import os

import requests
import json

from pandas.io.formats.format import return_docstring

configABSpath = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'config', 'config_ge4.json'))
with open(configABSpath, 'r') as file:
    configPath = json.load(file)

FID     = configPath['Linkage_DAO']
FOID    = configPath['FM_Order_DAO']
SOPATH  = configPath['SO_Header_DAO']
WOID    = configPath['WO_Details_DAO']
FFBOM   = configPath['FM_BOM_DAO']

# Query strings
salesorder_query_to_fetch_fullfilment_id = """
query MyQuery($data: [String!]!) {
  getBySalesorderids(salesorderIds: $data) {
    result {
      asnNumbers {
        createDate
        shipDate
        shipFrom
        shipTo
        sourceManifestId
        snNumber
        sourceManifestStatus
      }
      fulfillment {
        createDate
        fulfillmentId
        fulfillmentStatus
        oicId
        sourceSystemStatus
      }
      fulfillmentOrders {
        createDate
        foId
      }
      salesOrder {
        buid
        createDate
        region
        salesOrderId
      }
      workOrders {
        channelStatusCode
        createDate
        woId
        woStatusCode
        woType
      }
    }
  }
}
"""

fullfilmentid_to_fetch_sales_order_ref = """
query MyQuery($data: String!) {
  getFulfillmentsById(fulfillmentId: $data) {
    fulfillments {
      salesOrderRef
    }
  }
}

"""

workorderid_to_fulfiment_id = """
query MyQuery($data: [String!]!) {
  getByWorkorderids(workorderIds: $data) {
    result {
      salesOrder {
        buid
        createDate
        region
        salesOrderId
      }
      fulfillmentOrders {
        createDate
        foId
      }
      fulfillment {
        createDate
        fulfillmentId
        fulfillmentStatus
        oicId
        sourceSystemStatus
      }
      asnNumbers {
        createDate
        shipFrom
        shipDate
        shipTo
        snNumber
        sourceManifestId
        sourceManifestStatus
      }
      workOrder {
        channelStatusCode
        createDate
        woId
        woStatusCode
        woType
      }
    }
  }
}
"""

fulfilment_id_query_keys = """
query MyQuery ($data: [String!]!){
  getByFulfillmentids(fulfillmentIds: $data) {
    result {
      asnNumbers {
        createDate
        shipDate
        shipFrom
        shipTo
        snNumber
        sourceManifestId
        sourceManifestStatus
      }
      fulfillment {
        createDate
        fulfillmentId
        fulfillmentStatus
        oicId
        sourceSystemStatus
      }
      fulfillmentOrders {
        createDate
        foId
      }
      salesOrder {
        buid
        createDate
        region
        salesOrderId
      }
      workOrders {
        channelStatusCode
        createDate
        woId
        woStatusCode
        woType
      }
    }
  }
}
"""

fulfillment_query = """
query MyQuery($ids: [String]) {
  getByFulfillmentids(fulfillmentIds: $ids) {
    result {
      fulfillment {
        fulfillmentId
        fulfillmentStatus
      }
      # ... other fields
    }
  }
}
"""

fulfilment_order_id_query_to_fetch_other_data = """
query MyQuery($data: [String!]!) {
  getAllFulfillmentHeadersByFoId(foId: $data) {
    salesOrderId
    salesOrderRef
    fulfillmentId
    foId
    isDirectShip
    region
    updateBy
    updateDate
    createDate
    createBy
    foRef
    partitionDate
  }
}
"""

order_date_query_to_fetch_other_data = """
query MyQuery($fromDate: DateTime!, $toDate: DateTime!) {
  getOrdersByDate(fromDate: $fromDate, toDate: $toDate) {
    result {
      salesOrderRef
      salesOrderId
      fulfillmentId
    }
  }
}
"""

final_response_query_1 = """
query MyQuery($data: String!) {
  getFulfillmentByRef(salesOrderRef: $data) {
    buid
    region
    salesOrderId
    soHeaderRef
    sourceSystemId
    fulfillments {
      address {
        addressId
        addressLine1
        addressLine2
        addressLine3
        addressLine4
        addressLine5
        addressSeqNum
        categoryCodeDesc
        cfoLang
        city
        cityCode
        companyName
        contact {
          addressId
          addressSeqNum
          contactId
          contactType
          createBy
          createDate
          customerType
          partitionDate
          salesOrderRef
          soHeaderRef
          soLineRef
          updateBy
          updateDate
        }
        country
        createBy
        createDate
        custCategory
        custAddressId
        customerNum
        customerNameExt
        divisionDept
        email
        englishCompanyName
        englishFirstName
        englishLastName
        englishFullName
        englishLine1
        englishLine2
        englishLine3
        englishLine4
        englishLine5
        englishStateDesc
        entityType
        fedTaxId
        firstName
        fullName
        lastName
        lblContactName
        locationCode
        mailStop
        middleName
        partitionDate
        phone {
          addressId
          areaCode
          countryCode
          createBy
          createDate
          extension
          mediaType
          partitionDate
          phoneNumber
          phoneNumberId
          updateBy
          updateDate
        }
        postalCode
        prefix
        region
        stateCode
        stateDesc
        suburb
        suffix
        taxRegstrnNum
        title
        ucid
        updateBy
        updateDate
      }
      attributes {
        attributeName
        attributeValue
        createDate
        createBy
        salesOrderRef
        soAttributeRef
        updateBy
        updateDate
      }
      carrierAccount
      createBy
      createDate
      deliveryCity
      estDeliveryDate
      estShipDate
      fulfillmentId
      futureDeliveryDate
      inbndShipMethod
      isInvoicable
      manifestDate
      mergeType
      mrp
      mustArriveByDate
      mustShipByDate
      oicId
      partitionDate
      paymentTerm
      paymentTermCfoDesc
      region
      revisedDeliveryDate
      salesOrderId
      salesOrderLines {
        address {
          addressId
          addressLine1
          addressLine3
          addressLine2
          addressLine4
          addressLine5
          addressSeqNum
          categoryCodeDesc
          cfoLang
          city
          cityCode
          companyName
          contact {
            addressId
            addressSeqNum
            contactId
            contactType
            createBy
            createDate
            customerType
            partitionDate
            salesOrderRef
            soHeaderRef
            soLineRef
            updateBy
            updateDate
          }
          country
          createBy
          createDate
          custAddressId
          custCategory
          customerNameExt
          customerNum
          divisionDept
          email
          englishCompanyName
          englishFirstName
          englishFullName
          englishLastName
          englishLine1
          englishLine2
          englishLine3
          englishLine4
          englishLine5
          englishStateDesc
          fedTaxId
          entityType
          firstName
          fullName
          lastName
          lblContactName
          locationCode
          mailStop
          middleName
          partitionDate
          phone {
            addressId
            areaCode
            countryCode
            createBy
            createDate
            extension
            partitionDate
            mediaType
            phoneNumber
            phoneNumberId
            updateBy
            updateDate
          }
          postalCode
          prefix
          region
          stateCode
          stateDesc
          suburb
          suffix
          taxRegstrnNum
          title
          ucid
          updateBy
          updateDate
        }
        attributes {
          attributeName
          attributeValue
          createBy
          createDate
          soLineAttributeRef
          soLineRef
          updateBy
          updateDate
        }
        bomInventoryOrgCode
        buName
        configInvItemNum
        createBy
        createDate
        facility
        family
        finalPrice
        fulfillmentId
        isServiceTagRequired
        isShippable
        itemDesc
        itemId
        itemNum
        itemSubType
        lineId
        linkLine
        linkOrder
        linkType
        lob
        orderdQty
        originalPrice
        partitionDate
        platform
        region
        salesOrderRef
        siNumber
        soLineNum
        soLineQty
        soLineRef
        solineDtl {
          createBy
          createDate
          finalPrice
          isFulfillable
          itemDesc
          itemNum
          originalPrice
          partitionDate
          qty
          soLineDtlRef
          soLineRef
          unitOfMeasure
          updateBy
          updateDate
        }
        soLineType
        solinecharges {
          chargeCost
          chargeType
          createBy
          createDate
          partitionDate
          quantity
          soLineChargeRef
          soLineRef
          unitFee
          updateBy
          totalAmount
          updateDate
        }
        sourceTranscNum
        specialinstructions {
          createBy
          createDate
          instruction
          partitionDate
          seqNum
          soLineRef
          specialInstructionId
          specialInstructionType
          updateBy
          updateDate
        }
        unitOfMeasure
        updateBy
        updateDate
      }
      salesOrderRef
      shipByDate
      shipCode
      shipCodeGroup
      shipWeight
      soHeaderRef
      sostatus {
        createBy
        createDate
        fulfillmentId
        fulfillmentStsCode
        partitionDate
        salesOrderId
        salesOrderRef
        soStatusRef
        sourceSystemStsCode
        statusDate
        updateBy
        updateDate
      }
      sostatushist {
        createBy
        createDate
        fulfillmentId
        fulfillmentStsCode
        salesOrderId
        sourceSystemStsCode
        statusDate
        updateBy
        updateDate
      }
      systemQty
      updateBy
      updateDate
    }
  }
}
"""


# Query registry: maps keys to (query_string, graphql_url)
QUERY_REGISTRY = {
    "salesorder": {
        "query": [salesorder_query_to_fetch_fullfilment_id, ],
        "regions": {
            "india": FID,
            "us": FID,
            "eu": FID
        }
    },
    "fulfilment_to_sales_order_ref": {
        "query": fullfilmentid_to_fetch_sales_order_ref,
        "regions": {
            "india": SOPATH,
            "us": SOPATH,
            "eu": SOPATH
        }
    },
    "fulfillment_to_salesref": {
        "query": fulfillment_query,
        "regions": {
            "india": "https://india.fulfillment-api.example.com/graphql",
            "us": "https://us.fulfillment-api.example.com/graphql",
            "eu": "https://eu.fulfillment-api.example.com/graphql"
        }
    },
    "work_order":{
        "query": workorderid_to_fulfiment_id,
        "regions": {
            "india": FID,
            "us": FID,
            "eu": FID
        }
    },
    "fulfillment":{
        "query": fulfilment_id_query_keys,
        "regions": {
            "india": FID,
            "us": FID,
            "eu": FID
        }
    },
    "fulfillment_order":{
        "query": fulfilment_order_id_query_to_fetch_other_data,
        "regions": {
            "india": FOID,
            "us": FOID,
            "eu": FOID
        }
    },
    "order_date":{
        "query": order_date_query_to_fetch_other_data,
        "regions": {
            "india": SOPATH,
            "us": SOPATH,
            "eu": SOPATH
        }
    },
    "final_response_1": {
        "query": final_response_query_1,
        "regions": {
            "india": SOPATH,
            "us": SOPATH,
            "eu": SOPATH
        }
    },
}


def all_queries():
    return QUERY_REGISTRY


def execute_query(query: str, url: str, data):
    """
    Executes the GraphQL query defined by `query_key` for the given `region`.
    """
    DEFAULT_HEADERS = {
        "Content-Type": "application/json"
    }
    response = requests.post(
        url,
        headers=DEFAULT_HEADERS,
        json={
            "query": query,
            "variables": data
        },
        verify = False
    )

    if response.status_code == 200:
        result = response.json()
        # print(json.dumps(result, indent=2))
        return result
    else:
        print("----  FAILURE -------")
        print(response.text)
        return None

def fetch_salesorder_ref_ids(fo_ids):
    query_key = all_queries()['fulfillment_order']
    query = query_key['query']
    url = query_key["regions"]["india"]
    res = execute_query(query, url,  data={"data": fo_ids})
    fullfillment_headers_data1 = res.get("data", {}).get('getAllFulfillmentHeadersByFoId', [])
    sales_order_refs = []

    for each_fulfilment_order_data1 in fullfillment_headers_data1:
        sales_order_ref_id = each_fulfilment_order_data1.get('salesOrderRef')
        sales_order_refs.append(sales_order_ref_id)
    return sales_order_refs

def fetch_final_response(sales_order_ref_ids1):
    query_key = all_queries()['final_response_1']
    query = query_key['query']
    url = query_key["regions"]["india"]
    final_response = []
    for each_so_ref_id in sales_order_ref_ids1:
        res = execute_query(query=query, url=url, data={"data": each_so_ref_id})
        # import pdb; pdb.set_trace()
        response_data = res.get("data", {}).get('getFulfillmentByRef', [{}])[0]

        response_data_2 = {}
        fullfilment_data = response_data.get("fulfillments", [{}])[0]
        sales_order_lines_data = fullfilment_data.get("salesOrderLines", [{}])[0]
        address_data = fullfilment_data.get("address", [{}])[0]
        result_dict = {
            "PP Date": response_data_2.get("ppDate"), # getSoheaderBySoids
            "FoId": response_data_2.get("foId") if response_data_2 else None,
            "Ship From Facility": response_data_2.get("shipFromFacility"),
            "Ship To Facility": response_data_2.get("shipToFacility"),
            "IsDirect Ship": response_data_2.get("isDirectShip"),
            "SSC": response_data_2.get("ssc"),
            "Order Date": response_data_2.get("orderDate"),
            "wo_ids": "",
            # "wo_ids": wo_data, # need to check

            "BUID": response_data.get("buid"),
            "Sales Order Id": response_data.get("salesOrderId", ""),
            "Fulfillment Id": fullfilment_data.get("fulfillmentId", ""),
            "Region Code": response_data.get("region"),
            "System Qty": fullfilment_data.get("systemQty"),
            "Ship By Date": fullfilment_data.get("shipByDate"),
            "LOB": sales_order_lines_data.get("lob"),
            "Tax Regstrn Num": address_data.get("taxRegstrnNum"),
            "Address Line1": address_data.get("addressLine1"),
            "Postal Code": address_data.get("postalCode"),
            "State Code": address_data.get("stateCode"),
            "City Code": address_data.get("cityCode"),
            "Customer Num": address_data.get("customerNum"),
            "Customer Name Ext": address_data.get("customerNameExt"),
            "Country": address_data.get("country"),
            "Create Date": address_data.get("createDate"),
            "Ship Code": fullfilment_data.get("shipCode"),
            "Must Arrive By Date": fullfilment_data.get("mustArriveByDate"),
            "Update Date": fullfilment_data.get("updateDate"),
            "Merge Type": fullfilment_data.get("mergeType"),
            "Manifest Date": fullfilment_data.get("manifestDate"),
            "Revised Delivery Date": fullfilment_data.get("revisedDeliveryDate"),
            "Delivery City": fullfilment_data.get("deliveryCity"),
            "Source System Id": response_data.get("sourceSystemId"),
            "OIC Id": fullfilment_data.get("oicId"),
        }
        final_response.append(result_dict)
    return final_response

def fetch_data_using_sales_order_ids(sales_orderid_vals):
    query_key = all_queries()['salesorder']
    query = query_key['query'][0]
    url = query_key["regions"]["india"]
    res = execute_query(query=query, url=url, data={"data": sales_orderid_vals})

    sales_data = res.get("data", {}).get('getBySalesorderids', {}).get('result', [])
    if not sales_data:
        raise AttributeError("invalid sales order data")

    fullfil_ids = []
    source_manifest_ids = []
    filfilment_order_ids = []  # fo ids
    work_order_ids = []  # WO ids
    sales_order_ids = []

    for each_sales in sales_data:
        sales_fullfillment_data = each_sales.get('fulfillment', [])
        for fillfillment_data in sales_fullfillment_data:
            fullfil_ids.append(fillfillment_data.get('fulfillmentId'))

        asn_numbers_data = each_sales.get('asnNumbers', [])
        for each_asn_number in asn_numbers_data:
            source_manifest_ids.append(each_asn_number.get('sourceManifestId'))

        fulfilment_orders = each_sales.get('fulfillmentOrders', [])
        for each_fo_data in fulfilment_orders:
            filfilment_order_ids.append(each_fo_data.get('foId'))

        work_order_orders = each_sales.get('workOrders', [])
        for each_work_order in work_order_orders:
            work_order_ids.append(each_work_order.get('woId'))

        sales_order_dict = each_sales.get('salesOrder', {})
        if sales_order_dict:
            sales_order_ids.append(sales_order_dict.get('salesOrderId'))

    sales_order_refs = fetch_salesorder_ref_ids(filfilment_order_ids)
    return sales_order_ids, fullfil_ids, filfilment_order_ids, work_order_ids, sales_order_refs

def fetch_data_using_work_order_ids(work_order_id_val):
    query_key = all_queries()['work_order']
    query = query_key['query']
    url = query_key["regions"]["india"]
    res = execute_query(query, url, data={"data": work_order_id_val})

    work_order_data = res.get("data", {}).get('getByWorkorderids', {}).get('result', [])
    if not work_order_data:
        raise AttributeError("invalid work order data")

    sales_order_ids = []
    fullfil_ids = []
    source_manifest_ids = []
    filfilment_order_ids = []  # fo ids
    work_order_ids = []  # wo ids

    for each_work_order in work_order_data:
        sales_order_dict = each_work_order.get('salesOrder', {})
        if sales_order_dict:
            sales_order_ids.append(sales_order_dict.get('salesOrderId'))

        fulfilment_orders = each_work_order.get('fulfillmentOrders', [])
        for each_fo_data in fulfilment_orders:
            filfilment_order_ids.append(each_fo_data.get('foId'))

        fullfillment_dict = each_work_order.get('fulfillment')
        if fullfillment_dict:
            fullfil_ids.append(fullfillment_dict.get('fulfillmentId'))

        asn_numbers_data = each_work_order.get('asnNumbers', [])
        for each_asn_number in asn_numbers_data:
            source_manifest_ids.append(each_asn_number.get('sourceManifestId'))

        work_order_dict = each_work_order.get('workOrder', {})
        if work_order_dict:
            work_order_ids.append(work_order_dict.get('woId'))
    if filfilment_order_ids:
        sales_order_refs = fetch_salesorder_ref_ids(filfilment_order_ids)
    else:
        sales_order_refs = []
    return sales_order_ids, fullfil_ids, filfilment_order_ids, work_order_ids, sales_order_refs

def fetch_data_using_fullfilment_ids(fulfilment_id_val):
    # import pdb; pdb.set_trace()
    query_key = all_queries()['fulfillment']
    query = query_key['query']
    url = query_key["regions"]["india"]
    res = execute_query(query, url, data={"data": fulfilment_id_val})

    fullfillment_data = res.get("data", {}).get('getByFulfillmentids', {}).get('result', [])
    if not fullfillment_data:
        raise AttributeError("Invalid Fulfillment data")

    sales_order_ids = []
    fullfil_ids = []
    source_manifest_ids = []
    filfilment_order_ids = []  # fo ids
    work_order_ids = []  # wo ids

    for each_fulfilment in fullfillment_data:
        sales_order_dict = each_fulfilment.get('salesOrder', {})
        if sales_order_dict:
            sales_order_ids.append(sales_order_dict.get('salesOrderId'))

        fulfilment_orders = each_fulfilment.get('fulfillmentOrders', [])
        for each_fo_data in fulfilment_orders:
            filfilment_order_ids.append(each_fo_data.get('foId'))

        fullfillment_dict = each_fulfilment.get('fulfillment')
        if fullfillment_dict:
            fullfil_ids.append(fullfillment_dict.get('fulfillmentId'))

        asn_numbers_data = each_fulfilment.get('asnNumbers', [])
        for each_asn_number in asn_numbers_data:
            source_manifest_ids.append(each_asn_number.get('sourceManifestId'))

        work_order_orders = each_fulfilment.get('workOrders', [])
        for each_work_order in work_order_orders:
            work_order_ids.append(each_work_order.get('woId'))
    sales_order_refs = fetch_salesorder_ref_ids(filfilment_order_ids)
    return sales_order_ids, fullfil_ids, filfilment_order_ids, work_order_ids, sales_order_refs

def fetch_data_using_fulfilment_order_id(fulfilment_order_id_val):
    query_key = all_queries()['fulfillment_order']
    query = query_key['query']
    url = query_key["regions"]["india"]
    res = execute_query(query, url, data={"data": fulfilment_order_id_val})

    fullfillment_headers_data = res.get("data", {}).get('getAllFulfillmentHeadersByFoId', [])
    if not fullfillment_headers_data:
        raise AttributeError("Invalid Fulfilment order data")


    sales_order_ids = []
    fullfil_ids = []
    filfilment_order_ids = []  # fo ids
    sales_order_refs = []

    for each_fulfilment_order_data in fullfillment_headers_data:
        sales_order_id = each_fulfilment_order_data.get('salesOrderId')
        sales_order_ref_id = each_fulfilment_order_data.get('salesOrderRef')
        fullfilment_id = each_fulfilment_order_data.get('fulfillmentId')
        fullfillment_order_id = each_fulfilment_order_data.get('foId')
        sales_order_ids.append(sales_order_id)
        sales_order_refs.append(sales_order_ref_id)
        fullfil_ids.append(fullfilment_id)
        filfilment_order_ids.append(fullfillment_order_id)
    return sales_order_ids, fullfil_ids, filfilment_order_ids, sales_order_refs

def fetch_filter_data(input_data):
    is_order_date_present = False
    if "from_date" in input_data and "to_date" in input_data:
        is_order_date_present = True
        query_key = all_queries()['order_date']
        query = query_key['query']
        url = query_key["regions"]["india"]
        res = execute_query(
            query=query, url=url,
            data={"fromDate": input_data['from_date'] + "T00:00:00Z",
                  "toDate": input_data['to_date'] + "T23:59:59Z"})
        input_data.pop("from_date")
        input_data.pop("to_date")
        orders_data = res.get("data", {}).get('getOrdersByDate', {}).get('result', [])
        if not orders_data:
            print("No Orders found between the dates provided")

        sales_order_refs_data = []
        sales_order_ids_data = []
        fullfil_ids_data = []
        for each_order in orders_data:
            sales_order_ref = each_order.get('salesOrderRef')
            sales_order_id = each_order.get('salesOrderId')
            fulfillment_id = each_order.get('fulfillmentId')

            sales_order_ids_data.append(sales_order_id)
            sales_order_refs_data.append(sales_order_ref)
            fullfil_ids_data.append(fulfillment_id)

        if input_data.get("sales_order_ids"):
            sales_order_unmatched_ids = [item for item in input_data.get("sales_order_ids") if
                                         item not in sales_order_ids_data]
            if sales_order_unmatched_ids:
                raise AttributeError(f"Sales Order Ids {', '.join(sales_order_unmatched_ids)} invalid")

        query_key = all_queries()['salesorder']
        query = query_key['query'][0]
        url = query_key["regions"]["india"]

        fullfil_ids = []
        source_manifest_ids = []
        filfilment_order_ids = []  # fo ids
        work_order_ids = []  # WO ids
        sales_order_ids = []
        sales_order_refs = []
        chunk_size = 20
        if input_data.get("sales_order_ids"):
            sales_id_to_use = input_data.get("sales_order_ids")
        else:
            sales_id_to_use = sales_order_ids_data
        total = len(sales_id_to_use)

        for i in range(0, total, chunk_size):
            chunk = sales_id_to_use[i: i + chunk_size]
            res = execute_query(query=query, url=url, data={"data": chunk})

            sales_data = res.get("data", {}).get('getBySalesorderids', {}).get('result', [])
            if not sales_data:
                raise AttributeError("invalid sales order ids")

            for each_sales in sales_data:
                sales_fullfillment_data = each_sales.get('fulfillment', [])
                for fillfillment_data in sales_fullfillment_data:
                    fullfil_ids.append(fillfillment_data.get('fulfillmentId'))

                asn_numbers_data = each_sales.get('asnNumbers', [])
                for each_asn_number in asn_numbers_data:
                    source_manifest_ids.append(each_asn_number.get('sourceManifestId'))

                fulfilment_orders = each_sales.get('fulfillmentOrders', [])
                for each_fo_data in fulfilment_orders:
                    filfilment_order_ids.append(each_fo_data.get('foId'))

                work_order_orders = each_sales.get('workOrders', [])
                for each_work_order in work_order_orders:
                    work_order_ids.append(each_work_order.get('woId'))

                sales_order_dict = each_sales.get('salesOrder', {})
                if sales_order_dict:
                    sales_order_ids.append(sales_order_dict.get('salesOrderId'))

            sales_order_refs = fetch_salesorder_ref_ids(filfilment_order_ids)

        # import pdb; pdb.set_trace()

        if input_data.get("work_order_ids"):
            work_order_unmatched_ids = [item for item in input_data.get("work_order_ids") if item not in work_order_ids]
            if work_order_unmatched_ids:
                raise AttributeError(f"Work Order Ids {', '.join(work_order_unmatched_ids)} invalid")
            sales_order_ids, fullfil_ids, filfilment_order_ids, work_order_ids, sales_order_refs = fetch_data_using_work_order_ids(
                input_data.get("work_order_ids"))

        if input_data.get("fulfilment_ids"):
            fullfilment_unmatched_ids = [item for item in input_data.get("fulfilment_ids") if item not in fullfil_ids]
            if fullfilment_unmatched_ids:
                raise AttributeError(f"Fulfilment Ids {', '.join(fullfilment_unmatched_ids)} invalid")
            sales_order_ids, fullfil_ids, filfilment_order_ids, work_order_ids, sales_order_refs = fetch_data_using_fullfilment_ids(
                input_data.get("fulfilment_ids"))

        if input_data.get("filfilment_order_ids"):
            fullfilment_order_unmatched_ids = [item for item in input_data.get("filfilment_order_ids") if
                                               item not in filfilment_order_ids]
            if fullfilment_order_unmatched_ids:
                raise AttributeError(f"Fulfilment Ids {', '.join(fullfilment_order_unmatched_ids)} invalid")
            sales_order_ids, fullfil_ids, filfilment_order_ids, sales_order_refs = fetch_data_using_fulfilment_order_id(input_data.get("filfilment_order_ids"))
        if input_data.get("sales_order_ref_ids"):
            sales_order_ref_unmatched_ids = [item for item in input_data.get("sales_order_ref_ids") if
                                               item not in sales_order_refs]
            if sales_order_ref_unmatched_ids:
                raise AttributeError(f"Sales Order Ref Ids {' ,'.join(sales_order_ref_unmatched_ids)} invalid")
            sales_order_refs = input_data.get("sales_order_ref_ids")

    if "sales_order_ids" in input_data and not is_order_date_present:
        sales_order_ids, fullfil_ids, filfilment_order_ids, work_order_ids, sales_order_refs = fetch_data_using_sales_order_ids(input_data.get("sales_order_ids"))

        if input_data.get("work_order_ids"):
            work_order_unmatched_ids = [item for item in input_data.get("work_order_ids") if item not in work_order_ids]
            if work_order_unmatched_ids:
                raise AttributeError(f"Work Order Ids {' ,'.join(work_order_unmatched_ids)} are invalid")
            sales_order_ids, fullfil_ids, filfilment_order_ids, work_order_ids, sales_order_refs = fetch_data_using_work_order_ids(
            input_data.get("work_order_ids"))
        if input_data.get("fulfilment_ids"):
            fullfilment_unmatched_ids = [item for item in input_data.get("fulfilment_ids") if item not in fullfil_ids]
            if fullfilment_unmatched_ids:
                raise AttributeError(f"Fulfilment Ids {' ,'.join(fullfilment_unmatched_ids)} invalid")
            sales_order_ids, fullfil_ids, filfilment_order_ids, work_order_ids, sales_order_refs = fetch_data_using_fullfilment_ids(
                input_data.get("fulfilment_ids"))

        if input_data.get("filfilment_order_ids"):
            fullfilment_order_unmatched_ids = [item for item in input_data.get("filfilment_order_ids") if
                                               item not in filfilment_order_ids]
            if fullfilment_order_unmatched_ids:
                raise AttributeError(f"Fulfilment Ids {' ,'.join(fullfilment_order_unmatched_ids)} invalid")
            sales_order_ids, fullfil_ids, filfilment_order_ids, sales_order_refs = fetch_data_using_fulfilment_order_id(
            input_data.get("filfilment_order_ids"))
        if input_data.get("sales_order_ref_ids"):
            sales_order_ref_unmatched_ids = [item for item in input_data.get("sales_order_ref_ids") if
                                               item not in sales_order_refs]
            if sales_order_ref_unmatched_ids:
                raise AttributeError(f"Sales Order Ref Ids {' ,'.join(sales_order_ref_unmatched_ids)} invalid")
            sales_order_refs = input_data.get("sales_order_ref_ids")

    if "sales_order_ids" not in input_data and "work_order_ids" in input_data:
        sales_order_ids, fullfil_ids, filfilment_order_ids, work_order_ids, sales_order_refs = fetch_data_using_work_order_ids(input_data.get("work_order_ids"))

        if input_data.get("fulfilment_ids"):
            fullfilment_unmatched_ids = [item for item in input_data.get("fulfilment_ids") if item not in fullfil_ids]
            if fullfilment_unmatched_ids:
                raise AttributeError(f"Fulfilment Ids {' ,'.join(fullfilment_unmatched_ids)} invalid")
            sales_order_ids, fullfil_ids, filfilment_order_ids, work_order_ids, sales_order_refs = fetch_data_using_fullfilment_ids(
            input_data.get("fulfilment_ids"))

        if input_data.get("filfilment_order_ids"):
            fullfilment_order_unmatched_ids = [item for item in input_data.get("filfilment_order_ids") if
                                               item not in filfilment_order_ids]
            if fullfilment_order_unmatched_ids:
                raise AttributeError(f"Fulfilment Ids {' ,'.join(fullfilment_order_unmatched_ids)} invalid")
            sales_order_ids, fullfil_ids, filfilment_order_ids, sales_order_refs = fetch_data_using_fulfilment_order_id(
                input_data.get("filfilment_order_ids"))
        if input_data.get("sales_order_ref_ids"):
            sales_order_ref_unmatched_ids = [item for item in input_data.get("sales_order_ref_ids") if
                                               item not in sales_order_refs]
            if sales_order_ref_unmatched_ids:
                raise AttributeError(f"Sales Order Ref Ids {' ,'.join(sales_order_ref_unmatched_ids)} invalid")
            sales_order_refs = input_data.get("sales_order_ref_ids")

    if "sales_order_ids" not in input_data and not "work_order_ids" in input_data and "fulfilment_ids" in input_data:
        sales_order_ids, fullfil_ids, filfilment_order_ids, work_order_ids, sales_order_refs = fetch_data_using_fullfilment_ids(input_data.get("fulfilment_ids"))

        if input_data.get("filfilment_order_ids"):
            fullfilment_order_unmatched_ids = [item for item in input_data.get("filfilment_order_ids") if
                                               item not in filfilment_order_ids]
            if fullfilment_order_unmatched_ids:
                raise AttributeError(f"Fulfilment Ids {' ,'.join(fullfilment_order_unmatched_ids)} invalid")
            sales_order_ids, fullfil_ids, filfilment_order_ids, sales_order_refs = fetch_data_using_fulfilment_order_id(
            input_data.get("filfilment_order_ids"))

        if input_data.get("sales_order_ref_ids"):
            sales_order_ref_unmatched_ids = [item for item in input_data.get("sales_order_ref_ids") if
                                               item not in sales_order_refs]
            if sales_order_ref_unmatched_ids:
                raise AttributeError(f"Sales Order Ref Ids {' ,'.join(sales_order_ref_unmatched_ids)} invalid")
            sales_order_refs = input_data.get("sales_order_ref_ids")

    if ("sales_order_ids" not in input_data and not "work_order_ids" in input_data
            and not "fulfilment_ids" in input_data and "fulfilment_order_ids" in input_data):
        sales_order_ids, fullfil_ids, filfilment_order_ids, sales_order_refs = fetch_data_using_fulfilment_order_id(input_data.get('fulfilment_order_ids'))
        if input_data.get("sales_order_ref_ids"):
            sales_order_ref_unmatched_ids = [item for item in input_data.get("sales_order_ref_ids") if
                                               item not in sales_order_refs]
            if sales_order_ref_unmatched_ids:
                raise AttributeError(f"Sales Order Ref Ids {' ,'.join(sales_order_ref_unmatched_ids)} invalid")
            sales_order_refs = input_data.get("sales_order_ref_ids")

    if ("sales_order_ids" not in input_data and not "work_order_ids" in input_data
            and not "fulfilment_ids" in input_data and not "fulfilment_order_ids" in input_data
            and not "sales_order_ref_ids" in input_data):
        fullfil_ids = []
        source_manifest_ids = []
        filfilment_order_ids = []  # fo ids
        work_order_ids = []  # WO ids
        sales_order_ids = []
        sales_order_refs = input_data.get('sales_order_ref_ids')

    print("fullfil_ids is ", fullfil_ids)
    print("filfilment_order_ids is ", filfilment_order_ids)
    print("work_order_ids is ", work_order_ids)
    print("sales_order_ids is ", sales_order_ids)
    print("sales_order_refs is ", sales_order_refs)

    final_data = fetch_final_response(sales_order_refs)

    return final_data

def tablestructural(data,IsPrimary):
    table_structure = {
        "columns": [            
            {"value": "BUID", "sortBy": "ascending", "isPrimary": IsPrimary in ["APJ","EMEA","DAO"], "group": "ID", "checked": IsPrimary in ["APJ","EMEA","DAO"]},
            {"value": "PP Date", "sortBy": "ascending", "isPrimary": IsPrimary in ["APJ","EMEA","DAO"], "group": "Date", "checked": IsPrimary in ["APJ","EMEA","DAO"]},
            {"value": "Sales Order Id", "sortBy": "ascending", "isPrimary": IsPrimary in ["APJ","EMEA","DAO"], "group": "ID", "checked": IsPrimary in ["APJ","EMEA","DAO"]},
            {"value": "Fulfillment Id", "sortBy": "ascending", "isPrimary": IsPrimary in ["APJ","EMEA","DAO"], "group": "ID", "checked": IsPrimary in ["APJ","EMEA","DAO"]},
            {"value": "Region Code", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "Code", "checked": IsPrimary in []},
            {"value": "FoId", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "ID", "checked": IsPrimary in []},
            {"value": "System Qty", "sortBy": "ascending", "isPrimary": IsPrimary in ["APJ","EMEA"], "group": "Other", "checked": IsPrimary in ["APJ","EMEA"]},
            {"value": "Ship By Date", "sortBy": "ascending", "isPrimary": IsPrimary in ["APJ","EMEA","DAO"], "group": "Date", "checked": IsPrimary in ["APJ","EMEA","DAO"]},
            {"value": "LOB", "sortBy": "ascending", "isPrimary": IsPrimary in ["APJ","EMEA"], "group": "Other", "checked": IsPrimary in ["APJ","EMEA"]},
            {"value": "Ship From Facility", "sortBy": "ascending", "isPrimary": IsPrimary in ["EMEA"], "group": "Facility", "checked": IsPrimary in ["EMEA"]},
            {"value": "Ship To Facility", "sortBy": "ascending", "isPrimary": IsPrimary in ["EMEA"], "group": "Facility", "checked": IsPrimary in ["EMEA"]},
            {"value": "Tax Regstrn Num", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "Other", "checked": IsPrimary in []},
            {"value": "Address Line1", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "Address", "checked": IsPrimary in []},
            {"value": "Postal Code", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "Address", "checked": IsPrimary in []},
            {"value": "State Code", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "Code", "checked": IsPrimary in []},
            {"value": "City Code", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "Address", "checked": IsPrimary in []},
            {"value": "Customer Num", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "Other", "checked": IsPrimary in []},
            {"value": "Customer Name Ext", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "Other", "checked": IsPrimary in []},
            {"value": "Country", "sortBy": "ascending", "isPrimary": IsPrimary in ['APJ'], "group": "Address", "checked": IsPrimary in ['APJ']},
            {"value": "Create Date", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "Date", "checked": IsPrimary in []},
            {"value": "Ship Code", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "Code", "checked": IsPrimary in []},
            {"value": "Must Arrive By Date", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "Date", "checked": IsPrimary in []},
            {"value": "Update Date", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "Date", "checked": IsPrimary in []},
            {"value": "Merge Type", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "Type", "checked": IsPrimary in []},
            {"value": "Manifest Date", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "Date", "checked": IsPrimary in []},
            {"value": "Revised Delivery Date", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "Date", "checked": IsPrimary in []},
            {"value": "Delivery City", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "Address", "checked": IsPrimary in []},
            {"value": "Source System Id", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "ID", "checked": IsPrimary in []},
            {"value": "Is Direct Ship", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "Flag", "checked": IsPrimary in []},
            {"value": "SSC", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "Other", "checked": IsPrimary in []},
            {"value": "Vendor Work Order Num", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "ID", "checked": IsPrimary in []},
            {"value": "Channel Status Code", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "Code", "checked": IsPrimary in []},
            {"value": "Ismultipack", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "Flag", "checked": IsPrimary in []},
            {"value": "Ship Mode", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "Mode", "checked": IsPrimary in []},
            {"value": "Is Otm Enabled", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "Flag", "checked": IsPrimary in []},
            {"value": "SN Number", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "ID", "checked": IsPrimary in []},
            {"value": "OIC ID", "sortBy": "ascending", "isPrimary": IsPrimary in [], "group": "ID", "checked": IsPrimary in []},
            {"value":"Order Date","sortBy":"ascending","isPrimary":IsPrimary in ["APJ","DAO"],"group":"Date","checked":IsPrimary in ["APJ","DAO"]}
        ],
        "data": []
    }
    table_structure["data"].extend(data)
    return table_structure

if __name__ == "__main__":
    input_data = {
        # "sales_order_ids": ["8040046800", "4159187249" ,"8040063124"],
        "work_order_ids": ["5888405866", ],
        "fulfilment_ids": ["5948698697", ],
        "fulfilment_order_ids": ["7336030653629440001", ],
        # "sales_order_ref_ids": ["7336030615125647360", ],
        # "from_date": "2025-06-01",
        # "to_date": "2025-07-20",
        "format_type": "grid",
        "region":"EMEA"
    }
    try:
        response_data = fetch_filter_data(input_data)
        if input_data.get("format_type") == "grid":
            desired_order = [
                'BUID', 'PP Date', 'Sales Order Id', 'Fulfillment Id', 'Region Code', 'FoId', 'System Qty', 'Ship By Date',
                'LOB', 'Ship From Facility', 'Ship To Facility', 'Tax Regstrn Num', 'Address Line1', 'Postal Code',
                'State Code',
                'City Code', 'Customer Num', 'Customer Name Ext', 'Country', 'Create Date', 'Ship Code',
                'Must Arrive By Date',
                'Update Date', 'Merge Type', 'Manifest Date', 'Revised Delivery Date', 'Delivery City', 'Source System Id',
                'IsDirect Ship',
                'SSC', 'Vendor Work Order Num', 'Channel Status Code', 'Ismultipack', 'Ship Mode', 'Is Otm Enabled',
                'SN Number', 'OIC Id', 'Order Date'
            ]

            rows = []
            for item in response_data:
                row = {
                    "columns": [{"value": item.get(key, "")} for key in desired_order]
                }
                rows.append(row)         
            table_grid_output = tablestructural(data=rows,IsPrimary=input_data.get("region"))
            print(json.dumps(table_grid_output, indent=2))
        else:
            print(response_data)

    except AttributeError as e:
        print("--------------- Failure message is ", str(e))




































