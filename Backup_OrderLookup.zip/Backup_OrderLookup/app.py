from cmath import e
import aiohttp
from flask import Flask, request, jsonify,send_file,g
import oracledb
import requests
from flask_cors import CORS
from ManifestTrackerFunctions.ManifestTrackerFunctions import getASNHeaderAndDetailsByASN
from OrderAssist.OrderAssist import GetCompleteEntitydata, GetErrorLogData, GetNode0DetailswithColorcode,  GetNodeDetailswithColorcode, GetOAEntitydata, GetOAOrderHeaderData, GetRuleLogforEntityData, extract_sales_order_info, getGSOProcessingWOGenerationdata, getOAActualPayload, getPayloadDetailsData, getPreGSONetworkPlanProcessingdata
from OrderTrackerFunctions.OrderTrackerFunctions import getEnvelopeOverview
from SNRelease.SNRelease import *
from constants.constants import * 
from OrderSummary.orderSummary import * 
import db_connect as db
import os
import json
import time
import datetime
import logging
from gql import Client, gql
from dateutil import parser
import gzip
import pandas as pd
import uuid
import re
import gc
import random
from OOE.graphql_client import build_and_execute_query
from flasgger import Swagger
# from gql.transport.aiohttp import AIOHTTPTransport
from OrderLookUpFunction.salesOrderWrapper import getbySalesOrderID
from OrderLookUpFunction.fullfillmentWrapper import getbyFulfillmentID
from OrderLookUpFunction.workorderWrapper import workerORderThread
from typing import OrderedDict

app = Flask(__name__)
swagger_template = {
    "info": {
        "title": "FDH API",
        "description": "Auto-generated API documentation using Flasgger",
        "version": "1.0.0"
    }
}
swagger = Swagger(app, template=swagger_template)
CORS(app = app, origins = '*')
env = os.getenv('FLASK_ENV', 'PROD')
logging.basicConfig(filename='FWBDataService.log', level=logging.INFO, format='%(asctime)s :: %(message)s')

@app.before_request
def start_timer():
    g.start_time = time.time()
    logging.info(f"request: {request.method} {request.url}")
    logging.info(f"Headers: {dict(request.headers)}")
    g.execution_times = []
    g.execution_urls = []


@app.after_request
def log_response_time(response):
    if hasattr(g, 'start_time'):
        duration = time.time() - g.start_time
        if response.content_type == "application/json":
            data=json.loads(response.get_data())
            if type(data) is list:
                 data[0]["logs"] = {
                                "urls":g.execution_urls,
                                "time":g.execution_times
                            }
            else:
                data["logs"] = {
                                "urls":g.execution_urls,
                                "time":g.execution_times
                            }
            response.set_data(json.dumps(data))
            response.mimetype="application/json"
       
            logging.info(f"Response Status: {response.status}")
            logging.info(f"Total Response time: {duration: .4f} seconds")
           
    return response
# Load the configuration file
@app.route("/")
def hello_world():
    return "<p>Hello, World!</p>"

# Service repository Screen details - to get service rep details  
# salesOrderId = "1016319320"
# fulfillmentId = "246199320"
# soHeaderRef="7317818307910455296"
# region: OrderSummary
@app.route('/getListofFFIdbySO', methods=['POST'])
def getListofFFIdbySO():
    
     # Get the inputs from the request
    orderType = request.json.get('orderType')
    orderValue = request.json.get('orderValue')
    region = request.json.get('region')

    if orderType == "SalesOrder":
        orderType = "soNumber"

    try:
        type = orderType
        input = orderValue
        if not type:
            return jsonify({"error": "Order type is required"}), 400
        if not input:
            return jsonify({"error": "Order value is required"}), 400

        query = f"""
        query ($input1: String) {{
            envelopeQuery {{
                getEnvelopeOverview({type}: $input1, region: "{region}") {{
                    soNumber
                    oicDetails {{
                        oicId
                        fulfillments {{
                            fulfillmentId
                            soNumber
                            createDate
                            status
                        }}
                    }}
                }}
            }}
        }}
        """
        variables = {
            "input1": input
        }
        url = geturlfromconfig('OOE', region)
        
        try:
            response = requests.post(
                url,
                json={'query': query, "variables": variables},
                verify=False
            )
            response.raise_for_status()  # Raise an HTTPError for bad responses

            response_data = response.json()

            # Check if sales order number is None
            if response_data['data']['envelopeQuery']['getEnvelopeOverview']['soNumber'] is None:
                return jsonify({"error": "No data found", "url": url}), 404

            # Initialize sets and lists
            fulfillment_ids = set()
            fulfillments = []

            # Extract sales order number
            sales_order_id = response_data['data']['envelopeQuery']['getEnvelopeOverview']['soNumber']

            # Iterate through oicDetails to extract fulfillment IDs and create dates
            for oic_detail in response_data['data']['envelopeQuery']['getEnvelopeOverview']['oicDetails']:
                for fulfillment in oic_detail['fulfillments']:
                    if fulfillment['fulfillmentId'] not in fulfillment_ids:
                        fulfillment_ids.add(fulfillment['fulfillmentId'])
                        fulfillments.append({
                            'fulfillmentId': fulfillment['fulfillmentId'],
                            'createDate': fulfillment['createDate'] if fulfillment['createDate'] is not None else '1900-01-01',
                            'region': region
                        })

            # Sort fulfillments by createDate in descending order
            fulfillments.sort(key=lambda x: x['createDate'], reverse=True)


            # Build the query dynamically
            return jsonify({
                'fulfillmentIds': list(fulfillment_ids),
                'fulfillments': fulfillments,
                'salesOrderId': sales_order_id
            })

        except aiohttp.ClientError as e:
            return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500

        except requests.exceptions.RequestException as e:
            return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500

    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred. Error: {e}"}), 500

    finally:
        gc.collect()

@app.route('/validate_sn', methods=['POST'])
def PostSnReleaseRequest():
    data = request.json
    mfgSnValidationRequestBySN = data.get('mfgSnValidationRequestBySN')
    orderType = mfgSnValidationRequestBySN['orderType']
    orderValue = mfgSnValidationRequestBySN['orderValue']
    vendor = mfgSnValidationRequestBySN['vendor']
    region = mfgSnValidationRequestBySN['region']
    correlationId = str(uuid.uuid4())
    sender_id = "FDH-WB"
    receiver_id = "CM"
    messageType ="SNRELEASEVALIDATIONREQUEST"
    message_id = str(random.randint(10000000, 99999999))
    
    url = geturlfromconfig('SnRelease_Request',region)
    headers = {'Content-type':'application/json', 'Accept':'application/json'}
    if orderType == "snNumber":
        sn_numbers = orderValue
        payload = {
        "mfgSnValidationRequestBySN": {
            "messageId": message_id,    
            "senderId": sender_id,
            "receiverId": receiver_id,
            "messageType": messageType,
            "correlationId": correlationId,
            "snNumbers": sn_numbers,
            "vendor": vendor,
            "region": region
        }
    }
    try:
        response = requests.post(url, json=payload, headers=headers, verify=False)
        response.raise_for_status()
        decoded_response = response.content.decode('utf-8')
        parsed_json_response = json.loads(decoded_response)
        if not parsed_json_response.get('mfgSnValidationResponse') is None:
            group_by_release_status =  group_by_release_status_and_reason(parsed_json_response)
        else:
            return jsonify({
            'group_by_details': None,
            'response_from_CM': None 
            })
        return jsonify({
            'group_by_details': group_by_release_status,
            'response_from_CM': parsed_json_response
        })
    except requests.exceptions.RequestException as e:
        logging.error(f"An error occurred: {e}")
        return jsonify({"error": "Error while making the request"}), 500
    

# @app.route('/validate_sn', methods=['POST'])
# def validate_sn():
   # Extracting necessary fields from the request
    data = request.json
    mfgSnValidationRequestBySN = data.get('mfgSnValidationRequestBySN')
    orderType = mfgSnValidationRequestBySN['orderType']
    orderValue = mfgSnValidationRequestBySN['orderValue']
    vendor = mfgSnValidationRequestBySN['vendor']
    region = mfgSnValidationRequestBySN['region']
    messageType ="SNRELEASEVALIDATIONREQUEST"
    message_id = random.randint(10000000, 99999999)
    correlationId =uuid.uuid4()
    sender_id = "FDH-WB"
    receiver_id = "CM"
    if orderType == "snNumber":
        sn_number = orderValue
        sn_numbers = [sn_number]
        snpayload = {
        "mfgSnValidationRequestBySN": {
            "messageId": message_id,    
            "senderId": sender_id,
            "receiverId": receiver_id,
            "messageType": messageType,
            "correlationId": correlationId,
            "snNumber": sn_numbers,
            "vendor": vendor,
            "region": region
        }
            # Creating the response
    
    }
        response = {
            "mfgSnValidationResponse": {
                "messageType": messageType,
                "messageId": message_id,
                "senderId": sender_id,
                "receiverId": receiver_id,
                "messageCreateDate": datetime.datetime.now().isoformat() + "Z",
                "correlationId": correlationId,
                "messageDetail": [
                    {
                        "region": region,
                        "vendor": vendor,
                        "snNumber": sn_number,
                        "releaseStatus": "Valid",  # or "InValid"
                        "releaseRejectedReason": "Order is already completed", # or "Order is not completed"
                        "rereleaseId": "7B29FC40-CA47-1067-B31D-00DD010662DB" # from CM if completed else empty
                    } for sn_number in sn_numbers
                ]
            }
        }
    elif orderType == "asnNumber":
        asn_number = orderValue
        asn_numbers = [asn_number]
        asnpayload = {
        "mfgSnValidationRequestBySN": {
            "messageId": message_id,    
            "senderId": sender_id,
            "receiverId": receiver_id,
            "messageType": messageType,
            "correlationId": correlationId,
            "asnNumber": asn_numbers,
            "vendor": vendor,
            "region": region
        }
    }
        response = {
            "mfgSnValidationResponse": {
                "messageType": messageType,
                "messageId": message_id,
                "senderId": sender_id,
                "receiverId": receiver_id,
                "messageCreateDate": datetime.datetime.now().isoformat() + "Z",
                "correlationId": correlationId,
                "messageDetail": [
                    {
                        "region": region,
                        "vendor": vendor,
                        "asnNumber": asn_number,
                        "snNumber": "4X00436310",
                        "releaseStatus": "Valid",  # or "InValid"
                        "releaseRejectedReason": "Order is already completed", # or "Order is not completed"
                        "rereleaseId": "7B29FC40-CA47-1067-B31D-00DD010662DB" # from CM if completed else empty
                    } for asn_number in asn_numbers
                ]
            }
        }
    response1= {
    "mfgSnValidationResponse": {
        "correlationId": correlationId,
        "messageCreateDate": "2025-05-13T12:03:09.190237Z",
        "messageDetail": [
            {
                "region": "APJ",
                "releaseRejectedReason": "Order is already completed",
                "releaseStatus": "Valid",
                "rereleaseId": "7B29FC40-CA47-1067-B31D-00DD010662DB",
                "snNumber": "4X004363510",
                "vendor": "ODM - COMPAL"
            },
            {
                "region": "APJ",
                "releaseRejectedReason": "Order is already completed",
                "releaseStatus": "Valid",
                "rereleaseId": "8B29FC40-CA47-1067-B31D-00DD010662DB",
                "snNumber": "4X004363310",
                "vendor": "ODM - COMPAL"
            },
            {
                "region": "APJ",
                "releaseRejectedReason": "Order is in IP",
                "releaseStatus": "Invalid",
                "rereleaseId": "9B29FC40-CA47-1067-B31D-00DD010662DB",
                "snNumber": "4X004363610",
                "vendor": "ODM - COMPAL"
            },
            {
                "region": "APJ",
                "releaseRejectedReason": "Order is on Hold",
                "releaseStatus": "Invalid",
                "rereleaseId": "6B29FC40-CA47-1067-B31D-00DD010662DB",
                "snNumber": "4X004363410",
                "vendor": "ODM - COMPAL"
            },
            {
                "region": "APJ",
                "releaseRejectedReason": "Order is already completed",
                "releaseStatus": "Valid",
                "rereleaseId": "5B29FC40-CA47-1067-B31D-00DD010662DB",
                "snNumber": "4X004336711",
                "vendor": "ODM - COMPAL"
            }
        ],
        "messageId": message_id,
        "messageType": "SNRELEASEVALIDATIONREQUEST",
        "receiverId": "ODM - COMPAL",
        "requestId": "12345",
        "senderId": "FDH-WB"
    }
}
    group_by_release_status =  group_by_release_status_and_reason(response1)
    return jsonify({
            'group_by_details': group_by_release_status,
            'response_from_CM': response1
        })
    return jsonify(group_by_release_status)

@app.route('/sn_validation_basedon_id', methods=['POST'])
def sn_validation_basedon_id():
    data = request.json
    request_id = data.get('mfgSnValidationRequestByRequestId', {}).get('requestId')
    release_status = data.get('mfgSnValidationRequestByRequestId', {}).get('releaseStatus')
    release_rejected_reason = data.get('mfgSnValidationRequestByRequestId', {}).get('releaseRejectedReason')
    messageType ="SNRELEASEVALIDATIONREQUESTBYID"
    correlationId =uuid.uuid4()
    sender_id = "FDH-WB"
    receiver_id = "CM"  
    message_id = uuid.uuid4()
  
    payload = {
        "mfgSnValidationRequestByRequestId": {
            "messageId": message_id,    
            "senderId": sender_id,
            "receiverId": receiver_id,
            "messageType": messageType,
            "correlationId": correlationId,
            "request_id": request_id,
            "releaseStatus": release_status,
            "releaseRejectedReason": release_rejected_reason
        }
    }
    # Simulate processing the request
    response = {
        "mfgSnValidationResponseByRequestId": {
            "messageType": messageType,
            "messageId": message_id,
            "senderId": "CM",
            "receiverId": "FDH-WB",
            "requestId": request_id,
            "messageCreateDate": datetime.datetime.now().isoformat() + "Z",
            "messageDetail": [
                {
                    "region": "APJ/EMEA/DAO",
                    "vendor": "CET",  #get details based on correlationId
                    "snNumber": "4X00436310",  #get details based on correlationId
                    "releaseStatus": release_status,
                    "releaseRejectedReason": release_rejected_reason,
                    "rereleaseId": "7B29FC40-CA47-1067-B31D-00DD010662DB" # from CM
                }
            ]
        }
    }

    return jsonify(response)

@app.route('/sn_release_trigger', methods=['POST'])
def sn_release_trigger():
    data = request.json
    sn_number = data.get('mfgSnReleaseTriggerReq', {}).get('snNumber')
    vendor = data.get('mfgSnReleaseTriggerReq', {}).get('shipFrom')
    region = data.get('mfgSnReleaseTriggerReq', {}).get('region')
    message_id = str(uuid.uuid4())
    sender_id = "FDH-WB"
    receiver_id = "CM"
    messageType ="SNRELEASETRIGGERREQUEST"
    # Simulate processing the request
    status = "Success"  # or "Failure" based on your logic
    reason = "SN already Released" if status == "Failure" else ""
    payload = {
        "mfgSnReleaseTriggerReq": {
            "messageId": message_id,    
            "senderId": sender_id,
            "receiverId": receiver_id,
            "messageType": messageType,
            "correlationId": "AEAccf20fdf-ec20-40b4-b8c9-7781d0157b06",
            "snNumber": sn_number,
            "vendor": vendor,
            "region": region
        }
    }
    response = {
        "mfgSnReleaseTriggerResp": {
            "messageId": message_id,
            "snNumber": sn_number,
            "shipFrom": vendor,
            "region": region,
            "Status": status,
            "Reason": reason
        }
    }

    return jsonify(response)
@app.route('/sn_getApproverList', methods=['POST'])
def sn_getApproverList():
    data = request.json
    request_id = data.get('requestId')
    vendor = data.get('vendor')
   # try:
    #     connection = db.get_db_connection("DEV")
    #     if not connection:
    #         return jsonify({
    #             'error_code': '101',
    #             'error_msg': 'Failed to connect to the database'
    #         }), 500

    #     cursor = connection.cursor()
    #     p_out_errorcode = cursor.var(oracledb.STRING)
    #     p_out_errmsg = cursor.var(oracledb.STRING)
    #     try:
    #         cursor.callproc('svc_fdh.pkg_sn_release_request_details.prc_insert_sn_release_request_details', [
    #             requestid, mfgSnApprovalRequestByUsertoDb, p_out_errorcode, p_out_errmsg
    #         ])

    #         error_code = p_out_errorcode.getvalue()
    #         error_msg = p_out_errmsg.getvalue()
    #     except:
    #         return jsonify({
    #             'error_code': '102',
    #             'error_msg': 'Failed to execute the procedure'
    #         }), 500
    #     finally:
    #         cursor.close()
    #         connection.close()

    #     return jsonify({
    #         'error_code': error_code,
    #         'error_msg': error_msg
    #     })
    # except:
    #     return jsonify({
    #         'error_code': '103',
    #         'error_msg': 'Unknown error'
    #     }), 500
    response={
        "approverList": ["user1@dell.com", "user2@dell.com", "user3@dell.com", "user4@dell.com"],
        "requestId": request_id,
        "vendor": vendor
    }
    # Check if the request was successful
    # if response.status_code == 200:
    #     # Return the response from the external service
    #     return jsonify(response.json())
        # else:
        #     # Return an error message if the request failed
        #     return jsonify({"error": "Failed to get response from external service"}), response.status_code
    return jsonify(response)

@app.route('/save_SnApprovalRequest', methods=['POST'])
def save_request():
    data = request.get_json()
    sn_number = data.get('mfgSnReleaseTriggerReq', {}).get('snNumber')

    mfgSnApprovalRequestByUsertoDb = data.get('mfgSnApprovalRequestByUsertoDb')
    requestid = data.get('mfgSnApprovalRequestByUsertoDb', {}).get('requestid')
    requestedapprovers = data.get('mfgSnApprovalRequestByUsertoDb', {}).get('requestedapprovers')
    mfgSnApprovalRequestByUser = data.get('mfgSnApprovalRequestByUsertoDb').get('mfgSnApprovalRequestByUser')
    # Save the request data to the database
    
    if not mfgSnApprovalRequestByUsertoDb :
        return jsonify({
            'error_code': '100',
            'error_msg': 'Null parameter provided'
        }), 400

    # try:
    #     connection = db.get_db_connection("DEV")
    #     if not connection:
    #         return jsonify({
    #             'error_code': '101',
    #             'error_msg': 'Failed to connect to the database'
    #         }), 500

    #     cursor = connection.cursor()
    #     p_out_errorcode = cursor.var(oracledb.STRING)
    #     p_out_errmsg = cursor.var(oracledb.STRING)
    #     try:
    #         cursor.callproc('svc_fdh.pkg_sn_release_request_details.prc_insert_sn_release_request_details', [
    #             requestid, mfgSnApprovalRequestByUsertoDb, p_out_errorcode, p_out_errmsg
    #         ])

    #         error_code = p_out_errorcode.getvalue()
    #         error_msg = p_out_errmsg.getvalue()
    #     except:
    #         return jsonify({
    #             'error_code': '102',
    #             'error_msg': 'Failed to execute the procedure'
    #         }), 500
    #     finally:
    #         cursor.close()
    #         connection.close()

    #     return jsonify({
    #         'error_code': error_code,
    #         'error_msg': error_msg
    #     })
    # except:
    #     return jsonify({
    #         'error_code': '103',
    #         'error_msg': 'Unknown error'
    #     }), 500
    return jsonify("Data has bee saved successfully")


@app.route('/GetMasterdataDetails', methods=['POST'])
def GetMasterdataDetails():
    data = request.json
    methodname = data.get('methodname')
    env = 'GE1'
    connection = db.get_db_connection(env)
    if not connection:
        return jsonify({
            'menu_details': {},
            'error_code': '101',
            'error_msg': 'Failed to connect to the database'
        })
    cursor = connection.cursor()
    p_out_query_data = cursor.var(oracledb.CLOB)
    p_out_column_data = cursor.var(oracledb.CLOB)
    p_out_field_data = cursor.var(oracledb.CLOB)

    p_out_errorcode = cursor.var(oracledb.STRING)
    p_out_errmsg = cursor.var(oracledb.STRING)  
    try:
        cursor.callproc('SVC_FDH.pkg_column_details.prc_select_column_details', [methodname, p_out_query_data, p_out_column_data,p_out_field_data, p_out_errorcode, p_out_errmsg])
        query_data = p_out_query_data.getvalue().read()
        column_data = p_out_column_data.getvalue().read()
        error_code = p_out_errorcode.getvalue()
        error_msg = p_out_errmsg.getvalue()
    except Exception as e:
        return jsonify({
            'Masterdata': {},
            'error_code': '102',
            'error_msg': 'Failed to execute the procedure. Error: ' + str(e)
        })
    finally:
        cursor.close()
        connection.close()
        gc.collect()
    obj = {
        "query_data": query_data,
        "column_data": column_data
    }
    return jsonify({
        'Masterdata': obj,
        'error_code': error_code,
        'error_msg': error_msg
    })
def getsoandffid(entitytype,entityvalue,region):

    type = entitytype
    input = entityvalue
    if not type:
        return jsonify({"error": type+" is required"}), 400
    if not input:
        return jsonify({"error": input+" is required"}), 400

    query = f"""
    query ($input1: String) {{
        envelopeQuery {{
            getEnvelopeOverview({type}: $input1, region: "{region}") {{
                soNumber
                oicDetails{{
                    oicId
                    fulfillments{{
                    fulfillmentId
                    soNumber
                    }}
                }}
            }}
        }}
    }}
    """
    variables = {
        "input1": input
    }
    url = geturlfromconfig('OOE',region)
    try:
        response = requests.post(
            url,
            json={'query': query, "variables": variables},
            verify=False  
        )
        #print(response.json())

        response= response.json()
        if (response['data']['envelopeQuery']['getEnvelopeOverview']['soNumber'] is None):
            return {
        'fulfillmentId': None,
        'salesOrderId': None}
        fulfillmentId= response['data']['envelopeQuery']['getEnvelopeOverview']['oicDetails'][0]['fulfillments'][0]['fulfillmentId']
        salesOrderId= response['data']['envelopeQuery']['getEnvelopeOverview']['soNumber']
         # Build the query dynamically
        return {
        'fulfillmentId': fulfillmentId,
        'salesOrderId': salesOrderId}
    
        
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500
    finally:
        gc.collect()

def getsoreffromsoorffid(salesOrderId,fulfillmentId,region):
    response = db.GetMasterDataconfigDetails('getShipsetsBysoshipsetid')
    response = response['query_data'] 
    query = response % (salesOrderId, fulfillmentId)
    url =   geturlfromconfig('SO_Header',region)
    try:
        # Make the request to the GraphQL endpoint
        response = requests.post(
            url,
            json={'query': query},
            verify=False  # Disable SSL verification for GE4elopment purposes
        )
        response = response.json()
        if response['data']['getFulfillmentsBysofulfillmentid'] == []:
            return {
        'soHeaderRef': None}
        soHeaderRef = response['data']['getFulfillmentsBysofulfillmentid'][0]['soHeaderRef']
        return soHeaderRef
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500   
    finally:
        gc.collect()


def managed_Columns_details(salesOrderId,fulfillmentId,region):
    response = db.GetMasterDataconfigDetails('getManagedColumns')
    response = response['query_data'] 
    query = response % (salesOrderId, fulfillmentId,salesOrderId,salesOrderId,fulfillmentId)
    url =   geturlfromconfig('SO_Header',region)
    try:
        # Make the request to the GraphQL endpoint
        response = requests.post(
            url,
            json={'query': query},
            verify=False  # Disable SSL verification for GE4elopment purposes
        )
        response = response.json()
        return response
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500
    finally:
        gc.collect()
@app.route('/getHighlitedColumns', methods=['POST'])
def getHighlitedColumns():
  
    # Get the inputs from the request
    orderType = request.json.get('orderType')
    orderValue= request.json.get('orderValue')
    region= request.json.get('region')
    fields = request.json.get('fields', [])
    if (orderType =="FulfillmentId"):
        orderType = "fulfillmentId"
    elif (orderType =="SalesOrder"):
        orderType ="soNumber"
    elif (orderType =="WorkOrder"):
        orderType ="workOrderId"
        workorderId = request.json.get('orderValue')
    if ((orderType =="soNumber") or (orderType =="fulfillmentId")):
        soandss=  getsoandffid(orderType,orderValue,region) 

        if  (soandss['salesOrderId'] is None):
            return jsonify({"error": "Sales Order not found In OOE"}), 404    
        if  (soandss['fulfillmentId'] is None):
            return jsonify({"error": "fulfillmentId not found In OOE"}), 404   
        salesOrderId = soandss['salesOrderId']
        fulfillmentId = soandss['fulfillmentId']
        soHeaderRef =  getsoreffromsoorffid(salesOrderId,fulfillmentId,region) 
        if soHeaderRef == ({'soHeaderRef': None}):
            return jsonify({"error": "SoHeaderRef not found in USL"}), 404
        else:
         query =  getfulfillmentIdBysofulfillmentIdHC_query( salesOrderId ,fulfillmentId, fields)

    else :
        salesOrderRef =  getsoreffromwoid(workorderId,region) 
        soffid =  getsoandffidbysoref(salesOrderRef,region)
        salesOrderId = soffid['salesOrderId']
        fulfillmentId = soffid['fulfillmentId']
        soHeaderRef =  getsoreffromsoorffid(salesOrderId,fulfillmentId,region) 
        if soHeaderRef == ({'soHeaderRef': None}):
            return jsonify({"error": "soHeaderRef not found"}), 404
        else:
            query =  getfulfillmentIdBysofulfillmentIdHC_query( salesOrderId ,fulfillmentId, fields)



       #Build the query dynamically
    url =    geturlfromconfig('SO_Header',region)
    try:
        # Make the request to the GraphQL endpoint
        response = requests.post(
            url,
            json={'query': query},
            verify=False  # Disable SSL verification for GE4elopment purposes
        )
        response= response.json()
        if response.get('data') is None and 'errors' in response:
            error_message = response['errors'][0].get('message', 'Unknown error occurred')
            return jsonify({"error": error_message}), 404        # Extract the 'getShipsetByRef' from the given JSON
        fields2 =["orderType"]
        query2 =  getSoheaderByRef_query(salesOrderId, fields2)
        json_response2 = requests.post(
            url,
            json={'query': query2},
            verify=False  # Disable SSL verification for GE4elopment purposes
        )
        json_response2= json_response2.json()
        if json_response2.get('data') is None and 'errors' in json_response2:
            error_message = json_response2['errors'][0].get('message', 'Unknown error occurred')
            return jsonify({"error": error_message}), 404  
        response =response['data']['getFulfillmentsBysofulfillmentid']
        json_response2= json_response2['data']['getSoheaderBySoids']
        # response = flatten_json(response)
        # json_response2= flatten_json(json_response2)
        # Extract key-value pairs from both JSON responses
        managedcolumsvalue = merge_json(response, json_response2)
        fields=  merge_fields(fields, fields2)
# Print the merged key-value pairs
        column_names =  get_field_names(managedcolumsvalue)
        response = db.GetMasterDataconfigDetails('getHighlitedColumns')
        # Get the data from the response    
        response = response['column_data']
        displaynames = json.loads(response)
        # Get the third dataset
        result =  create_Highlited_Columns(column_names, displaynames,managedcolumsvalue)
        # Return the response from the GraphQL endpoint
        return jsonify(result)
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"No Data Found. Error: {e}"}), 500
    finally:
        gc.collect()
@app.route('/getManagedColumns', methods=['POST'])
def getManagedColumns():
    #Get the inputs from the request
    orderType = request.json.get('orderType')
    orderValue= request.json.get('orderValue')
    region= request.json.get('region')

    if (orderType =="FulfillmentId"):
        orderType = "fulfillmentId"
    elif (orderType =="SalesOrder"):
        orderType ="soNumber"
    
    try:
        soandss=  getsoandffid(orderType,orderValue,region) 
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred. Error: {e}"}), 500
      
    if  (soandss['salesOrderId'] is None):
        return jsonify({"error": "Sales Order not found In OOE"}), 404      
    salesOrderId = soandss['salesOrderId']
    fulfillmentId = soandss['fulfillmentId']
    url =   geturlfromconfig('SO_Header',region)
    try:
       
        jsonresponse =  managed_Columns_details(salesOrderId,fulfillmentId,region)
        extracted_data =  extract_keys_values(jsonresponse)
        response = db.GetMasterDataconfigDetails('getManagedColumns')
        # Get the data from the response    
        response = response['column_data']
        displaynames = json.loads(response) 
        # resp=log_response_time(response)
        return jsonify({
        'columnDetails': displaynames,
        'resultSet': {"managed_Columns":[extracted_data]}
        # 'logs' : {resp}
    })
    except requests.exceptions.RequestException as e:
      return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500
    finally:
        gc.collect()      

def extract_keys_values(data):
    result = {}
    def recursive_extract(data):
        if isinstance(data, dict):
            for key, value in data.items():
                if isinstance(value, dict) or isinstance(value, list):
                    recursive_extract(value)
                else:
                    result[key] = value
        elif isinstance(data, list):
            for item in data:
                recursive_extract(item)
    
    recursive_extract(data)
    return result


@app.route('/getListofWOPayload', methods=['POST'])
def GetListofWOPayload():
    input = request.json.get('input')
    identifier_type = request.json.get('identifier_type')
    region = request.json.get('region')
    if input is None:
        return jsonify({"error": "WO_iD is required"}), 400
    url =  geturlfromconfig('CM_ListPayload',region)
    try:
        payload = {
            "entityType":"woId",
            "entityValue": input
        }
        response = requests.get(url, json=payload, verify=False)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        logging.error(f"An error occurred: {e}")
        return jsonify({"error": "Error while making the request"}), 500
    finally:
        gc.collect()
    
@app.route('/getActualWOPayload', methods=['POST'])
def GetActualWOPayload():
    input = request.json.get('input')
    msgTxt_type = request.json.get('msgTxt_type')
    region=request.json.get('region')
    if input is None:
        return jsonify({"error": "payload is required"}), 400
    region = request.json.get('region')
    url =  geturlfromconfig('CM_Payload',region)
    try:
        payload = {"payloadType": msgTxt_type, "woId": input}
        response = requests.get(url, json=payload, verify=False)
        response.raise_for_status()  # Raise an HTTPError for bad responses (4xx and 5xx)
        response_data = response.json()
        if response_data is None:
            return jsonify({"error": "Invalid JSON response"}), 500
        payload = response_data
        if payload is None:
            return jsonify({"error": "Error while making the request"}), 500
        return payload

    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")
        return jsonify({"error": "Error occurred during request"}), 500
    finally:
        gc.collect()

@app.route('/getWOSLILogs', methods=['POST'])
def getWOSLILogs():
    input = request.json.get('input')
    identifier_type = request.json.get('identifier_type')
    region = request.json.get('region')
    if input is None:
        return jsonify({"error": "payload is required"}), 400
    url =  geturlfromconfig('CM_SLILogs',region)
    try:
        payload = {
            "entityType": identifier_type,
            "entityValue": input
        }
        response = requests.get(url, json=payload, verify=False)
        response.raise_for_status()  # Raise an HTTPError for bad responses (4xx and 5xx)
        response_data = response.json()
        if response_data is None:
            return jsonify({"error": "Invalid JSON response"}), 500
        payload = response_data
        if payload is None:
            return jsonify({"error": "Error while making the request"}), 500
        return payload

    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")
        return jsonify({"error": "Error occurred during request"}), 500
    finally:
        gc.collect()

@app.route('/getStableEventbasedonWO', methods=['POST'])
def getStableEventbasedonWO():
    order_id = request.json.get('order_id')
    region = request.json.get('region')
    
    url =  geturlfromconfig('CM_Stable_ListPayload',region)
    url = f"{url}{order_id}"
    try:
        response = requests.get(url,verify=False)
        response.raise_for_status()  # Raise an HTTPError for bad responses (4xx and 5xx)
        response_data = response.json()
        if response_data is None:
            return jsonify({"error": "Invalid JSON response"}), 500
        payload = response_data
        if payload is None:
            return jsonify({"error": "Error while making the request"}), 500
        return payload

    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")
        return jsonify({"error": "Error occurred during request"}), 500
    finally:    
        gc.collect()
@app.route('/getActualStablePayload', methods=['POST'])
def getActualStablePayload():
    payload = request.json.get('payload')
    region=request.json.get('region')
    if payload is None:
        return jsonify({"error": "payload is required"}), 400
    region = request.json.get('region')
    url =  geturlfromconfig('CM_Stable_Payload',region)
    try:
        response = requests.get(url, json=payload, verify=False)
        response.raise_for_status()  # Raise an HTTPError for bad responses (4xx and 5xx)
        response_data = response.json()
        if response_data is None:
            return jsonify({"error": "Invalid JSON response"}), 500
        payload = response_data
        if payload is None:
            return jsonify({"error": "Error while making the request"}), 500
        return payload
    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")
        return jsonify({"error": "Error occurred during request"}), 500
    finally:    
        gc.collect()
#Region WO
@app.route('/getWODrilldownDetails', methods=['POST'])
def getWODrilldownDetails():
    # Get the inputs from the request
    region = request.json.get('region')

    workOrderId = request.json.get('workOrderId')
    response =  getWorkOrderDrilldownDetails(workOrderId, region)
    return response

@app.route('/getWOheader', methods=['POST'])
def getWOheader():
    # Get the inputs from the request
    workOrderId = request.json.get('workOrderId')
    region = request.json.get('region')
    responce =  getWorkOrderheaderDetails(workOrderId, region)
    return responce

def merge_fields(*args):
    """
    Merge the fields from multiple datasets (lists of fields) into a single list.
    
    Args:
        *args: Multiple lists of fields.
    
    Returns:
        list: A list of unique fields from all the datasets.
    """
    
    # Initialize an empty set to store unique fields
    merged_set = set()
    
    # Check if any dataset is provided and raise an exception if not
    if not args:
        raise ValueError("At least one dataset is required.")
    
    # Iterate over each dataset (list of fields)
    for fields in args:
        # Check if the fields is a list or None
        if not isinstance(fields, list) and fields is not None:
            raise TypeError("Fields must be a list or None, not {}".format(type(fields)))
        
        # Check if the fields is a list and has any elements
        if isinstance(fields, list) and fields:
            # Convert the list to a set and update the merged_set
            merged_set.update(fields)
    
    # Convert the merged set back to a list
    merged_list = list(merged_set)
    return merged_list

def map_datasetswithcolumnames(column_names, displaynames, managedcolumsvalue):
    # Create a dictionary from dataset3 for quick lookup
    data_dict = {}
    for item in managedcolumsvalue:
        for key, value in item.items():
            if isinstance(value, list):
                for sub_item in value:
                    if isinstance(sub_item, dict):
                        data_dict.update(sub_item)
            elif isinstance(value, dict):
                data_dict.update(value)

    # Create the fourth dataset
    finallist = []
    for dbname in column_names:
        for item in displaynames:
            if item.get("columnsname", "").replace(" ", "").lower() == dbname.lower():
                mapped_item = {
                    "displayname": item.get("displayname"),
                    "dbname": dbname,
                    "sequence": item.get("sequence")
                }
                if dbname in data_dict:
                    mapped_item["value"] = data_dict.get(dbname, "")
                finallist.append(mapped_item)
                break
    return finallist

def flatten_json(json_obj):
    flat_dict = {}

    def flatten(item, parent_key=''):
        if isinstance(item, dict):
            for key, value in item.items():
                new_key = key if parent_key else key
                flatten(value, new_key)
        elif isinstance(item, list):
            for value in item:
                flatten(value, parent_key)
        else:
            flat_dict[parent_key] = item

    flatten(json_obj)
    return flat_dict

def merge_json_objects(obj1, obj2):
    if obj1 is None:
        return obj2 if obj2 is not None else {}
    if obj2 is None:
        return obj1

    merged_obj = obj1.copy()  # Create a copy of the first object
    merged_obj.update(obj2)   # Update the copy with the second object
    return merged_obj

# Function to extract key-value pairs from nested JSON
def merge_json(json1, json2):
    #print(  json1, json2)
    # Extract key-value pairs from json1
    json1_flat = {}
    for key, value in json1[0].items():
        if isinstance(value, list):
            for item in value:
                json1_flat.update(item)
        else:
            json1_flat[key] = value

    # Extract key-value pairs from json2
    json2_flat = {}
    for item in json2:
        json2_flat.update(item)

    # Merge the two dictionaries
    merged_json = {**json1_flat, **json2_flat}
    return [merged_json]
# Print the merged key-value pairs
def merge_json_column_with_displaynames(column_names, displaynames):
    merged_data = []

    for column in column_names:
        for display in displaynames:
            if display['columnsname'] == column:
                merged_data.append(display)
                break

    return merged_data

def getfulfillmentIdBysofulfillmentIdHC_query(salesOrderId, fulfillmentId,fields):

    # Construct the fields part of the query
    fields_str = ' '.join(fields)

    # Construct the full query
    query = f"""
    query getFulfillmentByRef {{
        getFulfillmentsBysofulfillmentid(salesOrderId: "{salesOrderId}", fulfillmentId: "{fulfillmentId}") {{
            {fields_str}
        }}
    }}
    """
    return query

def getfulfillmentIdBysoRefHC_query(salesOrderRef,fields):

    # Construct the fields part of the query
    fields_str = ' '.join(fields)

    # Construct the full query
    query = f"""
    query getFulfillmentByRef {{
        getFulfillmentByRef(salesOrderRef: "{salesOrderRef}") {{
            {fields_str}
        }}
    }}
    """

    return query

def getAsnHeaderInfoById(shipFromVendorId, sourceManifestId):

    query = f"""
    query MyQuery {{
    getAsnHeaderById(shipFromVendorId: "{shipFromVendorId}", sourceManifestId: "{sourceManifestId}") {{
        sourceManifestId
        createDate
        manifestStatusCode
        shipFromVendorSiteId
        shipToVendorSiteId
        shipToVendorId
        shipMode
        snRef
        scac
        }}
    }}
    """
    region = request.json.get('region')
    url = geturlfromconfig('ASNODM',region)
    try:
         # Construct the full query
        json_response = requests.post(
            url,
            json={'query': query},
            verify=False  # Disable SSL verification for GE4elopment purposes
        )
         # Get the data from the response    
        result = json_response.json()
        # Check for errors in the response
        if result.get('data') is None:
            error_message = result.get('errors', [{'message': 'Unknown error occurred'}])[0].get('message')
            return jsonify({"error": error_message}), 404
        result = json_response.json()['data']['getAsnHeaderById']
        return result
    
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500
   
def get_field_names(json_structure):
    field_names = []

    def extract_fields(structure):
        if isinstance(structure, list):
            for item in structure:
                extract_fields(item)
        elif isinstance(structure, dict):
            for key, value in structure.items():
                if isinstance(value, (dict, list)):
                    extract_fields(value)
                else:
                    field_names.append(key)
        else:
            field_names.append(structure)

    extract_fields(json_structure)
    return field_names

def get_column_names(json_structure):
    column_names = []
    for item in json_structure:
        if '{' in item and '}' in item:
            main_key, sub_keys = item.split('{')
            sub_keys = sub_keys.strip(' }').split(',')
            column_names.append(main_key.strip())
            column_names.extend([sub_key.strip() for sub_key in sub_keys])
        else:
            column_names.append(item.strip())
    return column_names

@app.route('/GetSchemaDetails', methods=['POST'])
def get_graphql_schema(api_url):
    query = """
    {
      __schema {
        types {
          name
          kind
          description
          fields {
            name
            description
            args {
              name
              type {
                name
                kind
              }
              defaultValue
            }
            type {
              name
              kind
            }
          }
        }
      }
    }
    """
    
    response = requests.post(api_url, json={'query': query})
    return response.json()

@app.route('/GetSchema', methods=['POST'])
def GetSchema():
    # Fetch the schema details
    query = request.json.get('query', None)

    graphql_endpoint = request.json.get('GRAPHQL_ENDPOINT', None)
    graphql_endpoint =  config[graphql_endpoint]
    if not graphql_endpoint:
        return jsonify({"error": "GRAPHQL_ENDPOINT is required"}), 400

    response = requests.post(
        graphql_endpoint,
        json={'query': query},
        verify=False
    )

    # Return the response from the GraphQL endpoint
    return jsonify(response.json())

# Region: Work Order
@app.route('/workorder', methods=['POST'])
def GetWODetails():
    
    # Get the inputs from the request
    workOrderId = request.json.get('workOrderId')
    fields = request.json.get('fields', [])
    region = request.json.get('region')
    if not workOrderId:
        return jsonify({"error": "workOrderId is required"}), 400
    if not fields:
        return jsonify({"error": "fields is required"}), 400
    url = geturlfromconfig('WO_Details',region)
    # Build the query dynamically
    query = wo_query(workOrderId, fields)
    try:
        # Make the request to the GraphQL endpoint
        response = requests.post(
            url,
            json={'query': query},
            verify=False  # Disable SSL verification for GE4elopment purposes
        )
        # Check for errors in the response
        if response.json() is None:
            error_message = response.get('errors', [{'message': 'Unknown error occurred'}])[0].get('message')
            return jsonify({"error": error_message}), 404
        
        # Return the response from the GraphQL endpoint
        return jsonify(response.json()['data']['getWorkOrderById'])
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500
    finally:
        gc.collect()

@app.route('/workorderDD', methods=['POST'])
def wo_query(workOrderId, fields):
    
     # Check for null or empty input
    if not workOrderId or not fields:
        raise ValueError("Both workOrderId and fields are required")
    # Construct the fields part of the query
    fields_str = ' '.join(fields)

    # Construct the full query
    query = f"""
    query MyQuery {{
        getWorkOrderById(workOrderId: "{workOrderId}") {{
            {fields_str}
        }}
    }}
    """
    #print(query)

    return query
# End Region

@app.route('/getOrderConfiguration', methods=['POST'])
def getOrderConfiguration():
    
 # Get the inputs from the request
    region = request.json.get('region')
    salesOrderId = request.json.get('salesOrderId')
    fulfillmentId = request.json.get('fulfillmentId')
    fields = request.json.get('fields', [])
    response =  getOrderConfigurationDetails(salesOrderId, fulfillmentId,region,fields)
    return response

@app.route('/getsoheaderbyref', methods=['POST'])
def GetSoheaderByRef():
    
    #logging.info(request.json)
    region = request.json.get('region')

    # Get the inputs from the request
    soHeaderRef = request.json.get('soHeaderRef')
    fields = request.json.get('fields', [])

    if not soHeaderRef:
        return jsonify({"error": "soHeaderRef is required"}), 400
    if not fields:
        return jsonify({"error": "fields is required"}), 400

    # Build the query dynamically
    query =  getSoheaderByRef_query(soHeaderRef, fields)
    url = geturlfromconfig('SO_Header',region)

    try:
        # Make the request to the GraphQL endpoint
        response = requests.post(
            url,
            json={'query': query},
            verify=False  # Disable SSL verification for GE4elopment purposes
        )
        
        # Return the response from the GraphQL endpoint
        return jsonify(response.json())
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500

def getSoheaderByRef_query(salesOrderIds, fields):
    # Check for null or empty input
    if not salesOrderIds or not fields:
        raise ValueError("Both salesOrderIds and fields are required")


    # Construct the fields part of the query
    fields_str = ' '.join(fields)

    # Construct the full query
    query = f"""
    query getSoheaderBySoids {{
        getSoheaderBySoids(salesOrderIds: "{salesOrderIds}") {{
            {fields_str}
        }}
    }}
    """

    return query
@app.route('/getShipsetByRef', methods=['POST'])
def getShipsetByRef():
   
    region = request.json.get('region')

    # Get the inputs from the request
    salesOrderRef = request.json.get('salesOrderRef')
    fields = request.json.get('fields', [])

    if not salesOrderRef:
        return jsonify({"error": "salesOrderRef is required"}), 400
    if not fields:
        return jsonify({"error": "fields is required"}), 400

    # Build the query dynamically
    query =  getShipsetByRef_query(salesOrderRef, fields)
    url = geturlfromconfig('SO_Header',region)

    try:
        # Make the request to the GraphQL endpoint
        response = requests.post(
            url,
            json={'query': query},
            verify=False  # Disable SSL verification for GE4elopment purposes
        )
        
        # Return the response from the GraphQL endpoint
        return jsonify(response.json())
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500

def getShipsetByRef_query(salesOrderRef, fields):
    # Check for null or empty input
    if not salesOrderRef or not fields:
        raise ValueError("Both salesOrderRef and fields are required")

    # Construct the fields part of the query
    fields_str = ' '.join(fields)

    # Construct the full query
    query = f"""
    query getShipsetByRef {{
        getShipsetByRef(salesOrderRef: "{salesOrderRef}") {{
            {fields_str}
        }}
    }}
    """

    return query


@app.route('/getsoBom', methods=['POST'])
def getSOBomDetails():
   
    logging.info(request.json)
    
    # Get the inputs from the request
    soLineDetlRef = request.json.get('soLineDetlRef')
    fields = request.json.get('fields', [])

    if not soLineDetlRef:
        return jsonify({"error": "soLineDetlRef is required"}), 400
    if not fields:
        return jsonify({"error": "fields is required"}), 400

    # Build the query dynamically
    query = getSOBom_query(soLineDetlRef, fields)
    region = request.json.get('region')
    url = geturlfromconfig('SO_BOM',region)
    try:
        # Make the request to the GraphQL endpoint
        response = requests.post(
            url,
            json={'query': query},
            verify=False  # Disable SSL verification for GE4elopment purposes
        )
        response = response.json()
        response = response["data"]["getAllSoBomBydtlref"]
        columndata = db.GetMasterDataconfigDetails('getSOBom_query')
        columndata = columndata['column_data']
        displaynames = json.loads(columndata)
        # Return the response from the GraphQL endpoint
        return jsonify({
        'columnDetails': displaynames,
        'resultSet': response
    })
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500

def getSOBom_query(soLineDetlRef, fields):
    # Check for null or empty input
    if not soLineDetlRef or not fields:
        raise ValueError("Both soLineDetlRef and fields are required")

    # Construct the fields part of the query
    fields_str = ' '.join(fields)
    
    # Construct the full query
    query = f"""
    query getAllSoBomBydtlref {{
        getAllSoBomBydtlref(soLineDetlRef: "{soLineDetlRef}") {{
            {fields_str}
        }}
    }}
    """
    return query
    
#END OF SO HEADER API
# Function to get addressLine1 where contactType is BILLING
def get_billing_address_line1(json_response):
    addresses = json_response["data"]["getSoheaderByRef"][0]["address"]
    for address in addresses:
        for contact in address["contact"]:
            if contact["contactType"] == "BILLING":
                return address["addressLine1"]
    return None
@app.route('/getAddressDetails', methods=['POST'])
def getAddressDetails():
   
    # Get the inputs from the request
    salesOrderId = request.json.get('salesOrderId')
    fulfillmentId = request.json.get('fulfillmentId')
    region = request.json.get('region')
    response =  getCustomerDetails(salesOrderId,fulfillmentId,region)
    return response
@app.route('/getSOLineDetails', methods=['POST'])
def getSOLineDetails():
  
     # Get the inputs from the request
    salesOrderId = request.json.get('salesOrderId')
    fulfillmentId = request.json.get('fulfillmentId')
    region = request.json.get('region')
    response =  getSOLineItemDetails(salesOrderId,fulfillmentId,region)
    return response


@app.route('/getWOLineAttributesDetails', methods=['POST'])
def getWOLineAttributesDetails():
  
    # Get the inputs from the request
    workOrderId = request.json.get('workOrderId')
    region = request.json.get('region')
    response =   getWorkOrderLineAttributesDetails(workOrderId, region)
    return response

@app.route('/getWOList', methods=['POST'])
def getWOList():
  
    # Get the inputs from the request
    salesOrderId = request.json.get('salesOrderId')
    fulfillmentId = request.json.get('fulfillmentId')
    region = request.json.get('region')
    response =  getWorkOrderList(salesOrderId,fulfillmentId,region)
    return response
    
@app.route('/getAsnByFulfillmentId', methods=['POST'])
def getAsnByFulfillmentId():
   
    # Get the inputs from the request
    fulfillmentId = request.json.get('fulfillmentId')
    region = request.json.get('region')
    response =  getAsnDetailsByFulfillmentId(fulfillmentId, region)
    return response

@app.route('/getAsnByFulfillmentIdManifestHeader', methods=['POST'])
def getAsnByFulfillmentIdanifestHeader():
    fulfillmentId = request.json.get('fulfillmentId')
    region = request.json.get('region')

    # Step 1: Get initial ASN details
    initial_response = getAsnDetailsByFulfillmentId(fulfillmentId, region)
    initial_data = initial_response.get_json()

    if 'resultSet' not in initial_data:
        return jsonify({"error": "Invalid response from getAsnDetailsByFulfillmentId"}), 500

    enriched_result_set = []

    # Step 2: Enrich each record with ODM ASN details
    for record in initial_data['resultSet']:
        shipFromVendorId = record.get('shipFromVendorId')
        sourceManifestId = record.get('sourceManifestId')

        if not shipFromVendorId or not sourceManifestId:
            continue

        odm_response = getODMasnDetails(shipFromVendorId, sourceManifestId, region)
        odm_data = odm_response.get_json()

        if 'resultSet' in odm_data and isinstance(odm_data['resultSet'], list) and odm_data['resultSet']:
            odm_record = odm_data['resultSet'][0]  # Assuming one record per pair
            record['shipToVendorId'] = odm_record.get('shipToVendorId')
            record['manifestStatusCode'] = odm_record.get('manifestStatusCode')
            record['createDate'] = odm_record.get('createDate')

        enriched_result_set.append(record)

    # Step 3: Add new columns to columnDetails
    updated_columns = initial_data['columnDetails']
    new_columns = [
        {"columnsname": "shipToVendorId", "displayname": "Ship To Vendor Id", "sequence": len(updated_columns) + 1},
        {"columnsname": "manifestStatusCode", "displayname": "Manifest Status Code", "sequence": len(updated_columns) + 2},
        {"columnsname": "createDate", "displayname": "Create Date", "sequence": len(updated_columns) + 3}
    ]
    updated_columns.extend(new_columns)

    return jsonify({
        "columnDetails": updated_columns,
        "resultSet": enriched_result_set
    })


@app.route('/getASNPayload', methods=['POST'])
def getASNPayload():
  
    entityType = request.json.get('entityType')
    entityValue = request.json.get('entityValue')
    region = request.json.get('region')
    response = getASNPayloadDetails(entityType, entityValue, region)
    return response

@app.route('/getAsnByWorkOrderId', methods=['POST'])
def getAsnByWOId():
    
    # Get the inputs from the request
    workorderId = request.json.get('fulfillmentId')
    region = request.json.get('region')
   
    if not workorderId:
        return jsonify({"error": "WorkorderId is required"}), 400
    
    url = geturlfromconfig('ASNODM',region)
    try:
         # Construct the full query
        response = db.GetMasterDataconfigDetails('getAsnByFulfillmentId')
        response = response['query_data']
        query = response % (workorderId)
        json_response = requests.post(
            url,
            json={'query': query},
            verify=False  # Disable SSL verification for GE4elopment purposes
        )
         # Get the data from the response    
        result = json_response.json()
        # Check for errors in the response
        if result.get('data') is None:
            error_message = result.get('errors', [{'message': 'Unknown error occurred'}])[0].get('message')
            return jsonify({"error": error_message}), 404
        result = json_response.json()['data']['getAsnByFulfillmentId']
        fresult=[]
        for res in result:
            resp =  getAsnHeaderInfoById( res['shipFromVendorId'], res['sourceManifestId'])
            fresult.append(resp[0])
 
        return fresult
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500
@app.route('/getASNDetailsForManifestTracker', methods=['POST'])
def getASNDetailsForManifestTracker():
 
    # Get the inputs from the request
    shipFromVendorId = request.json.get('shipFromVendorId')
    sourceManifestId = request.json.get('sourceManifestId')
    region = request.json.get('region')
   
    if not shipFromVendorId:
        return jsonify({"error": "shipFromVendorId is required"}), 400
    if not sourceManifestId:
        return jsonify({"error": "sourceManifestId is required"}), 400
    
    try:
        resp =  getASNHeaderAndDetailsByASN( shipFromVendorId, sourceManifestId, region)
        return resp
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500

@app.route('/getODMasnData', methods=['POST'])
def getODMasnData():
  
    # Get the inputs from the request
    shipFromVendorId = request.json.get('shipFromVendorId')
    sourceManifestId = request.json.get('sourceManifestId')
    region = request.json.get('region')
    response =  getODMasnDetails(shipFromVendorId,sourceManifestId,region)
    return response

@app.route('/getASNDrilldownDetails', methods=['POST'])
def getASNDrilldownDetails():
  
    # Get the inputs from the request
    shipFromVendorId = request.json.get('shipFromVendorId')
    sourceManifestId = request.json.get('sourceManifestId')
    region = request.json.get('region')
    response =  getASNDrilldownData(shipFromVendorId,sourceManifestId,region)
    return response

@app.route('/getSNDetails', methods=['POST'])
def getSNDetails():
   
    # Get the inputs from the request
    region = request.json.get('region')
    snNumber = request.json.get('snNumber')
    response =  getSNDrilldownData(snNumber, region)
    return response
   
@app.route('/getSostatusHistory', methods=['POST'])
def getSostatusbySoshipsetid():
  
    # Get the inputs from the request
    salesOrderId = request.json.get('salesOrderId')
    fulfillmentId = request.json.get('fulfillmentId')
    region = request.json.get('region')
    response =  getSostatusHistory(salesOrderId,fulfillmentId,region)
    return response
def split_date_time(date_string):
    datetime_obj = parser.isoparse(date_string)
    date_part = datetime_obj.date()
    time_part = datetime_obj.time()
    return date_part, time_part

@app.route('/split_date_time', methods=['POST'])
def split_date_time_endpoint():

    data = request.json
    date_string = data.get('Date')
    if not date_string:
        return jsonify({"error": "Date is required"}), 400
    
    try:
        date, time =  split_date_time(date_string)
        return jsonify({"date": str(date), "time": str(time)})
    except ValueError:
        return jsonify({"error": "Invalid date format"}), 400
@app.route('/getShipsetsBysoshipsetid', methods=['POST'])
def getShipsetsBysoshipsetid():

    salesOrderId = request.json.get('salesOrderId')
    fulfillmentId = request.json.get('fulfillmentId')
    region = request.json.get('region')
    url = geturlfromconfig('SO_Header',region)
    # Build the query dynamically
    
    response = db.GetMasterDataconfigDetails('getShipsetsBysoshipsetid')
    response = response['query_data'] 
    query = response % (salesOrderId, fulfillmentId)

    try:
        # Make the request to the GraphQL endpoint
        response = requests.post(
            url,
            json={'query': query},
            verify=False  # Disable SSL verification for GE4elopment purposes
        )
        response = response.json()
        # Check for errors in the response
        if response.get('data') is None:
            error_message = response.get('errors', [{'message': 'Unknown error occurred'}])[0].get('message')
            return jsonify({"error": error_message}), 404
            
        order_date_query = get_payload_details_query("soNumber", region)
        variables = {
            "input": salesOrderId
        }
        url = geturlfromconfig('OOE',region)
        try:
            order_date_response = requests.post(
                url,
                json={'query': order_date_query, "variables": variables},
                verify=False  
            )
            order_date_response= order_date_response.json()
            orderDate = order_date_response['data']['envelopeQuery']['getPayloadDetails']['soEnvelopeMessage']['createDate']
            response['data']['getFulfillmentsBysofulfillmentid'][0]['fulfillments'] [0]['createDate']= orderDate

        except requests.exceptions.RequestException as e:
            return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500

        return jsonify({
            'resultSet': response
        })
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500
    
@app.route('/GetLineitems', methods=['POST'])
def GetLineitems():
 # Get the inputs from the request
    
    salesOrderId = request.json.get('salesOrderId')
    fulfillmentId = request.json.get('fulfillmentId')
    region = request.json.get('region')
    response =  getLineitemsDetails(salesOrderId, fulfillmentId,region)
    return response

@app.route('/GetPartDetails', methods=['POST'])
def GetPartDetails():

    salesOrderId = request.json.get('salesOrderId')
    fulfillmentId = request.json.get('fulfillmentId')
    region = request.json.get('region')
    fields = request.json.get('fields', [])
    response =  GetPartDetailsData(salesOrderId, fulfillmentId,region,fields)
    return response

@app.route('/GetSvcTags', methods=['POST'])
def GetSvcTags():
 
    salesOrderId = request.json.get('salesOrderId')
    fulfillmentId = request.json.get('fulfillmentId')
    region = request.json.get('region')
    response =  GetSvcTagsDetails(salesOrderId, fulfillmentId,region)
    return response
#end region
@app.route('/GetOPPAttributes', methods=['POST'])
def GetOPPAttributes():
    try:
        # Extract input parameters
        fulfillmentId = request.json.get('fulfillmentId')
        region = request.json.get('region')

        if not fulfillmentId or not region:
            return jsonify({"error": "Missing 'fulfillmentId' or 'region' in request body"}), 400

        # Call the helper function
        return getOPPAttributeDetails(fulfillmentId, region)

    except Exception as e:
        return jsonify({"error": f"Unexpected error occurred: {str(e)}"}), 500
@app.route('/getfulfillmentorderdata', methods=['POST'])
def getfulfillmentorderdata():

    # Get the inputs from the requestn  
    region = request.json.get('region')
    foId = request.json.get('foId')
    response =  getfulfillmentorderdetails(foId, region)
    return response
    

def remove_keys(data, keys_to_remove):
    if isinstance(data, dict):
        return {k: remove_keys(v, keys_to_remove) for k, v in data.items() if k not in keys_to_remove}
    elif isinstance(data, list):
        return [remove_keys(item, keys_to_remove) for item in data]
    else:
        return data

@app.route('/getInternalShipmentdata', methods=['POST'])
def getInternalShipmentdata():
 
    # Get the inputs from the requestn  
    region = request.json.get('region')
    fulfillmentId = request.json.get('fulfillmentId')
    response =  getInternalShipmentPlanData(fulfillmentId, region)
    return response

@app.route('/GetMenuMasterData', methods=['GET'])
def GetMenuMasterData():
  
    connection = db.get_db_connection(env)
    if not connection:
        return jsonify({
            'menu_masterdata': [],
            'error_code': '101',
            'error_msg': 'Failed to connect to the database'
        })
    cursor = connection.cursor()
    p_out_menu_details = cursor.var(oracledb.CURSOR)
    p_out_errorcode = cursor.var(oracledb.STRING)
    p_out_errmsg = cursor.var(oracledb.STRING)
    try:
        cursor.callproc('SVC_FDH.pkg_menu_details.prc_select_menu_master_details', [ p_out_menu_details, p_out_errorcode, p_out_errmsg])
        menu_details = p_out_menu_details.getvalue().fetchall()
        error_code = p_out_errorcode.getvalue()
        error_msg = p_out_errmsg.getvalue()
    except Exception as e:
        return jsonify({
            'menu_masterdata': [],
            'error_code': '102',
            'error_msg': 'Failed to execute the procedure. Error: ' + str(e)
        })
    finally:
        cursor.close()
        connection.close()

    res_menu = []
    for data in menu_details:
        if data is None:
            continue
        obj = {
            "menu_details": data[0],
            "email_id": data[1]
        }
        res_menu.append(obj)

    return jsonify({
        'menu_masterdata': res_menu,
        'error_code': error_code,
        'error_msg': error_msg
    })
@app.route('/GetMenuDetails', methods=['POST'])
def GetMenuDetails():
  
    data = request.json
    emailid = data.get('emailid')
    if not emailid:
        return jsonify({
            'menu_details': {},
            'error_code': '100',
            'error_msg': 'No emailid provided'
        })
    connection = db.get_db_connection(env)
    if not connection:
        return jsonify({
            'menu_details': {},
            'error_code': '101',
            'error_msg': 'Failed to connect to the database'
        })
    cursor = connection.cursor()
    p_out_menu_details = cursor.var(oracledb.CURSOR)
    p_out_errorcode = cursor.var(oracledb.STRING)
    p_out_errmsg = cursor.var(oracledb.STRING)
    try:
        cursor.callproc('SVC_FDH.pkg_menu_details.prc_select_menu_details', [emailid, p_out_menu_details, p_out_errorcode, p_out_errmsg])
        menu_details = p_out_menu_details.getvalue().fetchall()
        error_code = p_out_errorcode.getvalue()
        error_msg = p_out_errmsg.getvalue()
    except Exception as e:
        return jsonify({
            'menu_details': {},
            'error_code': '102',
            'error_msg': 'Failed to execute the procedure. Error: ' + str(e)
        })
    finally:
        cursor.close()
        connection.close()
    obj = {
        "menus": menu_details[0][0] if menu_details else [],
        "email_id": menu_details[0][1] if menu_details else emailid
    }
    return jsonify({
        'menu_details': obj,
        'error_code': error_code,
        'error_msg': error_msg
    })


@app.route('/Insert_menu_details', methods=['POST'])
def insert_menu_details():
 
    data = request.json
    menudata = data.get('menudata')
    emailid = data.get('emailid')

    if not menudata or not emailid:
        return jsonify({
            'error_code': '100',
            'error_msg': 'Null parameter provided'
        }), 400

    connection = db.get_db_connection(env)
    if not connection:
        return jsonify({
            'error_code': '101',
            'error_msg': 'Failed to connect to the database'
        }), 500

    try:
        cursor = connection.cursor()
        p_out_errorcode = cursor.var(oracledb.STRING)
        p_out_errmsg = cursor.var(oracledb.STRING)
        cursor.callproc('SVC_FDH.pkg_menu_details.prc_insert_menu_details', [
           menudata, emailid, p_out_errorcode, p_out_errmsg
        ])

        error_code = p_out_errorcode.getvalue()
        error_msg = p_out_errmsg.getvalue()
        if error_msg!="SUCCESS":
            return jsonify({
                'error_code': error_code,
                'error_msg': error_msg
            }), 500

        return jsonify({
            'error_code': '0',
            'error_msg': 'Success'
        }), 200
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

@app.route('/Update_menu_details', methods=['POST'])
def update_menu_details():
   
    data = request.json
    menudata = data.get('menudata')
    emailid = data.get('emailid')
    if not menudata or not emailid:
        return jsonify({
            'error_code': '100',
            'error_msg': 'Null parameter provided'
        }), 400

    connection = db.get_db_connection(env)
    if not connection:
        return jsonify({
            'error_code': '101',
            'error_msg': 'Failed to connect to the database'
        }), 500

    try:
        cursor = connection.cursor()
        p_out_errorcode = cursor.var(oracledb.STRING)
        p_out_errmsg = cursor.var(oracledb.STRING)
        cursor.callproc('SVC_FDH.pkg_menu_details.prc_update_menu_details', [
            menudata, emailid, p_out_errorcode, p_out_errmsg
        ])

        error_code = p_out_errorcode.getvalue()
        error_msg = p_out_errmsg.getvalue()
        if error_msg!="SUCCESS":
            return jsonify({
                'error_code': error_code,
                'error_msg': error_msg
            }), 500

        return jsonify({
            'error_code': '0',
            'error_msg': 'Success'
        }), 200
    except Exception as e:
        return jsonify({
            'error_code': '102',
            'error_msg': 'Failed to execute the procedure. Error: ' + str(e)
        }), 500
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()
@app.route('/Delete_menu_details', methods=['POST'])
def delete_menu_details():

    data = request.json
    if not data.get('emailid'):
        return jsonify({
            'error_code': '100',
            'error_msg': 'Null parameter provided'
        }), 400

    connection = db.get_db_connection(env)
    if not connection:
        return jsonify({
            'error_code': '101',
            'error_msg': 'Failed to connect to the database'
        }), 500

    try:
        cursor = connection.cursor()
        p_out_errorcode = cursor.var(oracledb.STRING)
        p_out_errmsg = cursor.var(oracledb.STRING)
        cursor.callproc('SVC_FDH.pkg_menu_details.prc_delete_menu_details', [
            data.get('emailid'), p_out_errorcode, p_out_errmsg
        ])

        error_code = p_out_errorcode.getvalue()
        error_msg = p_out_errmsg.getvalue()
        if error_msg!="SUCCESS":
            return jsonify({
                'error_code': error_code,
                'error_msg': error_msg
            }), 500

        return jsonify({
            'error_code': '0',
            'error_msg': 'Success'
        }), 200
    except Exception as e:
        return jsonify({
            'error_code': '102',
            'error_msg': 'Failed to execute the procedure. Error: ' + str(e)
        }), 500
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()
@app.route('/GetTemplateMasterData', methods=['GET'])
def GetTemplateMasterData():
    connection = db.get_db_connection(env)
    if not connection:
        return jsonify({
            'template_masterdata': [],
            'error_code': '101',
            'error_msg': 'Failed to connect to the database'
        }), 500

    try:
        cursor = connection.cursor()
        p_out_template_details = cursor.var(oracledb.CURSOR)
        p_out_errorcode = cursor.var(oracledb.STRING)
        p_out_errmsg = cursor.var(oracledb.STRING)
        cursor.callproc('SVC_FDH.pkg_template_details.prc_select_template_master_details', [ p_out_template_details, p_out_errorcode, p_out_errmsg])

        template_details = p_out_template_details.getvalue().fetchall()
        error_code = p_out_errorcode.getvalue()
        error_msg = p_out_errmsg.getvalue()

        return jsonify({
            'template_masterdata': template_details,
            'error_code': error_code,
            'error_msg': error_msg
        })
    except Exception as e:
        return jsonify({
            'template_masterdata': [],
            'error_code': '102',
            'error_msg': 'Failed to execute the procedure. Error: ' + str(e)
        }), 500
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

@app.route('/GetAllDomainTabularDetails', methods=['POST'])
def GetAllDomainTabularDetails():
    input_json = request.get_json()
    if not input_json or not input_json.get("domain"):
        return jsonify({"error": "Missing or empty required field: domain"}), 400

    domain_name = input_json["domain"]
    
    connection = db.get_db_connection(env)
    if not connection:
        return jsonify({
            'tabular_details': [],
            'error_code': '101',
            'error_msg': 'Failed to connect to the database'
        }), 500

    try:
        cursor = connection.cursor()
        p_out_tabluar_details = cursor.var(oracledb.CURSOR)
        p_out_success = cursor.var(oracledb.NUMBER)
        p_out_errormsg = cursor.var(oracledb.STRING)

        cursor.callproc(
            'svc_fdh.pkg_eoe_domain_matrix.prc_alldomain_tabluar_details',
            [p_out_tabluar_details, p_out_success, p_out_errormsg]
        )

        
        headers = [desc[0] for desc in p_out_tabluar_details.getvalue().description]
        rows = p_out_tabluar_details.getvalue().fetchall()
        
        # Filter rows based on domain_name
        
        filtered_rows = [row for row in rows if row[0].lower() == domain_name.lower()]


        status = int(p_out_success.getvalue())
        errmsg = p_out_errormsg.getvalue()

        return jsonify({
            'headers':headers,
            'tabular_details': filtered_rows,
            'error_code': str(status),
            'error_msg': errmsg or ''
        })

    except Exception as e:
        return jsonify({
            'tabular_details': [],
            'error_code': '102',
            'error_msg': f'Failed to execute procedure: {e}'
        }), 500

    finally:
        cursor.close()
        connection.close()

@app.route('/GetTemplateDetails', methods=['POST'])
def GetTemplateDetails():
    data = request.json
    emailid = data.get('emailid')
    if not emailid:
        return jsonify({
            'template_details': [],
            'error_code': '100',
            'error_msg': 'Email id is required'
        }), 400

    try:
        connection = db.get_db_connection(env)
        cursor = connection.cursor()
        p_out_template_details = cursor.var(oracledb.CURSOR)
        p_out_errorcode = cursor.var(oracledb.STRING)
        p_out_errmsg = cursor.var(oracledb.STRING)
        cursor.callproc('SVC_FDH.pkg_template_details.prc_select_template_details', [emailid, p_out_template_details, p_out_errorcode, p_out_errmsg])

        # Fetch the values from the cursor
        template_details = p_out_template_details.getvalue().fetchall()
        error_code = p_out_errorcode.getvalue()
        error_msg = p_out_errmsg.getvalue()
    except oracledb.DatabaseError as e:
        return jsonify({
            'template_details': [],
            'error_code': '101',
            'error_msg': 'Failed to connect to the database. Error: ' + str(e)
        }), 500
    except Exception as e:
        return jsonify({
            'template_details': [],
            'error_code': '102',
            'error_msg': 'Failed to execute the procedure. Error: ' + str(e)
        }), 500
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

    return jsonify({
        'template_details': template_details,
        'error_code': error_code,
        'error_msg': error_msg
    })
@app.route('/Insert_template_details', methods=['POST'])
def Insert_template_details():
    data = request.json

    # Check for required parameters
    if not data.get('templatename') or not data.get('templatedata') or not data.get('mfename') or not data.get('emailid') or not data.get('defaultflag'):
        return jsonify({
            'error_code': '100',
            'error_msg': 'Null parameter provided'
        }), 400

    try:
        connection = db.get_db_connection(env)
        cursor = connection.cursor()
        p_out_errorcode = cursor.var(oracledb.STRING)
        p_out_errmsg = cursor.var(oracledb.STRING)
        cursor.callproc('SVC_FDH.pkg_template_details.prc_insert_template_details', [
            data.get('templatename'), data.get('templatedata'), data.get('mfename'), data.get('emailid'), data.get('defaultflag'), p_out_errorcode, p_out_errmsg
        ])

        error_code = p_out_errorcode.getvalue()
        error_msg = p_out_errmsg.getvalue()
    except oracledb.DatabaseError as e:
        return jsonify({
            'error_code': '101',
            'error_msg': 'Failed to connect to the database. Error: ' + str(e)
        }), 500
    except Exception as e:
        return jsonify({
            'error_code': '102',
            'error_msg': 'Failed to execute the procedure. Error: ' + str(e)
        }), 500
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

    return jsonify({
        'error_code': error_code,
        'error_msg': error_msg
    })

@app.route('/Update_template_details', methods=['POST'])
def update_template_details():
    data = request.json
    if not data.get('templatename') or not data.get('templatedata') or not data.get('mfename') or not data.get('emailid') or not data.get('defaultflag'):
        return jsonify({
            'error_code': '100',
            'error_msg': 'Null parameter provided'
        }), 400
    try:
        connection = db.get_db_connection(env)
        if not connection:
            return jsonify({
                'error_code': '101',
                'error_msg': 'Failed to connect to the database'
            }), 500
        cursor = connection.cursor()
        p_out_errorcode = cursor.var(oracledb.STRING)
        p_out_errmsg = cursor.var(oracledb.STRING)
        cursor.callproc('SVC_FDH.pkg_template_details.prc_update_template_details', [
            data.get('templatename'), data.get('templatedata'),
            data.get('mfename'), data.get('emailid'),
            data.get('defaultflag'), p_out_errorcode, p_out_errmsg
        ])
        error_code = p_out_errorcode.getvalue()
        error_msg = p_out_errmsg.getvalue()
        cursor.close()
        connection.close()
        return jsonify({
            'error_code': error_code,
            'error_msg': error_msg
        })
    except oracledb.DatabaseError as e:
        return jsonify({
            'error_code': '101',
            'error_msg': 'Failed to connect to the database. Error: ' + str(e)
        }), 500
    except Exception as e:
        return jsonify({
            'error_code': '102',
            'error_msg': 'Failed to execute the procedure. Error: ' + str(e)
        }), 500
@app.route('/Delete_template_details', methods=['POST'])
def delete_template_details():
    data = request.json
    if not data.get('templatename') or not data.get('emailid') or not data.get('mfename'):
        return jsonify({
            'error_code': '100',
            'error_msg': 'Null parameter provided'
        }), 400
    try:
        connection = db.get_db_connection(env)
        if not connection:
            return jsonify({
                'error_code': '101',
                'error_msg': 'Failed to connect to the database'
            }), 500
        cursor = connection.cursor()
        p_out_errorcode = cursor.var(oracledb.STRING)
        p_out_errmsg = cursor.var(oracledb.STRING)
        cursor.callproc('SVC_FDH.pkg_template_details.prc_delete_template_details', [
            data.get('templatename'), data.get('emailid'), data.get('mfename'),
            p_out_errorcode, p_out_errmsg
        ])

        error_code = p_out_errorcode.getvalue()
        error_msg = p_out_errmsg.getvalue()
        cursor.close()
        connection.close()
        return jsonify({
            'error_code': error_code,
            'error_msg': error_msg
        })
    except oracledb.DatabaseError as e:
        return jsonify({
            'error_code': '101',
            'error_msg': 'Failed to connect to the database. Error: ' + str(e)
        }), 500
    except Exception as e:
        return jsonify({
            'error_code': '102',
            'error_msg': 'Failed to execute the procedure. Error: ' + str(e)
        }), 500
#USER PREFERENCES
@app.route('/GetUserPrefMasterData', methods=['GET'])
def GetUserPrefMasterData():

    try:
        connection = db.get_db_connection(env)
        if not connection:
            return jsonify({
                'user_pref_masterdata': {},
                'error_code': '101',
                'error_msg': 'Failed to connect to the database'
            }), 500
        cursor = connection.cursor()
        p_out_user_pref_details = cursor.var(oracledb.CURSOR)
        p_out_errorcode = cursor.var(oracledb.STRING)
        p_out_errmsg = cursor.var(oracledb.STRING)
        cursor.callproc('svc_fdh.pkg_user_pref_details.prc_select_user_pref_master_details', [ p_out_user_pref_details, p_out_errorcode, p_out_errmsg])
        
        # Fetch the values from the cursor
        user_pref_details = p_out_user_pref_details.getvalue().fetchall()
        error_code = p_out_errorcode.getvalue()
        error_msg = p_out_errmsg.getvalue()
        
        parsed_data = []
        for row in user_pref_details:
            if row[0]:
                user_pref_string = row[0].read()
                try:
                    parsed_data.append(json.loads(user_pref_string))
                except json.JSONDecodeError:
                    return jsonify({
                        'user_pref_masterdata': {},
                        'error_code': '103',
                        'error_msg': 'Failed to parse JSON string'
                    }), 500
        cursor.close()
        connection.close()
        return jsonify({
            'user_pref_masterdata': parsed_data,
            'error_code': error_code,
            'error_msg': error_msg
        })
    except oracledb.DatabaseError as e:
        return jsonify({
            'user_pref_masterdata': {},
            'error_code': '101',
            'error_msg': 'Failed to connect to the database. Error: ' + str(e)
        }), 500
    except Exception as e:
        return jsonify({
            'user_pref_masterdata': {},
            'error_code': '102',
            'error_msg': 'Failed to execute the procedure. Error: ' + str(e)
        }), 500
@app.route('/GetUserPrefDetails', methods=['POST'])
def GetUserPrefDetails():

    data = request.json
    emailid = data.get('emailid')
    if not emailid:
        return jsonify({
            'user_pref_data': {},
            'error_code': '100',
            'error_msg': 'No emailid provided'
        }), 400

    try:
        connection = db.get_db_connection(env)
        if not connection:
            return jsonify({
                'user_pref_data': {},
                'error_code': '101',
                'error_msg': 'Failed to connect to the database'
            }), 500
        cursor = connection.cursor()
        p_out_user_pref_details = cursor.var(oracledb.CURSOR)
        p_out_errorcode = cursor.var(oracledb.STRING)
        p_out_errmsg = cursor.var(oracledb.STRING)
        try:
            cursor.callproc('svc_fdh.pkg_user_pref_details.prc_select_user_pref_details', [emailid, p_out_user_pref_details, p_out_errorcode, p_out_errmsg])

            # Fetch the values from the cursor
            user_pref_details = p_out_user_pref_details.getvalue().fetchall()
            error_code = p_out_errorcode.getvalue()
            error_msg = p_out_errmsg.getvalue()
            parsed_data = {}
            for row in user_pref_details:
                if row:
                    user_pref_object = row[0]
                    user_pref_string = user_pref_object.read()
                    parsed_data = json.loads(user_pref_string)
        except Exception as e:
            return jsonify({
                'user_pref_data': {},
                'error_code': '102',
                'error_msg': 'Failed to execute the procedure. Error: ' + str(e)
            }), 500
        finally:
            cursor.close()
            connection.close()
    except Exception as e:
        return jsonify({
            'user_pref_data': {},
            'error_code': '103',
            'error_msg': 'Unknown error. Error: ' + str(e)
        }), 500

    return jsonify({
        'user_pref_data': parsed_data,
        'error_code': error_code,
        'error_msg': error_msg
    })

@app.route('/Insert_user_pref_details', methods=['POST'])
def Insert_user_pref_details():
 
    data = request.json
    user_pref_data = data.get('user_pref_data')
    emailid = data.get('emailid')

    if not user_pref_data or not emailid:
        return jsonify({
            'error_code': '100',
            'error_msg': 'Null parameter provided'
        }), 400

    try:
        connection = db.get_db_connection(env)
        if not connection:
            return jsonify({
                'error_code': '101',
                'error_msg': 'Failed to connect to the database'
            }), 500

        cursor = connection.cursor()
        p_out_errorcode = cursor.var(oracledb.STRING)
        p_out_errmsg = cursor.var(oracledb.STRING)
        try:
            cursor.callproc('svc_fdh.pkg_user_pref_details.prc_insert_user_pref_details', [
                user_pref_data, emailid, p_out_errorcode, p_out_errmsg
            ])

            error_code = p_out_errorcode.getvalue()
            error_msg = p_out_errmsg.getvalue()
        except:
            return jsonify({
                'error_code': '102',
                'error_msg': 'Failed to execute the procedure'
            }), 500
        finally:
            cursor.close()
            connection.close()

        return jsonify({
            'error_code': error_code,
            'error_msg': error_msg
        })
    except:
        return jsonify({
            'error_code': '103',
            'error_msg': 'Unknown error'
        }), 500

@app.route('/Update_user_pref_details', methods=['POST'])
def Update_user_pref_details():
  
    data = request.json
    if not data.get('user_pref_data') or not data.get('emailid'):
        return jsonify({
            'error_code': '100',
            'error_msg': 'Null parameter provided'
        }), 400

    try:
        connection = db.get_db_connection(env)
        if not connection:
            return jsonify({
                'error_code': '101',
                'error_msg': 'Failed to connect to the database'
            }), 500

        cursor = connection.cursor()
        p_out_errorcode = cursor.var(oracledb.STRING)
        p_out_errmsg = cursor.var(oracledb.STRING)
        try:
            cursor.callproc('svc_fdh.pkg_user_pref_details.prc_update_user_pref_details', [
                data.get('user_pref_data'), data.get('emailid'), p_out_errorcode, p_out_errmsg
            ])

            error_code = p_out_errorcode.getvalue()
            error_msg = p_out_errmsg.getvalue()
        except Exception as e:
            return jsonify({
                'error_code': '102',
                'error_msg': 'Failed to execute the procedure. Error: ' + str(e)
            }), 500
        finally:
            cursor.close()
            connection.close()

        return jsonify({
            'error_code': error_code,
            'error_msg': error_msg
        })
    except Exception as e:
        return jsonify({
            'error_code': '103',
            'error_msg': 'Unknown error. Error: ' + str(e)
        }), 500


@app.route('/UpdateLastSeen', methods=['POST'])
def UpdateLastSeen():

    data = request.json
    user_id = data.get('email_id')

    if not user_id:
        return jsonify({
            'message': 'User ID is required',
            'error_code': '100'
        }), 400

    try:
        connection = db.get_db_connection(env)
        if not connection:
            return jsonify({
                'message': 'Failed to connect to the database',
                'error_code': '101'
            }), 500

        cursor = connection.cursor()
        try:
            merge_query = """
                MERGE INTO svc_fdh.users_active_sessions uas
                USING (SELECT :user_id AS v_user_id, SYSTIMESTAMP AS v_last_seen FROM dual) d
                ON (d.v_user_id = uas.user_id)
                WHEN MATCHED THEN
                    UPDATE SET uas.last_seen = d.v_last_seen,
                               updated_by = 'SVC_FDH',
                               updated_ts = SYSTIMESTAMP
                WHEN NOT MATCHED THEN
                    INSERT (user_id, last_seen)
                    VALUES (d.v_user_id, d.v_last_seen)
            """
            cursor.execute(merge_query, {'user_id': user_id})
            connection.commit()
        except Exception as e:
            return jsonify({
                'message': f'Failed to update last_seen: {str(e)}',
                'error_code': '102'
            }), 500
        finally:
            cursor.close()
            connection.close()
    except Exception as e:
        return jsonify({
            'message': f'Unexpected error: {str(e)}',
            'error_code': '103'
        }), 500

    return jsonify({
        'message': 'last_seen updated successfully',
        'error_code': '0'
    }), 200


@app.route('/GetActiveUsers', methods=['GET'])
def GetActiveUsers():

    try:
        connection = db.get_db_connection(env)
        if not connection:
            return jsonify({
                'message': 'Failed to connect to the database',
                'error_code': '101',
                'active_user_count': 0
            }), 500

        cursor = connection.cursor()
        try:
            query = """
                SELECT count(*) FROM svc_fdh.users_active_sessions a
                WHERE cast(a.last_seen as timestamp) at time zone 'UTC' >= cast(SYSTIMESTAMP as timestamp) 
                at time zone 'UTC' - INTERVAL '5' MINUTE
            """
            cursor.execute(query)
            count = cursor.fetchone()[0]

        except Exception as e:
            return jsonify({
                'message': f'Failed to fetch active user count: {str(e)}',
                'error_code': '102',
                'active_user_count': 0
            }), 500
        finally:
            cursor.close()
            connection.close()

    except Exception as e:
        return jsonify({
            'message': f'Unexpected error: {str(e)}',
            'error_code': '103',
            'active_user_count': 0
        }), 500

    return jsonify({
        'message': 'Active user count fetched successfully',
        'error_code': '0',
        'active_user_count': count
    }), 200


@app.route('/Delete_user_pref_details', methods=['POST'])
def Delete_user_pref_details():
    data = request.json
    if not data.get('emailid'):
        return jsonify({
            'error_code': '100',
            'error_msg': 'No emailid provided'
        }), 400
    try:
        connection = db.get_db_connection(env)
        if not connection:
            return jsonify({
                'error_code': '101',
                'error_msg': 'Failed to connect to the database'
            }), 500
        cursor = connection.cursor()
        p_out_errorcode = cursor.var(oracledb.STRING)
        p_out_errmsg = cursor.var(oracledb.STRING)
        try:
            cursor.callproc('svc_fdh.pkg_user_pref_details.prc_delete_user_pref_details', [
                data.get('emailid'), p_out_errorcode, p_out_errmsg
            ])
            error_code = p_out_errorcode.getvalue()
            error_msg = p_out_errmsg.getvalue()
        except oracledb.DatabaseError as e:
            return jsonify({
                'error_code': '101',
                'error_msg': 'Failed to connect to the database. Error: ' + str(e)
            }), 500
        except Exception as e:
            return jsonify({
                'error_code': '102',
                'error_msg': 'Failed to execute the procedure. Error: ' + str(e)
            }), 500
        finally:
            cursor.close()
            connection.close()
        return jsonify({
            'error_code': error_code,
            'error_msg': error_msg
        })
    except Exception as e:
        return jsonify({
            'error_code': '103',
            'error_msg': 'Unknown error. Error: ' + str(e)
        }), 500


@app.route('/GetFilterValues', methods=['POST'])
def getFilterValues():

    data = request.json
    p_in_page_name = data.get('pageName')
    connection = db.get_db_connection(env)
    cursor = connection.cursor()
    p_out_filter_details = cursor.var(oracledb.CURSOR)
    p_out_errorcode = cursor.var(oracledb.STRING)
    p_out_errmsg = cursor.var(oracledb.STRING)

    cursor.callproc('svc_fdh.pkg_OrderSummary_details.prc_select_filter_details', [
        p_in_page_name, p_out_filter_details, p_out_errorcode, p_out_errmsg
    ])

    filter_details = p_out_filter_details.getvalue().fetchall()
    error_code = p_out_errorcode.getvalue()
    error_msg = p_out_errmsg.getvalue()

    return jsonify({
        'filter_details': filter_details,
        'error_code': error_code,
        'error_msg': error_msg
    })

    # product onboard Screen details
@app.route('/GetRequestDetails', methods=['GET'])
def GetRequestDetails():
    connection = db.get_db_connection(env=env)
    cursor = connection.cursor()
    p_out_request_details = cursor.var(oracledb.CURSOR)
    p_out_errorcode = cursor.var(oracledb.STRING)
    p_out_errmsg = cursor.var(oracledb.STRING)

    cursor.callproc('svc_fdh.pkg_product_onboard_details.prc_select_requset_status_details', [
        p_out_request_details, p_out_errorcode, p_out_errmsg
    ])

    request_details = p_out_request_details.getvalue().fetchall()
    error_code = p_out_errorcode.getvalue()
    error_msg = p_out_errmsg.getvalue()

    return jsonify({
        'request_details': request_details,
        'error_code': error_code,
        'error_msg': error_msg
    })


# product onboard Screen details - to get sequence Request ID
@app.route('/GetRequestIDDetails', methods=['GET'])
def GetRequestIDDetails():

    connection = db.get_db_connection(env=env)
    cursor = connection.cursor()
    p_out_request_id_details = cursor.var(oracledb.CURSOR)
    p_out_errorcode = cursor.var(oracledb.STRING)
    p_out_errmsg = cursor.var(oracledb.STRING)

    cursor.callproc('svc_fdh.pkg_product_onboard_details.prc_select_requset_id_details', [
        p_out_request_id_details, p_out_errorcode, p_out_errmsg
    ])

    request_id_details = p_out_request_id_details.getvalue().fetchall()
    error_code = p_out_errorcode.getvalue()
    error_msg = p_out_errmsg.getvalue()

    return jsonify({
        'request_id_details': request_id_details,
        'error_code': error_code,
        'error_msg': error_msg
    })


# product onboard Screen details - to get Request ID details in Update Pop up
@app.route('/GetRequestIDPopupDtls', methods=['POST'])
def GetRequestIDPopupDtls():
   
    data = request.json
    userid = data.get('userid')
    connection = db.get_db_connection(env=env)
    cursor = connection.cursor()
    p_out_request_id = cursor.var(oracledb.CURSOR)
    p_out_errorcode = cursor.var(oracledb.STRING)
    p_out_errmsg = cursor.var(oracledb.STRING)

    cursor.callproc('svc_fdh.pkg_product_onboard_details.prc_requset_id_popup_dtls', [
        userid, p_out_request_id, p_out_errorcode, p_out_errmsg
    ])

    request_id_popup_dtls = p_out_request_id.getvalue().fetchall()
    error_code = p_out_errorcode.getvalue()
    error_msg = p_out_errmsg.getvalue()

    return jsonify({
        'request_id_popup_dtls': request_id_popup_dtls,
        'error_code': error_code,
        'error_msg': error_msg
    })


# insert onborad details - Product Onboard screen

@app.route('/Insert_onboard_details', methods=['POST'])
def Insert_onboard_details():
    data = request.json
    userid = data.get('userid')
    requestid = data.get('requestid')
    mfename = data.get('mfename')
    interlockproduct = data.get('interlockproduct')
    interlockpoc = data.get('interlockpoc')
    interlockmodule = data.get('interlockmodule')
    description = data.get('description')

    connection = db.get_db_connection(env=env)
    cursor = connection.cursor()
    p_out_errorcode = cursor.var(oracledb.STRING)
    p_out_errmsg = cursor.var(oracledb.STRING)

    cursor.callproc('svc_fdh.pkg_product_onboard_details.prc_insert_onboard_details', [
        userid, requestid, mfename, interlockproduct, interlockpoc, interlockmodule, description,
        p_out_errorcode, p_out_errmsg
    ])

    error_code = p_out_errorcode.getvalue()
    error_msg = p_out_errmsg.getvalue()

    return jsonify({
        'error_code': error_code,
        'error_msg': error_msg
    })


# Update onborad details - Product Onboard screen

@app.route('/Update_onboard_details', methods=['POST'])
def Update_onboard_details():
    
    data = request.json
    userid = data.get('userid')
    requestid = data.get('requestid')
    requesttype = data.get('requesttype')   
    interlockproduct = data.get('interlockproduct')
    assignee = data.get('assignee')
    interlockmodule = data.get('interlockmodule')
    mfename = data.get('mfename') 
    interlockpoc = data.get('interlockpoc')
    reviewer = data.get('reviewer')
    completiondate = data.get('completiondate')
    priority = data.get('priority')
    deadlinedate = data.get('deadlinedate')
    status = data.get('status')
    description = data.get('description')

    connection = db.get_db_connection(env=env)
    cursor = connection.cursor()
    p_out_errorcode = cursor.var(oracledb.STRING)
    p_out_errmsg = cursor.var(oracledb.STRING)

    cursor.callproc('svc_fdh.pkg_product_onboard_details.prc_update_onboard_details', [
        requestid, requesttype, interlockproduct, assignee, interlockmodule, mfename,
        interlockpoc, reviewer, completiondate, priority, deadlinedate, status, description,
        userid, p_out_errorcode, p_out_errmsg
    ])

    error_code = p_out_errorcode.getvalue()
    error_msg = p_out_errmsg.getvalue()

    return jsonify({
        'error_code': error_code,
        'error_msg': error_msg
    })


# insert onborad details - Product Onboard screen

@app.route('/Update_onboard_popup_details', methods=['POST'])
def Update_onboard_popup_details():
   
    data = request.json
    userid = data.get('userid')
    requestid = data.get('requestid')
    mfename = data.get('mfename')
    mfename = ','.join(mfename)
    status = data.get('status')
    date = data.get('date')
    interlockmodule = data.get('interlockmodule')
    description = data.get('description')

    connection = db.get_db_connection(env=env)
    cursor = connection.cursor()
    p_out_errorcode = cursor.var(oracledb.STRING)
    p_out_errmsg = cursor.var(oracledb.STRING)

    cursor.callproc('svc_fdh.pkg_product_onboard_details.prc_update_onboard_popup_details', [
        userid, requestid, mfename, status, date, interlockmodule, description, p_out_errorcode, p_out_errmsg
    ])

    error_code = p_out_errorcode.getvalue()
    error_msg = p_out_errmsg.getvalue()

    return jsonify({
        'error_code': error_code,
        'error_msg': error_msg
    })


 # get onboard details for Grid display
@app.route('/GetOnboardDetails', methods=['POST'])
def GetOnboardDetails():
   
    data = request.json
    status = data.get('status')
    connection = db.get_db_connection(env=env)
    cursor = connection.cursor()
    p_out_onboard_details = cursor.var(oracledb.CURSOR)
    p_out_errorcode = cursor.var(oracledb.STRING)
    p_out_errmsg = cursor.var(oracledb.STRING)
    cursor.callproc('svc_fdh.pkg_product_onboard_details.prc_select_product_onboard_details', [status, p_out_onboard_details, p_out_errorcode, p_out_errmsg])

    Onboard_details = p_out_onboard_details.getvalue().fetchall()
    keys = [
        "Request ID", "Request Type", "Interlock Product", "Screen Name", "Interlock Module", "Description", 
        "Assignee", "Interlock POC", "Reviewer", "Submitted Date", 
        "Completion Date", "Deadline Date", "Priority", 
        "Status", "Actions"
    ]

    result = [dict(zip(keys, entry)) for entry in Onboard_details]
    error_code = p_out_errorcode.getvalue()
    error_msg = p_out_errmsg.getvalue()

    return jsonify({
        'Onboard_details': result,
        'error_code': error_code,
        'error_msg': error_msg
    })


@app.route('/getDetailsByTraceId', methods=['POST'])
def getDetailsByTraceId():
   
    traceId = request.json.get('traceId')
    fields = request.json.get('fields', [])
    if not traceId:
        return jsonify({"error": "traceId is required"}), 400
    if not fields:
        return jsonify({"error": "fields is required"}), 400

    fields_str = ' '.join(fields)
    query = f"""
    query ($input1: String) {{
        envelopeQuery {{
            getEnvelope(traceId: $input1) {{
                {fields_str}
            }}
        }}
    }}
    """

    variables = {
        "input1": traceId
    }
    url = geturlfromconfig('OOE', 'DEV')

    try:
        response = requests.post(
            url,
            json={'query': query, "variables": variables},
            verify=False
        )
        response = response.json()
        result = response['data']['envelopeQuery']
        return jsonify(result)
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500

@app.route('/getDetailsByInputType', methods=['POST'])
def getDetailsByInputType():
  
    type = request.json.get('type')
    input = request.json.get('input')
    if not type:
        return jsonify({"error": type + " is required"}), 400
    if not input:
        return jsonify({"error": input + " is required"}), 400

    query = f"""
    query ($input1: String) {{
        envelopeQuery {{
            getEnvelopeOverview({type}: $input1) {{
                soNumber
                oicDetails {{
                    oicId
                    shipSets {{
                        shipSetId
                    }}
                }}
            }}
        }}
    }}
    """

    variables = {
        "input1": input
    }
    url = geturlfromconfig('OOE', 'DEV')

    try:
        response = requests.post(
            url,
            json={'query': query, "variables": variables},
            verify=False
        )
        response = response.json()
        woIds = getWOIDs("800008740", "8729246")
        for oic in response['data']['envelopeQuery']['getEnvelopeOverview']['oicDetails']:
            for ss in oic['shipSets']:
                ss['workOrders'] = [woIds[0]]

        result = response['data']['envelopeQuery']['getEnvelopeOverview']
        return jsonify(result)
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500


def getWOIDs(salesOrderId, shipsetId):
    query = f"""
    query MyQuery {{
        getKeys(salesOrderId: "{salesOrderId}", shipsetId: "{shipsetId}") {{
            workorder {{woId}}
            fulfillmentOrder {{foId}}
        }}
    }}
    """
    url=  geturlfromconfig('SO_Header', 'DEV')

    try:
        response = requests.post(
            url,
            json={'query': query},
            verify=False  
        )
        response= response.json()
        result= response['data']['getKeys']['workorder']
        return result
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500

@app.route('/GetOrderTracker' ,methods=['POST'])
def keystoredata():
    data = request.json
    entity_type = data.get('entity_type')
    entity_value =data.get('entity_value')
    source_type = data.get('source_type')
    if not entity_type or not entity_value:
        return jsonify({'error': 'entity_type and entity_value are required'}), 400

    connection = db.get_db_connection(env='DEV')
    try:
        cursor = connection.cursor()
        cursor.execute(
            'SELECT clob_data FROM svc_fdh.test_data WHERE entity_type = :entity_type AND entity_value = :entity_value AND source_type= :source_type' ,
            {'entity_type': entity_type, 'entity_value': entity_value, 'source_type': source_type }
        )
        results = cursor.fetchall()
        
        final_row = []
        for row in results:
            final_row.append(json.loads(row[0].read()))
        
        return jsonify(final_row)
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        cursor.close()
        connection.close()
@app.route('/InsertOrderTracker' ,methods=['POST'])
def summaryviewdatastub():
    data = request.json
    entity_type = data.get('entity_type')
    entity_value = data.get('entity_value')
    source_type = data.get('source_type')
    clob_data = json.dumps(data.get('clob_data'))  

    if not entity_type or not entity_value or not source_type or not clob_data:
        return jsonify({'error': 'Invalid input data'}), 400

    try:
        connection = db.get_db_connection(env='DEV')
        cursor = connection.cursor()

        try:
            cursor.execute(
                '''
                INSERT INTO svc_fdh.test_data (entity_type, entity_value, source_type, clob_data)
                VALUES (:entity_type, :entity_value, :source_type, :clob_data)
                ''',
                entity_type=entity_type,
                entity_value=entity_value,
                source_type=source_type,
                clob_data=clob_data
            )
            connection.commit()
            message = 'Data inserted successfully.'
        except oracledb.IntegrityError as e:
            error_code = e.args[0].code
            if error_code == 1:  # ORA-00001
                return jsonify({'error': 'A record with one of the primary keys already exists.'}), 409
            else:
                raise

        return jsonify({'message': message}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Update Endpoint
@app.route('/UpdateOrderTracker', methods=['POST'])
def update_order_tracker():
    data = request.json
    entity_type = data.get('entity_type')
    entity_value = data.get('entity_value')
    source_type = data.get('source_type')
    clob_data = json.dumps(data.get('clob_data'))  

    if not entity_type or not entity_value or not source_type or not clob_data:
        return jsonify({'error': 'Invalid input data'}), 400

    try:
        connection = db.get_db_connection(env='DEV')
        cursor = connection.cursor()

        cursor.execute(
            '''
            UPDATE svc_fdh.test_data 
            SET clob_data = :clob_data
            WHERE entity_type = :entity_type AND entity_value = :entity_value AND source_type = :source_type
            ''',
            clob_data=clob_data,
            entity_type=entity_type,
            entity_value=entity_value,
            source_type=source_type
        )
        connection.commit()
        message = 'Data updated successfully.'

        return jsonify({'message': message}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/getProcessLogandEventTracker', methods=['POST'])
def getProcessLogandEventTracker():
 
    input = request.json.get('input')
    region = request.json.get('region')
    url = geturlfromconfig("OOE", region)
    identifier_type = request.json.get('identifier_type')

    if not input:
        return jsonify({"error": "input is required"}), 400
    if not identifier_type:
        return jsonify({"error": "identifier_type is required"}), 400

    query = getEnvelopeLogs_query(identifier_type, input, region)
    variables = {
        "input": input
    }

    try:
        response = requests.post(
            url,
            json={'query': query},
            verify=False
        )
        response = response.json()
        result = response['data']['envelopeQuery']
        return jsonify(result)
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500

@app.route('/getEventTracker', methods=['POST'])
def getEventTracker():
   
    input = request.json.get('input')
    region = request.json.get('region')
    identifier_type = request.json.get('identifier_type')
    url = geturlfromconfig("OOE", region)

    if not input:
        return jsonify({"error": "input is required"}), 400
    if not identifier_type:
        return jsonify({"error": "identifier_type is required"}), 400

    query = f"""{{
        envelopeQuery {{
            getPayloadDetails({identifier_type}: "{input}", region: "{region}") {{
                soNumber
            oICDetails {{
                envelopeInMessages {{
                    envelopeId
                    oicId
                    soNumber
                    msgType
                    direction
                    channel
                    status
                    traceId
                    envMsgTextId
                    createDate
                    modifyDate
                    createBy
                    modifyBy
                    region
                    partitionDate
                    isPreGSO
                    startProctime
                    tryCount
                }}
                envelopeOutMessages {{
                    envelopeId
                    oicId
                    soNumber
                    msgType
                    direction
                    channel
                    status
                    traceId
                    envMsgTextId
                    createDate
                    modifyDate
                    createBy
                    modifyBy
                    region
                    partitionDate
                    isPreGSO
                    startProctime
                    tryCount
                }}
                fdh_EventTrackerMessages {{
                    id
                    entityValue
                    domain
                    subDomain
                    transaction
                    version
                    currentState
                    condition
                    eventTime
                    actionCode
                    entityType
                    appTraceID
                    partitionDate
                }}
            }}
            fulfillmentDetails {{
                oicId
                fulfillmentInMessages {{
                    fulfillmentMessageId
                    fulfillmentId
                    oicId
                    msgType
                    status
                    direction
                    exception
                    channelCode
                    fulfillmentMsgTextId
                    region
                    createDate
                    modifyDate
                    createBy
                    modifyBy
                    partitionDate
                    soNumber
                    woId
                    startProcTime
                    tryCount
                }}
                fulfillmentOutMessages {{
                    fulfillmentMessageId
                    fulfillmentId
                    oicId
                    msgType
                    status
                    direction
                    exception
                    channelCode
                    fulfillmentMsgTextId
                    region
                    createDate
                    modifyDate
                    createBy
                    modifyBy
                    partitionDate
                    soNumber
                    woId
                    startProcTime
                    tryCount
                }}
                fdh_EventTrackerMessages {{
                    id
                    entityValue
                    domain
                    subDomain
                    transaction
                    version
                    currentState
                    condition
                    eventTime
                    actionCode
                    entityType
                    appTraceID
                    partitionDate
                }}
            }}
            }}
        }}
    }}"""


    try:
        response = requests.post(
            url,
            json={'query': query},
            verify=False
        )
        response = response.json()
        result = response['data']['envelopeQuery']['getPayloadDetails']['oICDetails' if identifier_type == "oicId" else "fulfillmentDetails"][0]['fdh_EventTrackerMessages']
        return jsonify(result)
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500


@app.route('/getSLILogs', methods=['POST'])
def getSLILogs():

    input = request.json.get('input')
    region = request.json.get('region')
    identifier_type = request.json.get('identifier_type')
    url =  geturlfromconfig("OOE",region)
    if not input:
        return jsonify({"error": "input is required"}), 400
    if not identifier_type:
        return jsonify({"error": "identifier_type is required"}), 400
    query = f"""{{
        envelopeQuery {{
            getPayloadDetails({identifier_type}: "{input}", region: "{region}") {{
                soNumber
                oICDetails {{
                envelopeInMessages {{
                    envelopeId
                    oicId
                    soNumber
                    msgType
                    direction
                    channel
                    status
                    traceId
                    envMsgTextId
                    createDate
                    modifyDate
                    createBy
                    modifyBy
                    region
                    partitionDate
                    isPreGSO
                    startProctime
                    tryCount
                }}
                envelopeOutMessages {{
                    envelopeId
                    oicId
                    soNumber
                    msgType
                    direction
                    channel
                    status
                    traceId
                    envMsgTextId
                    createDate
                    modifyDate
                    createBy
                    modifyBy
                    region
                    partitionDate
                    isPreGSO
                    startProctime
                    tryCount
                }}
                base_EventTrackerMessages {{
                    id
                    status
                    subDomain
                    domain
                    region
                    createDate
                    upateDate
                    createBy
                    updateBy
                    transaction
                    retrycount
                    partitionDate
                    entityValue
                    entityType
                    eventName
                    entityKey
                }}
            }}
            fulfillmentDetails {{
                oicId
                fulfillmentInMessages {{
                    fulfillmentMessageId
                    fulfillmentId
                    oicId
                    msgType
                    status
                    direction
                    exception
                    channelCode
                    fulfillmentMsgTextId
                    region
                    createDate
                    modifyDate
                    createBy
                    modifyBy
                    partitionDate
                    soNumber
                    woId
                    startProcTime
                    tryCount
                }}
                fulfillmentOutMessages {{
                    fulfillmentMessageId
                    fulfillmentId
                    oicId
                    msgType
                    status
                    direction
                    exception
                    channelCode
                    fulfillmentMsgTextId
                    region
                    createDate
                    modifyDate
                    createBy
                    modifyBy
                    partitionDate
                    soNumber
                    woId
                    startProcTime
                    tryCount
                }}
                base_EventTrackerMessages {{
                    id
                    status
                    subDomain
                    domain
                    region
                    createDate
                    upateDate
                    createBy
                    updateBy
                    transaction
                    retrycount
                    partitionDate
                    entityValue
                    entityType
                    eventName
                    entityKey
                }}
            }}
            }}
        }}
    }}"""
  
    try:
        response = requests.post(
            url,
            json={'query': query},
            verify=False  
        )
        response= response.json()
        result = response['data']['envelopeQuery']['getPayloadDetails']['fulfillmentDetails'][0]['base_EventTrackerMessages'] if identifier_type == "fulfillmentId" else response['data']['envelopeQuery']['getPayloadDetails']['oICDetails'][0]['base_EventTrackerMessages']
        # for obj in result:
        #     byte_data = obj["msg"]
        #     print(byte_data)
        #     json_data = convert_gzip_byte_data_to_json(byte_data)
        #     print(json_data)
        #     obj["message"] = json_data
        #     obj.pop("msg")
        
        return jsonify(result)
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500

@app.route('/getWOProcessLog', methods=['POST'])
def getWOProcessLog():
  
    input = request.json.get('input')
    region = request.json.get('region')
    identifier_type = request.json.get('identifier_type')
    url = geturlfromconfig("CM_ProcessLog", region)

    if not input:
        return jsonify({"error": "input is required"}), 400
    if not identifier_type:
        return jsonify({"error": "identifier_type is required"}), 400

    try:
        payload = {
            "entityType": identifier_type,
            "entityValue": input
        }
        response = requests.get(url, json=payload, verify=False)
        response.raise_for_status()
        return response.json()["processlog"]
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500

@app.route('/getPayloadDetails', methods=['POST'])
def getPayloadDetails():

    input = request.json.get('input')
    identifier_type = request.json.get('identifier_type')
    region = request.json.get('region')
    
    try:
        payload = getPayloadDetailsData(input, identifier_type, region)
        return payload
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500

def convert_gzip_byte_data_to_json(byte_data):
    if byte_data is None:
        raise ValueError("byte_data cannot be None")

    try:
        # Decompress the byte data using gzip
        decompressed_data = gzip.decompress(bytes(byte_data))
    except gzip.BadGzipFile as e:
        raise ValueError(f"Failed to decompress byte data: {e}")

    if not decompressed_data:
        raise ValueError("Decompressed data is empty")

    try:
        # Decode bytes to string
        json_str = decompressed_data.decode('utf-8')
    except UnicodeDecodeError as e:
        raise ValueError(f"Failed to decode byte data: {e}")

    if not json_str:
        raise ValueError("JSON string is empty")

    try:
        # Parse string to JSON
        json_data = json.loads(json_str)
    except json.JSONDecodeError as e:
        raise ValueError(f"Failed to parse JSON string: {e}")

    if not json_data:
        raise ValueError("JSON data is empty")

    return json_data
def get_payload_details_query(identifier_type, region):
    if not identifier_type:
        raise ValueError("Identifier type is required")
    
    query = f"""query EnvelopeQuery($input:String){{
        envelopeQuery {{
            getPayloadDetails({identifier_type}: $input, region: "{region}") {{
                soNumber
            oICDetails {{
                envelopeInMessages {{
                    envelopeId
                    oicId
                    soNumber
                    msgType
                    direction
                    channel
                    status
                    traceId
                    envMsgTextId
                    createDate
                    modifyDate
                    createBy
                    modifyBy
                    region
                    partitionDate
                    isPreGSO
                    startProctime
                    tryCount
                }}
                envelopeOutMessages {{
                    envelopeId
                    oicId
                    soNumber
                    msgType
                    direction
                    channel
                    status
                    traceId
                    envMsgTextId
                    createDate
                    modifyDate
                    createBy
                    modifyBy
                    region
                    partitionDate
                    isPreGSO
                    startProctime
                    tryCount
                }}
            }}
            fulfillmentDetails {{
                oicId
                fulfillmentInMessages {{
                    fulfillmentMessageId
                    fulfillmentId
                    oicId
                    msgType
                    status
                    direction
                    exception
                    channelCode
                    fulfillmentMsgTextId
                    region
                    createDate
                    modifyDate
                    createBy
                    modifyBy
                    partitionDate
                    soNumber
                    woId
                    startProcTime
                    tryCount
                }}
                fulfillmentOutMessages {{
                    fulfillmentMessageId
                    fulfillmentId
                    oicId
                    msgType
                    status
                    direction
                    exception
                    channelCode
                    fulfillmentMsgTextId
                    region
                    createDate
                    modifyDate
                    createBy
                    modifyBy
                    partitionDate
                    soNumber
                    woId
                    startProcTime
                    tryCount
                }}
            }}
            }}
        }}
    }}"""

    return query
def get_payload_details_query_oicId(identifier_type, region):
    if not identifier_type:
        raise ValueError("Identifier type is required")
    
    query = f"""query EnvelopeQuery($input:String){{
        envelopeQuery {{
            getPayloadDetails({identifier_type}: $input, region: "{region}") {{
                soNumber
            oICDetails {{
                envelopeInMessages {{
                    envelopeId
                    oicId
                    soNumber
                    msgType
                    direction
                    channel
                    status
                    traceId
                    envMsgTextId
                    createDate
                    modifyDate
                    createBy
                    modifyBy
                    region
                    partitionDate
                    isPreGSO
                    startProctime
                    tryCount
                }}
                
            }}
            fulfillmentDetails {{
                oicId
                fulfillmentInMessages {{
                    fulfillmentMessageId
                    fulfillmentId
                    oicId
                    msgType
                    status
                    direction
                    exception
                    channelCode
                    fulfillmentMsgTextId
                    region
                    createDate
                    modifyDate
                    createBy
                    modifyBy
                    partitionDate
                    soNumber
                    woId
                    startProcTime
                    tryCount
                }}
            }}
            }}
        }}
    }}"""
    return query
def get_payload_details_query_tracker(identifier_type, input, region):
    if not identifier_type:
        raise ValueError("Identifier type is required.")

    query = f"""
    query ($input: String) {{
      envelopeQuery {{
        getPayloadDetails ({identifier_type}: $input, region: "{region}") {{
            soNumber
            oICDetails {{
                envelopeInMessages {{
                    envelopeId
                    oicId
                    soNumber
                    msgType
                    direction
                    channel
                    status
                    traceId
                    envMsgTextId
                    createDate
                    modifyDate
                    createBy
                    modifyBy
                    region
                    partitionDate
                    isPreGSO
                    startProctime
                    tryCount
                }}
                envelopeOutMessages {{
                    envelopeId
                    oicId
                    soNumber
                    msgType
                    direction
                    channel
                    status
                    traceId
                    envMsgTextId
                    createDate
                    modifyDate
                    createBy
                    modifyBy
                    region
                    partitionDate
                    isPreGSO
                    startProctime
                    tryCount
                }}
            }}
            fulfillmentDetails {{
                oicId
                fulfillmentId
                fulfillmentInMessages {{
                    fulfillmentMessageId
                    fulfillmentId
                    oicId
                    msgType
                    status
                    direction
                    exception
                    channelCode
                    fulfillmentMsgTextId
                    region
                    createDate
                    modifyDate
                    createBy
                    modifyBy
                    partitionDate
                    soNumber
                    woId
                    startProcTime
                    tryCount
                }}
                fulfillmentOutMessages {{
                    fulfillmentMessageId
                    fulfillmentId
                    oicId
                    msgType
                    status
                    direction
                    exception
                    channelCode
                    fulfillmentMsgTextId
                    region
                    createDate
                    modifyDate
                    createBy
                    modifyBy
                    partitionDate
                    soNumber
                    woId
                    startProcTime
                    tryCount
                }}
            }}
    }}
  }}
}}
    """

    return query

def getActualPayload(msgTxt_type, input, region):
    if not msgTxt_type:
        raise ValueError("msgTxt_type type is required.")
    query = f"""
    query  {{
    envelopeQuery {{
        getActualPayload({"envelopMessageTextId" if msgTxt_type=="oicidMessageTextId" else msgTxt_type}: "{input}", region: "{region}") {{
            envelopeMessageTextDetails {{
                envMsgTextId
                msgBlob
                createDate
                modifyDate
                createBy
                modifyBy
                partitionDate
            }}
            fulfillmentMessageTextDetails {{
                fulfillmentMessages {{
                fulfillmentMessageId
                fulfillmentId
                oicId
                msgType
                status
                direction
                exception
                channelCode
                fulfillmentMsgTextId
                region
                createDate
                modifyDate
                createBy
                modifyBy
                partitionDate
                }}
                fulfillmentMsgTextId
                msgBlob
            }}
        }}
    }}
}}
    """
    url =  geturlfromconfig('OOE', region)
    try:
        response = requests.post(
            url,
            json={'query': query},
            verify=False  
        )
        response= response.json()
        if msgTxt_type=="fulfillmentMessageTextId":
            msgblob = response['data']['envelopeQuery']['getActualPayload']['fulfillmentMessageTextDetails']['msgBlob']
            result =  convert_gzip_byte_data_to_json(msgblob)
            json_result = json.dumps(result, indent=4)
            return json_result
        
        if msgTxt_type=="oicidMessageTextId":
            msgblob = response['data']['envelopeQuery']['getActualPayload']['envelopeMessageTextDetails']['msgBlob']
            result =  convert_gzip_byte_data_to_json(msgblob)
            json_result = json.dumps(result, indent=4)
            return json_result
        
        response = response['data']['envelopeQuery']['getActualPayload']['envelopeMessageTextDetails']['msgBlob']
        return response
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500

def get_envelope_logs_query(input, identifier_type):
    query = f"""
    query ($input: String) {{
      envelopeQuery {{
        getEnvelopeLogs ({identifier_type}: $input) {{
          soNumber
          oICId
          fulfillmentId
          processLogs {{
            processLogId
            createDate
            createDate
          }}
          incomingEvents {{
            incomingEventId
            keyName
            keyValue
            eventName
            status
            description
            messagePayload
            serviceName
            serviceEndPoint
            startProctime
            traceId
            region
            createDate
            modifyDate
            createBy
            modifyBy
            partitionDate
            soNumber
          }}
          outgoingEvents {{
            outgoingEventId
            keyName
            keyValue
            eventName
            status
            description
            messagePayload
            serviceName
            serviceEndPoint
            startProctime
            traceId
            region
            createDate
            modifyDate
            createBy
            modifyBy
            partitionDate
            soNumber
          }}
        }}
      }}
    }}
    """
    return query
def find_salesorder_entries(data):
    salesorder_entries = [entry for entry in data if entry.get("msgType") == "SALESORDER"]
    return salesorder_entries

def extract_latest_envMsgTextId_by_envelopeId(salesorder_entries):
    # Sort the entries based on envelopeId in ascending order
    sorted_entries = sorted(salesorder_entries, key=lambda x: x.get("envelopeId"))
    # Get the envMsgTextId of the latest entry based on envelopeId
    latest_envMsgTextId = sorted_entries[-1].get("envMsgTextId") if sorted_entries else None
    return latest_envMsgTextId

@app.route('/get_oicid_payload', methods=['POST'])
def get_oicid_payload():

    input = request.json.get('input')
    identifier_type = request.json.get('identifier_type')
    region = request.json.get('region')
    url = geturlfromconfig('OOE', region)
    query = get_payload_details_query_oicId(identifier_type, region)
    variables = {
        "input": input
    }
    try:
        response = requests.post(
            url,
            json={'query': query, "variables": variables},
            verify=False
        )
        response = response.json()
        result = response['data']['envelopeQuery']['getPayloadDetails']['oICDetails'][0]['envelopeInMessages']
        salesorder_entries = find_salesorder_entries(result)
        msgTxt_type = 'envelopMessageTextId'
        latest_envMsgTextId = extract_latest_envMsgTextId_by_envelopeId(salesorder_entries)
        print(latest_envMsgTextId)
        if not latest_envMsgTextId:
            return []
        msgblob = getActualPayload(msgTxt_type, latest_envMsgTextId, region)
        result = convert_gzip_byte_data_to_json(msgblob)
        json_result = json.dumps(result, indent=4)
        return json_result
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500

# Order Tracker
@app.route('/getCompleteOrderTracker', methods=['POST'])  # type: ignore
def getCompleteOrderTracker():

    input = request.json.get('input')
    identifier_type = request.json.get('identifier_type')
    region = request.json.get('region')
    
    try:
        envelopeOverview = getEnvelopeOverview(input, identifier_type, config, region)
        return envelopeOverview
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500

@app.route('/getActualPayload', methods=['POST'])
def getActualPayloadCall():

    input = request.json.get('input')
    msgTxt_type = request.json.get('msgTxt_type')
    region = request.json.get('region')
    try:
        result = getActualPayload(msgTxt_type, input, region)
        return result
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500

@app.route('/getFacilitiesList', methods=['GET'])
def getFacilitiesList():

    query = f"""query GetVendormasterData {{
        getVendormasterData {{
            vendorId
            vendorName
            aliasnameProduction
            aliasnameTest
            createBy
            updateBy
            isOdm
            is3pl
            isCfi
        }}
    }}"""
    url = config['Vendor_Master_Data_USL']

    try:
        response = requests.post(
            url,
            json={'query': query},
            verify=False  
        )
        response = response.json()
        return response['data']['getVendormasterData']
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500

@app.route('/ReassignRequest', methods=['POST'])
def PostReassignRequest():

    region = request.json.get('region')
    fulfillmentId = request.json.get('fulfillmentId')
    reassignByRules = request.json.get('reassignByRules')
    reassignedFacility = request.json.get('reassignedFacility')
    reassignReason = request.json.get('reassignReason')
    reassignedBy = request.json.get('reassignedBy')
    
    url = geturlfromconfig('Reassign_Request', region)
    headers = {'Content-type': 'application/json', 'Accept': 'application/json'}

    payload = {
        "messageType": "string",
        "messageCreateBy": "string",
        "messageId": "string",
        "messageCreateDate": "string",
        "version": "string",
        "messageDetail": {
            "region": region,
            "fulfillmentId": fulfillmentId,
            "reassignByRules": reassignByRules,
            "reassignedFacility": reassignedFacility,
            "reassignReason": reassignReason,
            "reassignedBy": reassignedBy
        }
    }

    try:
        response = requests.post(url, json=payload, headers=headers, verify=False)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        logging.error(f"An error occurred: {e}")
        return jsonify({"error": "Error while making the request"}), 500


# def get_domain_subdomain_details():

#     with open('./domain_matrix.json', 'r') as f:
#         data = json.load(f)

#     transformed_data = [
#         {
#             "domain": value["domain"],
#             "sub-domain": [{"name": sub_domain["name"]} for sub_domain in value.get("sub-domain", [])]
#         }
#         for value in data
#     ]

#     return jsonify(transformed_data)  

@app.route('/postNewTransaction', methods=['POST'])  # type: ignore
def post_new_transaction():

    # services_input_file = open("./servicesData.json", "r")
    # transactions_input_file = open("./transactionData.json", "r")
    # services_input_json = json.load(services_input_file)
    # transaction_input_json = json.load(transactions_input_file)
    # payload = {
    #             "domain": "MfgShipment",
    #             "subdomain": "MfgShipmentGateWay",
    #             "domain_id": 3,
    #             "subdomain_id": 6,
    #             "transaction_id": "InitASNPalletConsumeProcess_17",
    #             "transactions_json": transaction_input_json,
    #             "services_json": services_input_json,
    #             "state": "Active"
    #             }

    # print("post_new_transaction")

  
    # payload = request.json
    # # url = f'https://eoemasterdata-api.eoeg4-a1-np.kob.dell.com/api/createTransaction'


    # # try:
    # #     print(1)
    # #     response = requests.post(url, json=payload, verify=False)
    # #     print(2)
    # #     response.raise_for_status()
    # #     print(3)
    # #     return response.json()

    # # except requests.exceptions.RequestException as e:
    # #     logging.error(f"An error occurred: {e}")
    # #     return jsonify({"error": "Error while making the request"}), 500



    def parse_condition_to_emitting_svc(condition_str, emitting_svc_name):
        # Normalize HTML-encoded operators
        condition_str = condition_str.replace("&amp;&amp;", "&&").replace("||", "||")
        # Remove parentheses to simplify extraction
        cleaned = re.sub(r'[()]+', '', condition_str)
        # Split by logical operators
        tokens = re.split(r'\s*(\|\||&&)\s*', cleaned)
        # Filter out operators and keep only module names
        modules = {token.strip() for token in tokens if token.strip() not in ['&&', '||']}
        # Build the output dictionary
        return {module: emitting_svc_name for module in modules}



    payload = request.json
    domain_id = payload.get("domain_id",None)
    domain = payload.get("domain",None)
    subdomain_id = payload.get("subdomain_id", None)
    subdomain = payload.get("subdomain", None)
    transaction_id = payload.get("transaction_id",None)
    transaction_json = payload.get("transactions_json",None)
    services_json = payload.get("services_json",None)
    state = payload.get("state","Draft")

    if not transaction_json or not services_json:
        return jsonify({"error": "services are mandatory to post the payload"}), 400

    if state == "Draft":
        try:
            env = os.getenv('FLASK_ENV', 'GE4')
            connnection = db.get_db_connection(env= env)
            cursor = connnection.cursor()
            out_sql_msg = cursor.var(oracledb.STRING)
            out_sql_code = cursor.var(oracledb.NUMBER)
            cursor.callproc('svc_fdh.pkg_eoe_domain_matrix.prc_insert_draft_tranaction',
                            [domain_id, domain, subdomain_id, subdomain, transaction_id, json.dumps(transaction_json), json.dumps(services_json), out_sql_code, out_sql_msg]);
            print(out_sql_code.getvalue(), out_sql_msg.getvalue())
            connnection.commit()
            cursor.close()
            db.close_db_connection(connnection)
            return jsonify({"message": out_sql_msg.getvalue()}), 200
        except Exception as e:
            cursor.close()
            db.close_db_connection(connnection)
            print(e)
            return jsonify({"error": str(e)}), 500

    elif state ==  "Active":

        transactionData = {
        "domain": domain,
        "domainId": domain_id,
        "subdomain": subdomain,
        "subdomainId": subdomain_id,
        "name": transaction_json["name"],
        "isNewVersion": transaction_json["isNewVersion"],
        "entityType": transaction_json["entityType"],
        "description": transaction_json["description"],
        "parentTransactions": [ int(i) for i in transaction_json["parentTransaction"]] if transaction_json["parentTransaction"] else [0], # send zero if not present
        "nextTransactions": [ int(i) for i in transaction_json["nextTransaction"]],
        }
        stateTransactions =  []

        for services in services_json:
            service = services
            emittingSerivce =  service["label"]
            states = service["tableData"]
            for state in states:
                isInitState = 'Y' if state["columns"][1]["value"] == '' else 'N'
                tableData = {"currentState": state["columns"][1]["value"],
                            "nextState": state["columns"][2]["value"],
                            "condition": state["columns"][3]["value"],
                            "emittingSvc": parse_condition_to_emitting_svc(state["columns"][3]["value"], emittingSerivce),
                                        #    , "version":"v1"},
                            "serviceSubscribed":[ss["name"] for ss in state["columns"][4]["value"]],
                            "isInitState": isInitState,
                            "isEndTransaction": "N"
                            }
                stateTransactions.append(tableData)
                # print(tableData)
        stateTransactions[len(stateTransactions)-1]["isEndTransaction"] = "Y"
        transactionData["stateTransitions"] = stateTransactions
        print(transactionData)

        # return jsonify(transactionData), 200

        url = f'https://eoemasterdata-api.eoeg4-a1-np.kob.dell.com/api/createTransaction'

        try:
            response = requests.post(url, json=transactionData, verify=False)
            response.raise_for_status()
            if response.json()["status"].upper() == "SUCCESS":
                try:
                    flag = 'Y'
                    env = os.getenv('FLASK_ENV', 'GE4')
                    connnection = db.get_db_connection(env= env)
                    cursor = connnection.cursor()
                    out_sql_msg = cursor.var(oracledb.STRING)
                    out_sql_code = cursor.var(oracledb.NUMBER)
                    cursor.callproc('svc_fdh.pkg_eoe_domain_matrix.prc_delete_draft_tranaction',
                                    [domain_id, domain, subdomain_id, subdomain, transaction_id, str(transactionData), flag, out_sql_code, out_sql_msg]);
                    print(out_sql_code.getvalue(), out_sql_msg.getvalue())
                    connnection.commit()
                    cursor.close()
                    db.close_db_connection(connnection)
                    # return jsonify({"message": out_sql_msg.getvalue()}), 200
                except Exception as e:
                    cursor.close()
                    db.close_db_connection(connnection)
                    print(e)
                    return jsonify({"error": str(e)}), 500
            else:
                try:
                    flag = 'N'
                    env = os.getenv('FLASK_ENV', 'GE4')
                    connnection = db.get_db_connection(env= env)
                    cursor = connnection.cursor()
                    out_sql_msg = cursor.var(oracledb.STRING)
                    out_sql_code = cursor.var(oracledb.NUMBER)
                    cursor.callproc('svc_fdh.pkg_eoe_domain_matrix.prc_delete_draft_tranaction',
                                    [domain_id, domain, subdomain_id, subdomain, transaction_id, str(transactionData), flag, out_sql_code, out_sql_msg]);
                    print(out_sql_code.getvalue(), out_sql_msg.getvalue())
                    connnection.commit()
                    cursor.close()
                    db.close_db_connection(connnection)
                    # return jsonify({"message": out_sql_msg.getvalue()}), 200
                except Exception as e:
                    cursor.close()
                    db.close_db_connection(connnection)
                    print(e)
                    return jsonify({"error": str(e)}), 500

            return response.json()

        except requests.exceptions.RequestException as e:
            logging.error(f"An error occurred: {e}")
            return jsonify({"error": "Error while making the request"}), 500



@app.route('/getDomainMatrixDetails', methods=['POST'])
def get_domain_matrix_details():
 
    url = 'https://eoemasterdata-api.eoeg4-a1-np.kob.dell.com/api/allDomainsData'
    
    try:
        response = requests.get(url, verify=False)
        response.raise_for_status()

        data = response.json()

        with open('./domain_matrix.json', 'w') as f:
            json.dump(data, f, indent=2)

        domain_data = data.get("data", [])
        result = [
            {
                "domain": item["domain"],
                "domain_id": item["domainId"],
                "subdomain": [[{"name": sub["name"]}, {"subdomain_id": sub["subdomainId"]}] for sub in item.get("subdomain", [])]
            }
            for item in domain_data
        ]

        return jsonify(result), 200

    except requests.exceptions.RequestException as e:
        logging.error(f"[ERROR] Request failed: {e}")
        return jsonify({"error": "Error occurred during request"}), 500


@app.route('/getDomainMatrixTransactionDetails', methods=['POST'])
def get_domain_subdomain_transaction_details():
 
    input_json = request.get_json()

    if not input_json or "domain" not in input_json or "subdomain" not in input_json:
        return jsonify({"error": "Missing required fields: domain and subdomain"}), 400

    transaction_data = {}

    try:
        with open(r'./domain_matrix.json', 'r') as f:
            data = json.load(f).get('data', [])

        domain_name = input_json["domain"]
        subdomain_name = input_json["subdomain"]

        for domain in data:
            if domain["domain"] == domain_name:
                for subdomain in domain.get("subdomain", []):
                    if subdomain["name"] == subdomain_name:
                        transaction_data["active_transactions"] = subdomain.get("transaction", [])
                        for transaction in transaction_data["active_transactions"]:
                            transaction["state"] = "Active"

    except Exception as e:
        return jsonify({"error": f"Internal server error: {str(e)}"}), 500

    try:
        env = os.getenv('FLASK_ENV', 'GE4')
        connection = db.get_db_connection(env=env)
        cursor = connection.cursor()
        cursor_result = cursor.execute(
            "SELECT transactions_json FROM svc_fdh.draft_transactions WHERE domain_name = :1 AND subdomain_name = :2",
            [domain_name, subdomain_name]
        )
        transaction_values = cursor_result.fetchall()
        transaction_data["draft_transactions"] = [row[0] for row in transaction_values]

        cursor.close()
        db.close_db_connection(connection)

    except Exception:
        transaction_data["draft_transactions"] = []

    return jsonify(transaction_data), 200


# @app.route('/postDomainMatrixTransactionDetails', methods=['POST'])
# def post_domain_subdomain_transaction_details():
#     input_json = request.get_json()
#     domain_id = input_json.get("domain_id",None)
#     subdomain_id = input_json.get("subdomain_id", None)
#     domain_name = input_json.get("domain_name",None)
#     subdomain_name = input_json.get("subdomain_name", None)
#     transaction_json = input_json.get("transaction_json",None)

#     if not domain_id or not subdomain_id or not domain_name or not subdomain_name or not transaction_json:
#         return jsonify({"error": "Missing required fields: domain_id, subdomain_id, domain_name, subdomain_name, transaction_json"}), 400

#     try:
#         env = 'DEV' 
#         connection = db.get_db_connection(env)
#         cursor = connection.cursor()
#         # insert data into draft_transactions table
#         sql_insert = "INSERT INTO svc_fdh.draft_transactions (domain_id, domain, subdomain_id, subdomain, transaction_json) VALUES (:domain_id, :domain, :subdomain_id, :subdomain, :transaction_json)"
#         cursor.execute(sql_insert, {'domain_id': domain_id, 'domain': domain_name, 'subdomain_id': subdomain_id ,'subdomain': subdomain_name, 'transaction_json': transaction_json})
#         connection.commit()
#         return jsonify({"message": "Draft transaction created successfully"}), 200

cnt = 1
# tbl_counter = 1
def process_transactions(transaction):
    services = {}
    subscribing_states = {}
    all_states = {}
    
    def add_event(emitting_service, event_name, state, service_urls, previous_state=""):
        global cnt 
        # global tbl_counter
        service_name = emitting_service["serviceName"]
        service_type = emitting_service["serviceType"]
        service_version = emitting_service["serviceVersion"]
        for urls in service_urls:
            if urls["url"] and urls["name"] not in subscribing_states:
                subscribing_states[urls["name"]] = []
                subscribing_states[urls["name"]].append(state)
                # print("subscribing_states -> " , subscribing_states)
            elif urls["url"] and urls["name"] in subscribing_states:
                subscribing_states[urls["name"]].append(state)
        
        if service_name not in all_states:
            all_states[service_name] =  []
            all_states[service_name].append(state)
            # print(all_states)
        elif service_name in all_states and state not in all_states[service_name]:
            all_states[service_name].append(state)

        if service_name not in services:
            services[service_name] = {
                "id":cnt,
                "label":service_name,
                "version":service_version,  
                "description":"",
                "serviceType": service_type,
                "description":"",
                "tableData": []
            }

            cnt+=1
            # print("cnt -> ", cnt)
            # tbl_counter = 1
            

        # remove duplicate columns from the list
        for col in services[service_name]["tableData"]:
            if col["columns"][1]["value"] == previous_state and col["columns"][2]["value"] == state and col["columns"][3]["value"] == event_name  :
                col["columns"][4]["value"].extend(urls["url"] for urls in service_urls)
                return
        services[service_name]["tableData"].append({
            "columns":[
                {"value": len(services[service_name]["tableData"])+1},
                {"value": previous_state},
                {"value": state},
                {"value": event_name},
                {"value": service_urls } #[{urls}for urls in service_urls]}  # send name and version
            ]
        })
        # print("services[service_name] -> ", len(services[service_name]["tableData"]) )
        # print("State -> ", state)
        # tbl_counter += 1

   
    # def traverse_states(state, previous_state):

    #     emitting_service = state["emittingSvc"].get(state["condition"])
    #     print("emitting_service -> ", emitting_service)
    #     add_event(emitting_service, state["condition"], state["name"], state["serviceUrls"], previous_state=previous_state)

    def traverse_states(state, previous_state):
        
        # if state condition contains  "||" then split it
        if "||" in state["condition"]:
            emitting_service  = state["emittingSvc"]
            
            for key, value in state["emittingSvc"].items():
                add_event(value, state["condition"], state["name"], state["serviceUrls"], previous_state=previous_state)
        else:
            emitting_service = state["emittingSvc"].get(state["condition"])
            add_event(emitting_service, state["condition"], state["name"], state["serviceUrls"], previous_state=previous_state)
        
        for next_state in state.get("nextState", []):
            traverse_states(next_state, state["name"])

    traverse_states(transaction["nextState"], previous_state="")
  
    return list(services.values())
@app.route('/getDomainMatrixServicesDetails', methods=['POST'])  # type: ignore
def get_transaction_service_details():

    request_data = request.json
    domain_id = request_data.get("domain_id", None)
    subdomain_id = request_data.get("subdomain_id", None)
    transaction_id = request_data.get("transaction_id", None)
    transaction_name = request_data.get("transaction_name", None)
    version = request_data.get("version", None)
    state = request_data.get("state", "Draft")

    if state == "Draft":
        try:
            env = os.getenv('FLASK_ENV', 'GE4')
            connection = db.get_db_connection(env)
            cursor = connection.cursor()
            result = cursor.execute(
                "SELECT services_json FROM svc_fdh.draft_transactions WHERE domain_id = :domain_id AND subdomain_id = :subdomain_id AND transaction_id = :transaction_id",
                {'domain_id': domain_id, 'subdomain_id': subdomain_id, 'transaction_id': transaction_id}
            )
            result = cursor.fetchone()
            services_json = result[0]
            return jsonify(services_json), 200

        except Exception as e:
            return jsonify({"error": f"Internal server error: {str(e)}"}), 500

    if state == "Active":
        if not domain_id and not subdomain_id and not transaction_id and not transaction_name and not version:
            return jsonify({"error": "Missing one or more input values in request body"}), 400

        url = f'https://eoemasterdata-api.eoeg4-a1-np.kob.dell.com/api/getPrimaryData/{domain_id}/{subdomain_id}/{transaction_id}/{transaction_name}/{version}'
        try:
            response = requests.get(url, verify=False)
            if response.status_code == 200:
                api_json = response.json()
                if api_json.get("status") == "failure":
                    return jsonify({"error": api_json}), 404
                result = process_transactions(api_json["data"][0])
                return jsonify(result)
            else:
                return jsonify({"error": f"Failed to fetch data. Status: {response.status_code}"}), response.status_code
        except requests.exceptions.RequestException:
            return jsonify({"error": "Error occurred during request"}), 500

    
@app.route('/Domain_Matrix_Get_ServiceRepository_Dtls', methods=['POST'])
def Domain_Matrix_Get_ServiceRepository_Dtls():

    data = request.json
    domain = data.get('domain')
    Input_Service_Url = data.get('Input_Service_Url')
    env = os.getenv('FLASK_ENV', 'GE4')
    connection = db.get_db_connection(env=env)
    if not connection:
        return jsonify({
            'menu_details': {},
            'error_code': '101',
            'error_msg': 'Failed to connect to the database'
        })
    cursor = connection.cursor()
    p_out_domain_matrix_dtls = cursor.var(oracledb.CURSOR)
    p_out_errorcode = cursor.var(oracledb.STRING)
    p_out_errmsg = cursor.var(oracledb.STRING)

    try:
        cursor.callproc(
            'SVC_FDH.pkg_fdh_ui_screen_details.prc_select_domain_matrix_details',
            [domain, Input_Service_Url, p_out_domain_matrix_dtls, p_out_errorcode, p_out_errmsg]
        )
        domain_matrix_dtls = p_out_domain_matrix_dtls.getvalue().fetchall()
        error_code = p_out_errorcode.getvalue()
        error_msg = p_out_errmsg.getvalue()

        if error_msg != "SUCCESS":
            return jsonify({
                'error_code': error_code,
                'error_msg': error_msg
            }), 500

        service_details = [
            {
                "service_name": row[0],
                "service_description": row[1],
                "service_version": row[2],
                "service_url": row[3]
            }
            for row in domain_matrix_dtls
        ]
        return service_details

    except Exception as e:
        return jsonify({
            'Masterdata': {},
            'error_code': '102',
            'error_msg': 'Failed to execute the procedure. Error: ' + str(e)
        })
    finally:
        cursor.close()
        connection.close()


@app.route('/getDomainMatrixTransactionsByDomain', methods=['POST'])
def get_transactions_by_domain():

    try:
        url = 'https://eoemasterdata-api.eoeg4-a1-np.kob.dell.com/api/allDomainsData'
        response = requests.get(url, verify=False)
        response.raise_for_status()

        data = response.json()

        request_data = request.get_json()
        domain_name = request_data.get('domain')

        if not domain_name:
            return jsonify({"error": "Missing 'domain' in request body"}), 400

        matched_domain = next((d for d in data['data'] if d['domain'] == domain_name), None)

        if not matched_domain:
            return jsonify({"error": f"Domain '{domain_name}' not found"}), 404

        transaction_map = {}
        for subdomain in matched_domain.get('subdomain', []):
            for txn in subdomain.get('transaction', []):
                name = txn.get('name')
                txn_id = txn.get('id')
                if name and txn_id is not None:
                    transaction_map[name] = txn_id

        return jsonify(transaction_map)

    except requests.RequestException as e:
        return jsonify({"error": f"Failed to fetch domain data: {str(e)}"}), 500
    except Exception as e:
        return jsonify({"error": f"An error occurred: {str(e)}"}), 500
    
@app.route('/getAllEntityTypes', methods=['GET'])
def get_all_entity_types():
    try:
        url = 'https://eoemasterdata-api.eoeg4-a1-np.kob.dell.com/api/allEntityTypes'
        response = requests.get(url, verify=False)
        return jsonify(response.json())
    except Exception as e:
        return jsonify({
            "status": "Failure",
            "message": f"Internal error: {str(e)}",
            "data": []
        }), 500

@app.route('/GetServiceRepositoryIODtls', methods=['POST'])
def GetServiceRepositoryIODtls():
 
    data = request.json
    p_in_io_flag = data.get('ioflag')    
    p_in_serial_number = data.get('serialnumber')

    if not p_in_io_flag or not p_in_serial_number:
        return jsonify({
            'svcrepo_details': [],
            'error_code': '100',
            'error_msg': 'No ioflag provided'
        })

    connection = db.get_db_connection(env=env)
    if not connection:
        return jsonify({
            'svcrepo_details': [],
            'error_code': '101',
            'error_msg': 'Failed to connect to the database'
        })

    cursor = connection.cursor()
    try:
        if p_in_io_flag == 'input':
            cursor.execute(
                'SELECT input FROM svc_EOEDB.service WHERE ID = :serial_number',
                {'serial_number': p_in_serial_number}
            )
        elif p_in_io_flag == 'output':
            cursor.execute(
                'SELECT output FROM svc_EOEDB.service WHERE ID = :serial_number',
                {'serial_number': p_in_serial_number}
            )
        else:
            return jsonify({
                'svcrepo_details': [],
                'error_code': '103',
                'error_msg': 'Invalid ioflag value'
            })

        result = cursor.fetchone()
        clob_content = result[0].read() if result and result[0] else None
        return jsonify(clob_content)

    except Exception as e:
        return jsonify({
            'svcrepo_details': [],
            'error_code': '102',
            'error_msg': 'Failed to execute the procedure. Error: ' + str(e)
        })

    
@app.route('/getDomainMatrixServicesVersionDtls', methods=['POST'])
def GetDomainMatrixServicesVersionDtls():
 
    request_data = request.json
    domain = request_data.get("domain", None)
    invokedBy = request_data.get("serviceType", None)

    url = f'https://eoemasterdata-api.eoeg4-a1-np.kob.dell.com/api/allServicesInDomainByType/{domain}/{invokedBy}'
    
    try:
        response = requests.get(url, verify=False)
        if response.status_code == 200:
            api_json = response.json()
            data = api_json.get("data", [])
            return jsonify(data=data, status="Success")
        else:
            return jsonify({"error": f"Failed to fetch data. Status: {response.status_code}"}), response.status_code
    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")
        return jsonify({"error": "Error occurred during request"}), 500

@app.route('/getServiceVersions', methods=['POST'])
def GetServiceVersions():
 
    request_data = request.json
    domain = request_data.get("domain")
    invokedBy = request_data.get("serviceType")
    service_name_to_find = request_data.get("serviceName")

    if not domain or not invokedBy or not service_name_to_find:
        return jsonify({"error": "'domain', 'invokedBy', and 'serviceName' are required."}), 400

    url = f'https://eoemasterdata-api.eoeg4-a1-np.kob.dell.com/api/allServicesInDomainByType/{domain}/{invokedBy}'
    
    try:
        response = requests.get(url, verify=False, timeout=10)
        response.raise_for_status()
        api_json = response.json()
        all_services = api_json.get("data", [])
        for service in all_services:
            if service.get("serviceName") == service_name_to_find:
                versions = service.get("version", [])
                return jsonify(versions=versions)
        return jsonify({
            "error": f"Service '{service_name_to_find}' not found in domain '{domain}'.",
            "status": "Not Found"
        }), 404

    except requests.exceptions.HTTPError as e:
        return jsonify({
            "error": f"Failed to fetch data from target API. Status: {e.response.status_code}",
            "details": str(e)
        }), e.response.status_code
    except requests.exceptions.RequestException as e:
        return jsonify({"error": "An unexpected error occurred while communicating with the service."}), 500

    
@app.route('/getDomainMatrixPublishingEvents', methods=['POST'])
def GetDomainMatrixPublishingEvents():
 
    request_data = request.json
    domain = request_data.get("domain", None)
    subdomain = request_data.get("subdomain", None)

    url = f'https://eoemasterdata-api.eoeg4-a1-np.kob.dell.com/api/getPublishingEvents/{domain}/{subdomain}'
    
    try:
        response = requests.get(url, verify=False)
        if response.status_code == 200:
            api_json = response.json()
            return api_json
        else:
            return jsonify({"error": f"Failed to fetch data. Status: {response.status_code}"}), response.status_code
    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")
        return jsonify({"error": "Error occurred during request"}), 500

@app.route('/GetDomainMatrixSvcTypeDtls', methods=['POST'])
def GetDomainMatrixSvcTypeDtls():

    request_data = request.json
    domain = request_data.get("domain", None)
    connection = db.get_db_connection(env)
    if not connection:
        return jsonify({
            'ServiceType_Details': [],
            'error_code': '101',
            'error_msg': 'Failed to connect to the database'
        })
    cursor = connection.cursor()
    p_out_d_svctype_details = cursor.var(oracledb.CURSOR)
    p_out_errorcode = cursor.var(oracledb.STRING)
    p_out_errmsg = cursor.var(oracledb.STRING)
    try:
        cursor.callproc('SVC_FDH.pkg_eoe_domain_matrix.prc_select_d_svctype_details', [domain, p_out_d_svctype_details, p_out_errorcode, p_out_errmsg])
        svctype_details = p_out_d_svctype_details.getvalue().fetchall()
        error_code = p_out_errorcode.getvalue()
        error_msg = p_out_errmsg.getvalue()
    except Exception as e:
        return jsonify({
            'svctype_details': [],
            'error_code': '102',
            'error_msg': 'Failed to execute the procedure. Error: ' + str(e)
        })
    finally:
        cursor.close()
        connection.close()
 
    res_svctype = []
    res_svctype = [data[0] for data in svctype_details if data is not None]
 
    return jsonify({
        'svctype_details': res_svctype,
        'error_code': error_code,
        'error_msg': error_msg
    })

@app.route('/GetServiceRepositoryDtls', methods=['POST'])
def GetServiceRepositoryDtls():
 
    data = request.json
    domain = data.get('domain')
    # input = json.dumps(data.get('input'))
    # output = json.dumps(data.get('output'))
    if not domain:
        return jsonify({
            'svcrepo_details': [],
            'error_code': '100',
            'error_msg': 'No domain provided'
        })
    connection = db.get_db_connection(env=env)
    if not connection:
        return jsonify({
            'svcrepo_details': [],
            'error_code': '101',
            'error_msg': 'Failed to connect to the database'
        })
    cursor = connection.cursor()
    p_out_repository_details = cursor.var(oracledb.CURSOR)
    p_out_errorcode = cursor.var(oracledb.STRING)
    p_out_errmsg = cursor.var(oracledb.STRING)
    try:
        cursor.callproc('svc_fdh.pkg_service_repository_details.prc_select_service_repository_details', [ domain, p_out_repository_details, p_out_errorcode, p_out_errmsg])
        # Fetch the values from the cursor
        svcrep_details = p_out_repository_details.getvalue().fetchall()
        error_code = p_out_errorcode.getvalue()
        error_msg = p_out_errmsg.getvalue()   
        # Process the results
        data_dicts = []
        for row in svcrep_details:
            custom_obj = {
                "serial_number": row[0],
                "domain": row[1],
                "service_name": row[2],
                "service_type": row[3],
                "service_description": row[4],
                "service_version": row[5],
                "service_url": row[6],
                "input": row[7].read() if row[7] is not None else None,
                "output": row[8].read() if row[8] is not None else None,
                "request_date": row[9] if row[9] is not None else None,
                "request_by": row[10],
                "update_date": row[11] if row[11] is not None else None,            
                "update_by": row[12]
            }
            data_dicts.append(custom_obj) 
    except Exception as e:
        return jsonify({
            'svcrepo_details': [],
            'error_code': '102',
            'error_msg': 'Failed to execute the procedure. Error: ' + str(e)
        })
    finally:
        cursor.close()
        connection.close()
    return jsonify({
        'svcrepo_details': data_dicts,
        'error_code': error_code,
        'error_msg': error_msg,
    })

@app.route('/Insert_svc_rep_details', methods=['POST'])
def insert_svc_rep_details():

    data = request.json
    domain = data.get('domain')
    service_name = data.get('service_name')
    service_type = data.get('service_type')
    service_description = data.get('service_description')
    service_version = data.get('service_version')
    service_url  = data.get('service_url')
    input = data.get('input')
    output = data.get('output')
    # if not domain or not service_name or not service_type or not service_description or not service_version or not service_url or not input or not output:
    #     return jsonify({
    #         'error_code': '100',
    #         'error_msg': 'Null parameter provided'
    #     }), 400
    connection = db.get_db_connection(env)
    if not connection:
        return jsonify({
            'error_code': '101',
            'error': 'Failed to connect to the database'
        }), 500

    try:
        cursor = connection.cursor()
        p_out_errorcode = cursor.var(oracledb.STRING)
        p_out_errmsg = cursor.var(oracledb.STRING)
        cursor.callproc('SVC_FDH.pkg_service_repository_details.prc_insert_svc_rep_details', [
           domain, service_name, service_type, service_description, service_version, service_url, input, output, p_out_errorcode, p_out_errmsg
        ])

        error_code = p_out_errorcode.getvalue()
        error_msg = p_out_errmsg.getvalue()
        if error_code == '0':
            return jsonify({
                'error_code': '0',
                'error': 'Success'
            }), 200
        elif error_code == '1':
            return jsonify({
                'error_code': '406',
                'error': 'DUPLICATE ENTRY: Service with same name and version already exists.'
            }), 406       
        else:
            return jsonify({
                'error_code': error_code,
                'error': error_msg
            }), 500

    except Exception as e:
        return jsonify({
            'error_code': '102',
            'error': 'Failed to execute the procedure. Error: ' + str(e)
        }), 500
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

@app.route('/Update_svc_rep_details', methods=['POST'])
def update_svc_rep_details():

    data = request.json
    serial_number = data.get('serial_number')
    domain = data.get('domain')
    service_name = data.get('service_name')
    service_type = data.get('service_type')
    service_description = data.get('service_description')
    service_version = data.get('service_version')
    service_url = data.get('service_url')
    input = data.get('input')
    output = data.get('output')

    connection = db.get_db_connection(env)
    if not connection:
        return jsonify({
            'error_code': '101',
            'error': 'Failed to connect to the database'
        }), 500

    try:
        cursor = connection.cursor()
        p_out_errorcode = cursor.var(oracledb.STRING)
        p_out_errmsg = cursor.var(oracledb.STRING)

        cursor.callproc('SVC_FDH.pkg_service_repository_details.prc_update_svc_rep_details', [
            serial_number, domain, service_name, service_type, service_description,
            service_version, service_url, input, output, p_out_errorcode, p_out_errmsg
        ])

        error_code = p_out_errorcode.getvalue()
        error_msg = p_out_errmsg.getvalue()

        if error_code == '0':
            return jsonify({
                'error_code': '0',
                'error': 'Success'
            }), 200
        elif error_code == '1':
            return jsonify({
                'error_code': '406',
                'error': 'URL update is not allowed as it is used in other active transactions'
            }), 406
        elif error_code == '2':
            return jsonify({
                'error_code': '406',
                'error': 'Duplicate service name and version already exists'
            }), 406
        else:
            return jsonify({
                'error_code': error_code,
                'error': error_msg
            }), 500

    except Exception as e:
        return jsonify({
            'error_code': '102',
            'error': 'Failed to execute the procedure. Error: ' + str(e)
        }), 500
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

@app.route('/Delete_svc_rep_details', methods=['POST'])
def delete_svc_rep_details():
    data = request.json
    if not data.get('serial_number'):
        return jsonify({
            'error_code': '100',
            'error_msg': 'Null parameter provided'
        }), 400
    connection = db.get_db_connection(env)
    if not connection:
        return jsonify({
            'error_code': '101',
            'error_msg': 'Failed to connect to the database'
        }), 500

    try:
        cursor = connection.cursor()
        p_out_errorcode = cursor.var(oracledb.STRING)
        p_out_errmsg = cursor.var(oracledb.STRING)
        cursor.callproc('SVC_FDH.pkg_service_repository_details.prc_delete_svc_rep_details', [
            data.get('serial_number'), p_out_errorcode, p_out_errmsg
        ])

        error_code = p_out_errorcode.getvalue()
        error_msg = p_out_errmsg.getvalue()
        if error_code == '0':
            return jsonify({
                'error_code': '0',
                'error': 'Success'
            }), 200
        elif error_code == '1':
            return jsonify({
                'error_code': '406',
                'error': 'Delete is not allowed as it is used in other active transactions'
            }), 406       
        else:
            return jsonify({
                'error_code': error_code,
                'error': error_msg
            }), 500

    except Exception as e:
        return jsonify({
            'error_code': '102',
            'error': 'Failed to execute the procedure. Error: ' + str(e)
        }), 500
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

@app.route('/GetInvokebyDetails', methods=['GET'])
def GetInvokebyDetails():

    connection = db.get_db_connection(env)
    if not connection:
        return jsonify({
            'Invokeby_Details': [],
            'error_code': '101',
            'error_msg': 'Failed to connect to the database'
        })
    cursor = connection.cursor()
    p_out_svc_invokeby_details = cursor.var(oracledb.CURSOR)
    p_out_errorcode = cursor.var(oracledb.STRING)
    p_out_errmsg = cursor.var(oracledb.STRING)
    try:
        cursor.callproc('SVC_FDH.pkg_service_repository_details.prc_select_svc_rep_invokedby_details', [ p_out_svc_invokeby_details, p_out_errorcode, p_out_errmsg])
        invokeby_Details = p_out_svc_invokeby_details.getvalue().fetchall()
        error_code = p_out_errorcode.getvalue()
        error_msg = p_out_errmsg.getvalue()
    except Exception as e:
        return jsonify({
            'Invokeby_Details': [],
            'error_code': '102',
            'error_msg': 'Failed to execute the procedure. Error: ' + str(e)
        })
    finally:
        cursor.close()
        connection.close()

    res_invokeby = []
    for data in invokeby_Details:
        if data is None:
            continue
        obj = {
            "filter_value": data[0]
        }
        res_invokeby.append(obj)

    return jsonify({
        'Invokeby_Details': res_invokeby,
        'error_code': error_code,
        'error_msg': error_msg
    })

# Get the consolidated view

@app.route('/getOrderConfigurationColumns', methods=['POST'])
def getOrderConfigurationColumns():

    region = request.json.get('region')
    response = getOrderConfigurationColumnsData(region)
    return response

@app.route('/getPartDetailsColumns', methods=['POST'])
def getPartDetailsColumns():
  
    region = request.json.get('region')
    response = getPartdetailsColumnsData(region)
    return response


@app.route('/GetOrderHeaderData', methods=['POST'])  # type: ignore
def GetOrderHeaderData():
    """
    Get Order Header Data.
    ---
    tags:
      - Order Data
    consumes:
      - application/json
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          properties:
            input:
              type: string
              example: "123456"
            identifier_type:
              type: string
              example: "order_id"
            region:
              type: string
              example: "US"
    responses:
      200:
        description: Successfully retrieved order header data
        content:
          application/json:
            example:
              order_id: "123456"
              status: "shipped"
              region: "US"
      500:
        description: Failed to connect to GraphQL endpoint
        content:
          application/json:
            example:
              error: "Failed to connect to the GraphQL endpoint. Error: <error details>"
    """
    input = request.json.get('input')
    identifier_type = request.json.get('identifier_type')
    region = request.json.get('region')

    try:
        orderdata = GetOAOrderHeaderData(input, identifier_type, region)
        return orderdata
    except aiohttp.ClientError as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500


# Order Assist Screen
@app.route('/GetCompleteEntity', methods=['POST'])
def GetCompleteEntity():
    """
    Get Complete Entity data based on input, identifier type, and region.
    ---
    tags:
      - Entity Data
    consumes:
      - application/json
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          properties:
            input:
              type: string
              example: "3000033259"
            identifier_type:
              type: string
              example: "FulfillmentId"
            region:
              type: string
              example: "APJ"
    responses:
      200:
        description: Successfully retrieved entity data
        content:
          application/json:
            example:
              entityData: {...}
      500:
        description: Error connecting to GraphQL endpoint
        content:
          application/json:
            example:
              error: "Failed to connect to the GraphQL endpoint. Error: <error details>"
    """
    input = request.json.get('input')
    identifier_type = request.json.get('identifier_type')
    region = request.json.get('region')

    try:
        orderdata = GetCompleteEntitydata(input, identifier_type, region)
        return orderdata
    except aiohttp.ClientError as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500



@app.route('/getOrderAssistWorkflowDetails', methods=['POST'])
def getOrderAssistWorkflowDetails():
    # GRAPHQL_URL = " https://ooelandscapeui.ooe-eg4-r3-np.kob.dell.com/graphql" 
    try:
        data = request.get_json()
        fulfillment_id = data.get("fulfillmentId")
        region = data.get("region")

        if not fulfillment_id or not region:
            return jsonify({"error": "Missing 'fulfillmentId' or 'region'"}), 400
        
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500 
    query1 = """
        {
          envelopeQuery {
            getEnvelopeOverview(fulfillmentId: "%s", region: "%s") {
              soNumber
              oicDetails {
                oicId
                isPreGSO
                createDate
              }
            }
          }
        }
        """% (fulfillment_id, region)
    print (query1)
         
    url =  geturlfromconfig('OOE',region)
    
    try:
        response1 = requests.post(
            url,
            json={'query': query1},
            verify=False  
        )
    
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500 
    
    result1 = response1.json()
         

    if "errors" in result1:
            return jsonify({"error": result1["errors"]}), 500

    oic_details = result1['data']['envelopeQuery']['getEnvelopeOverview']['oicDetails']
    filtered = [o for o in oic_details if str(o["isPreGSO"]).lower() == "true"]

    if not filtered:
            return jsonify({"message": "No matching oicDetails found"}), 404

    latest = max(filtered, key=lambda x: x["createDate"])
    latest_oic_id = latest["oicId"]

        # Step 2: Use latest oicId to get payload details
    query2 = f"""
        {{
          envelopeQuery {{
            getPayloadDetails(oicId: "{latest_oic_id}", region: "{region}") {{
              oICDetails {{
                envelopeInMessages {{
                  oicId
                  msgType
                  direction
                  traceId
                  isPreGSO
                  envMsgTextId
                  createDate
                }}
              }}
            }}
          }}
        }}
        """
    
    response2 = requests.post(url, json={'query': query2}, verify=False)
    result2 = response2.json()
    if "errors" in result2:
            return jsonify({"error": result2["errors"]}), 500

    oic_details_list = result2['data']['envelopeQuery']['getPayloadDetails']['oICDetails']

    if not isinstance(oic_details_list, list) or not oic_details_list:
        return jsonify({"error": "oICDetails is missing or not a list"}), 500

    messages = oic_details_list[0].get('envelopeInMessages', [])

# Filter for NETWORKPLANRESP messages
    filtered_messages = [msg for msg in messages if msg.get('msgType') == 'NETWORKPLANRESP']
    if not filtered_messages:
        return jsonify({"message": "Order is placed.No NETWORKPLANRESP messages found"}), 404

# Get the latest by envMsgTextId
    latest_msg = max(filtered_messages, key=lambda x: x["createDate"])
    latest_env_msg_id = latest_msg["envMsgTextId"]
    msgTxt_type="oicidMessageTextId"
    mesgblob =   getOAActualPayload(msgTxt_type, latest_env_msg_id, region)
    return  mesgblob
    
    # mesgblob_raw = mesgblob
    
# print("Raw msgblob output:", mesgblob_raw)
# print("Type of msgblob_raw:", type(mesgblob_raw))
   

@app.route('/getPreGSONetworkPlanProcessing', methods=['POST'])  # type: ignore
def getPreGSONetworkPlanProcessing():

    # Ensure the request has a valid JSON body
    if not request.is_json:
        return jsonify({"error": "Invalid request payload"}), 400

    # Extract the identifier_type, input, and region from the JSON payload
    identifier_type = request.json.get('identifier_type')
    input_value = request.json.get('input')
    region = request.json.get('region')
    if identifier_type == "oicid" or identifier_type == "OICID":
        identifier_type = "oicId"
    if identifier_type == "fulfillmentid" or identifier_type == "FULFILLMENTID":
        identifier_type = "fulfillmentId"
    if not input_value:
        return jsonify({"error": "input is required"}), 400
    if not identifier_type:
        return jsonify({"error": "identifier_type is required"}), 400
    if not all([identifier_type, input_value, region]):
        return jsonify({"error": "Missing required parameters"}), 400

    try:
        orderdata = getPreGSONetworkPlanProcessingdata(input_value, identifier_type, region)
        return orderdata
    except aiohttp.ClientError as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred. Error: {e}"}), 500


@app.route('/getGSOProcessingWOGeneration', methods=['POST'])  # type: ignore
def getGSOProcessingWOGeneration():
   
    # Extract the identifier_type, input, and region from the JSON payload
    identifier_type = request.json.get('identifier_type')
    input_value = request.json.get('input')
    region = request.json.get('region')
    if identifier_type == "oicid" or identifier_type == "OICID":
        identifier_type = "oicId"
    if identifier_type == "fulfillmentid" or identifier_type == "FULFILLMENTID":
        identifier_type = "fulfillmentId"
    if not input_value:
        return jsonify({"error": "input is required"}), 400
    if not identifier_type:
        return jsonify({"error": "identifier_type is required"}), 400
    try:
        # Retrieve the order data
        orderdata = getGSOProcessingWOGenerationdata(input_value, identifier_type, region)
        return orderdata
    except aiohttp.ClientError as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred. Error: {e}"}), 500

@app.route('/GetEntitydata', methods=['POST'])  # type: ignore
def GetEntitydata():
 
    input = request.json.get('input')
    identifier_type = request.json.get('identifier_type')
    region = request.json.get('region')
    
    try:
        orderdata = GetOAEntitydata(input, identifier_type, region)
        return orderdata
    except aiohttp.ClientError as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500

@app.route('/GetErrorLogforEntity', methods=['POST'])  # type: ignore
def GetErrorLogforEntity():
 
    input = request.json.get('input')
    identifier_type = request.json.get('identifier_type')
    region = request.json.get('region')
    if identifier_type == "oicid" or identifier_type == "OICID":
        identifier_type = "oicId"
    if identifier_type == "fulfillmentid" or identifier_type == "FULFILLMENTID":
        identifier_type = "fulfillmentId"
    if not input:
        return jsonify({"error": "input is required"}), 400
    if not identifier_type:
        return jsonify({"error": "identifier_type is required"}), 400
    try:
        orderdata = GetErrorLogData(input, identifier_type, region)
        return orderdata
    except aiohttp.ClientError as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500

@app.route('/GetRuleLogforEntity', methods=['POST'])  # type: ignore
def GetRuleLogforEntity():
 
    input = request.json.get('input')
    identifier_type = request.json.get('identifier_type')
    region = request.json.get('region')
    
    try:
        orderdata = GetRuleLogforEntityData(input, identifier_type, region)
        return orderdata
    except aiohttp.ClientError as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500

@app.route('/GetProcessRuleErrorLogforEntity', methods=['POST'])  # type: ignore
def GetProcessRuleErrorLogforEntity():

    input = request.json.get('input')
    identifier_type = request.json.get('identifier_type')
    region = request.json.get('region')
    if identifier_type == "oicid" or identifier_type == "OICID":
        identifier_type = "oicId"
    if identifier_type == "fulfillmentid" or identifier_type == "FULFILLMENTID":
        identifier_type = "fulfillmentId"
    if not input:
        return jsonify({"error": "input is required"}), 400
    if not identifier_type:
        return jsonify({"error": "identifier_type is required"}), 400
    try:
        errordata = GetErrorLogData(input, identifier_type, region)
        ruledata = GetRuleLogforEntityData(input, identifier_type, region)
        return jsonify({
            'errorData': errordata,
            'ruleData': ruledata
        })
    except aiohttp.ClientError as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500

@app.route('/getErrorcountColourCodeForTabs', methods=['POST'])  # type: ignore
def getErrorcountColourCodeForTabs():
 
    input = request.json.get('input')
    identifier_type = request.json.get('identifier_type')
    region = request.json.get('region')
    
    try:
        errorcount = getErrorcountForTabs(input, identifier_type, region)  # type: ignore
        return errorcount
    except aiohttp.ClientError as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500

@app.route('/getFFandSObasedonASN', methods=['POST'])  # type: ignore
def getFFandSObasedonASN():

    input = request.json.get('input')
    identifier_type = request.json.get('identifier_type')
    region = request.json.get('region')
    
    try:
        resultset = GetCompleteEntitydata(input, identifier_type, region)
        resultset = extract_sales_order_info(resultset)
        return resultset
    except aiohttp.ClientError as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500


# For OOE Landscape
@app.route("/graphql-query", methods=["POST"])
def graphql_query():

    try:
        data = request.get_json()
        # print("Received data:", data) 

        query_type = data.get("queryType")
        inputs = data.get("inputs")
        region = data.get("region", "DAO")
        datakey = data.get("datakey")

        if not all([query_type, inputs, datakey]):
            return jsonify({"error": "Missing required fields"}), 400

        result = build_and_execute_query(query_type, inputs, datakey, region)
        # print("Query result:", result) # 👈 Log output
        if datakey == "messageText":
            details = result.get("data", {}).get("envelopeQuery", {}).get("getActualPayload", {})

            if "envelopeMessageTextDetails" in details and details["envelopeMessageTextDetails"]:
                env_detail = details["envelopeMessageTextDetails"]
                blob = env_detail.get("msgBlob")
                if blob:
                    decoded = convert_gzip_byte_data_to_json(blob)
                    env_detail["msgBlob"] = decoded

            if "fulfillmentMessageTextDetails" in details and details["fulfillmentMessageTextDetails"]:
                fulfill_detail = details["fulfillmentMessageTextDetails"]
                blob = fulfill_detail.get("msgBlob")
                if blob:
                    decoded = convert_gzip_byte_data_to_json(blob)
                    fulfill_detail["msgBlob"] = decoded

        return result
    except ValueError as ve:
        return jsonify({"error": str(ve)}), 400
    except Exception as e:
        return jsonify({"error": "Unexpected error", "details": str(e)}), 500
@app.route('/GetNode0Data', methods=['POST'])  # type: ignore
def GetNode0Data():
    """
    Get Node 0 Data with color coding.
    ---
    tags:
      - Node Data
    consumes:
      - application/json
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          properties:
            FulfillmentId:
              type: string
              example: "3000033259"
            SalesOrder:
              type: string
              example: "8040036926"
            region:
              type: string
              example: "APJ"
    responses:
      200:
        description: Successfully retrieved node data
        content:
          application/json:
            example:
              nodeData: {...}
      500:
        description: Error connecting to GraphQL endpoint
        content:
          application/json:
            example:
              error: "Failed to connect to the GraphQL endpoint. Error: <error details>"
    """
    FulfillmentId = request.json.get('FulfillmentId')
    SalesOrder = request.json.get('SalesOrder')
    region = request.json.get('region')
    
    try:
        resultset = GetNode0DetailswithColorcode(FulfillmentId, SalesOrder, region)
        return resultset
    except aiohttp.ClientError as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500
@app.route('/GetAllotherNodeData', methods=['POST'])  # type: ignore
def GetAllotherNodeData():
    """
    Get Node 1 Data with color coding.
    ---
    tags:
      - Node Data
    consumes:
      - application/json
    parameters:
      - in: body
        name: body
        required: true
        schema:
          type: object
          properties:
            FulfillmentId:
              type: string
              example: "3000033259"
            SalesOrder:
              type: string
              example: "SO78910"
            region:
              type: string
              example: "APJ"
    responses:
      200:
        description: Successfully retrieved node data
        content:
          application/json:
            example:
              nodeData: {...}
      500:
        description: Error connecting to GraphQL endpoint
        content:
          application/json:
            example:
              error: "Failed to connect to the GraphQL endpoint. Error: <error details>"
    """
    FulfillmentId = request.json.get('FulfillmentId')
    SalesOrder = request.json.get('SalesOrder')
    region = request.json.get('region')
    
    try:
        resultset = GetNodeDetailswithColorcode(FulfillmentId, SalesOrder, region)
        return resultset
    except aiohttp.ClientError as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500
    finally:
        gc.collect()
 
#OrderAssist Screen
def build_node_tree(fulfillments, order_date, actual_wo_data):
    result_set = actual_wo_data.get('CUST')  
    
    factory_codes = {
        "CC4X", "EMFX", "APCX", "SXM", "ICCX", "EMFC", "AMFA", "MES-EMFX",
        "CCCX", "BR1X", "MES-CC4X", "MES-APCX", "MES-CCCX", "MES-ICCX",
        "CC6X", "MES-BR1X", "YPG", "MES-AMFA", "MES-EMFC"
    }


    node = OrderedDict([
    ("Facility", "Order Placed"),
    ("NodeStatus", "CMP"),
    ("orderDate", order_date),
    ("child", [])
    ])

    for fulfillment in fulfillments:
        facility = fulfillment.get("facility")
        facility_type = fulfillment.get("facilityType")
        fabd = fulfillment.get("fabd")
        fsbd = fulfillment.get("fsbd")
        carrier = fulfillment.get("carrier")
        ship_mode = fulfillment.get("shipMode")
        legs = fulfillment.get("legs", [])

        child_node = {
            "Facility": facility,
            "FacilityType": facility_type,
            "Originalfabd": fabd,
            "Originalfsbd": fsbd,
            "OriginalCarrier": carrier,
            "OriginalShipMode": ship_mode,
            "NodeStatus": ("Not Started"),
            "ActualCarrier": "",
            "ActualShipMode": "",
            "Actualfabd": "",
            "Actualfsbd": "",
            "children": [],
            "isDirectShippable": "Y",
            "isOtmEnabled": "Y",
            "shipVia": "DUK",
            "status": "Success",
            "updateDate": "2025-06-18T00:00:00.000+00:00"
        }

        for leg in legs:
            child_facility = leg.get("shipFromLocation")
            facility_type = "Factory" if child_facility in factory_codes else "3PL"
            print(facility_type)
            grandchild = {
                "Facility": child_facility,
                "FacilityType": facility_type, #leg.get("facilityType"),
                "Originalfabd": leg.get("fabd"),
                "Originalfsbd": leg.get("fsbd"),
                "OriginalCarrier": leg.get("carrier"),
                "OriginalShipMode": leg.get("shipMode"),
                "NodeStatus": "Not Started",
                "ActualCarrier": "",
                "ActualShipMode": "",
                "Actualfabd": "",
                "Actualfsbd": "",
                "children": [{
                    "address": leg.get("deliveryAddress", "44 Morningside Ave, Keansburg, New Jersey(NJ), 07734"),
                    "createDate": leg.get("createDate", "2025-06-06T11:05:00Z"),
                    "NodeStatus": "Delivered",
                    "MABD": "",
                    "EstimatedDeliveryDate": ""
                }],
                "isDirectShippable": leg.get("isDirectShippable", "Y"),
                "isOtmEnabled": "",
                "shipVia": "DUK",
                "status": "Not started",
                "updateDate": "2025-06-18T00:00:00.000+00:00"
            }

            child_node["children"].append(grandchild)

        node["child"].append(child_node)

    return node



@app.route('/getOrderAssistWorkflowDetailssection', methods=['POST'])
def getOrderAssistWorkflowDetailssection():
    try:
        data = request.get_json()
        fulfillment_id = data.get("fulfillmentId")
        region = data.get("region")

        if not fulfillment_id or not region:
            return jsonify({"error": "Missing 'fulfillmentId' or 'region'"}), 400

        query1 = f"""
        {{
          envelopeQuery {{
            getEnvelopeOverview(fulfillmentId: "{fulfillment_id}", region: "{region}") {{
              soNumber
              oicDetails {{
                oicId
                isPreGSO
                createDate
              }}
            }}
          }}
        }}
        """
        url = geturlfromconfig('OOE', region)
        response1 = requests.post(url, json={'query': query1}, verify=False)
        result1 = response1.json()

        if "errors" in result1:
            return jsonify({"error": result1["errors"]}), 500

        overview = result1['data']['envelopeQuery']['getEnvelopeOverview']
        so_number = overview['soNumber']
        oic_details = overview['oicDetails']
        filtered = [o for o in oic_details if str(o["isPreGSO"]).lower() == "true"]

        if not filtered:
            return jsonify({"message": "No matching oicDetails found"}), 404

        latest = max(filtered, key=lambda x: x["createDate"])
        latest_oic_id = latest["oicId"]

        query2 = f"""
        {{
          envelopeQuery {{
            getPayloadDetails(oicId: "{latest_oic_id}", region: "{region}") {{
              oICDetails {{
                envelopeInMessages {{
                  oicId
                  msgType
                  direction
                  traceId
                  isPreGSO
                  envMsgTextId
                  createDate
                }}
              }}
            }}
          }}
        }}
        """
        response2 = requests.post(url, json={'query': query2}, verify=False)
        result2 = response2.json()

        if "errors" in result2:
            return jsonify({"error": result2["errors"]}), 500
        messages = result2['data']['envelopeQuery']['getPayloadDetails']['oICDetails'][0]['envelopeInMessages']
        network_msgs = [msg for msg in messages if msg.get('msgType') == 'NETWORKPLANRESP']
        if not network_msgs:
            return jsonify({"message": "Order is placed. No NETWORKPLANRESP messages found"}), 404

        latest_msg = max(network_msgs, key=lambda x: x["createDate"])
        msgTxt_type = "oicidMessageTextId"
        latest_env_msg_id = latest_msg["envMsgTextId"]
        mesgblob = getActualPayload(msgTxt_type, latest_env_msg_id, region)

        if isinstance(mesgblob, str):
            try:
                mesgblob = json.loads(mesgblob)
            except json.JSONDecodeError as e:
                return jsonify({"error": f"Failed to parse message blob JSON: {e}"}), 500

        message_detail = mesgblob.get("messageDetail", {})
        order_date = mesgblob.get("messageCreateDate", "")
        fulfillments = message_detail.get("fulfillments", [])
        print(fulfillments)

        actual_wo_data = {}
        for fulfillment in fulfillments:
            fid = fulfillment.get("fulfillmentId")
            if not fid:
                continue

            wo_response =  getWorkOrderList(so_number,fid,region)

            if wo_response.status_code == 200:
                try:
                    wo_json = wo_response.json['resultSet']
                    if isinstance(wo_json, str):
                        wo_json = json.loads(wo_json)
                except Exception:
                    wo_json = {}

                for wo in wo_json:
                    ship_to = wo.get("shipToFacility")
                    if ship_to:
                        actual_wo_data[ship_to] = {
                            "Actualfsbd": wo.get("fsbd", ""),
                            "Actualfabd": wo.get("fabd", ""),
                            "ActualShipMode": wo.get("shipMode", ""),
                            "ActualCarrier": wo.get("vendorId", "")
                        }

        final_output = {
            "NodeDetails": [build_node_tree(fulfillments, order_date, actual_wo_data)],
            "fulfilmentId": fulfillment_id,
            "status": "SUCCESS"
        }

        return jsonify(final_output), 200

    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500
    finally:
        gc.collect()
 
@app.route('/getbySalesOrderId', methods=['POST'])
def getbySalesbyOrderId():
    # Get query parameters
    data = request.get_json()
    salesorderid = data.get('salesorderid', "")
    tableformat = data.get('tableformat')
    region = data.get('region')

    try:
        if salesorderid and tableformat:
            salesorder_ids = salesorderid.split(",") if salesorderid else []
            salesorderdetails = getbySalesOrderID(salesorderid=salesorder_ids,format_type=tableformat,region=region)
            salesorderdetails = json.loads(salesorderdetails)
            return jsonify(salesorderdetails), 200
        else:
            return jsonify({"error": "Error: Please Provide Inputs salesorderid and tableformat (grid or export)"}), 400
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500

@app.route('/getbyFulfillmentId', methods=['POST'])
def getbyFulfillmentId():
    # Get query parameters
    data = request.get_json()
    fulfillmentid = data.get('fulfillmentid', "")
    tableformat = data.get('tableformat')
    region = data.get('region')

    try:
        if fulfillmentid and tableformat:
            fulfillment_ids = fulfillmentid.split(",") if fulfillmentid else []
            fulfillmentdetails = getbyFulfillmentID(fulfillmentids=fulfillment_ids, format_type=tableformat, region=region)
            fulfillmentdetails = json.loads(fulfillmentdetails)
            return jsonify(fulfillmentdetails), 200
        else:
            return jsonify({"error": "Error: Please Provide Inputs fulfillmentid and tableformat (grid or export)"}), 400
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500

@app.route('/getbyWorkordertId', methods=['POST'])
def getbyWorkordertId():
    # Get query parameters
    data = request.get_json()
    workorderid = data.get('workorderid', "")
    tableformat = data.get('tableformat')
    region = data.get('region')

    try:
        if workorderid and tableformat:
            workorder_ids = workorderid.split(",") if workorderid else []
            workorderdetails = workerORderThread(workorderids=workorder_ids, format_type=tableformat, region=region)
            workorderdetails = json.loads(workorderdetails)
            return jsonify(workorderdetails), 200
        else:
            return jsonify({"error": "Error: Please Provide Inputs workorderid and tableformat (grid or export)"}), 400
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to the GraphQL endpoint. Error: {e}"}), 500
        
@app.route("/get-order-data", methods=["POST"])
def handle_order_request():
    try:
        payload = request.get_json()

        format_type = payload.get("format_type", "export")
        region = payload.get("region", "EMEA")
        filters = payload.get("filters", {})
        salesorderid = payload.get("salesorderid", [])

        result = getbySalesOrderID(
            salesorderid=salesorderid,
            format_type=format_type,
            region=region,
            filters=filters
        )

        return jsonify(result)

    except Exception as e:
        return jsonify({
            "error": str(e),
            "trace": traceback.format_exc()
        }), 500

@app.route('/GetFilterColumns', methods=['GET'])
def get_filter_columns_by_region():
    if getattr(g, 'skip_logs', False):
            return response
    g.skip_logs = True
    connection = db.get_db_connection(env)
    if not connection:
        return jsonify({'error': 'Failed to connect to the database'}), 500

    cursor = connection.cursor()

    try:
        query = """
            SELECT ID, "value", "label", "filter_type", "is_active", "default", "valueType", "REGION"
            FROM REGION_DATA_FILTERS
        """
        cursor.execute(query)
        rows = cursor.fetchall()
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        cursor.close()
        connection.close()

    def convert_to_bool(value):
        return str(value).strip() == '1'

    result = {}
    
    for row in rows:
        region = row[7].strip() if row[7] else "UNKNOWN"
        filter_item = {
            "id": row[0],
            "value": row[1],
            "label": row[2],
            "type": row[3],
            "default": convert_to_bool(row[5]),
            "is_active": convert_to_bool(row[4]),
            "valueType": row[6]
        }
        if region not in result:
            result[region] = []
        result[region].append(filter_item)

    return jsonify(result) 

@app.route('/GetTemplates', methods=['GET'])
def get_templates():
    if getattr(g, 'skip_logs', False):
        return jsonify({'message': 'Logs skipped'})
    g.skip_logs = True

    region = request.args.get('region')
    template_id = request.args.get('id')

    connection = db.get_db_connection(env)
    if not connection:
        return jsonify({'error': 'Failed to connect to the database'}), 500

    cursor = connection.cursor()
    result = []

    try:
        query = """
        SELECT TEMPLATE_ID, USERDATA, REGION, FORMAT_TYPE, 
               FILTERS, TEMPLATENAME, WORKORDERID, SHARED,
               SHAREDUSERNAME, COLUMNS
        FROM TEMPLATE_DATA
        """
        filters = []
        bind_params = {}

        if region:
            filters.append("REGION = :region")
            bind_params["region"] = region
        if template_id:
            filters.append("TEMPLATE_ID = :template_id")
            bind_params["template_id"] = template_id

        if filters:
            query += " WHERE " + " AND ".join(filters)
            
        cursor.execute(query, bind_params)
        rows = cursor.fetchall()

        for row in rows:
            try:
                userdata_clob = row[1]
                userdata_str = userdata_clob.read() if hasattr(userdata_clob, 'read') else userdata_clob
                userdata_json = json.loads(userdata_str) if userdata_str else {}
            except Exception as e:
                print("Failed to parse userdata:", e)
                userdata_json = {}

            try:
                filters_clob = row[4]
                filters_str = filters_clob.read() if hasattr(filters_clob, 'read') else filters_clob
                filters_json = json.loads(filters_str) if filters_str else {}
            except Exception as e:
                print("Failed to parse filters:", e)
                filters_json = {}

            try:
                columns_clob = row[9]
                columns_str = columns_clob.read() if hasattr(columns_clob, 'read') else columns_clob
                columns_json = json.loads(columns_str) if columns_str else []
            except Exception as e:
                print("Failed to parse columns:", e)
                columns_json = []

            result.append({
                "template_id": row[0],
                "userdata": userdata_json,
                "region": row[2],
                "format_type": row[3],
                "filters": filters_json,
                "templatename": row[5],
                "workorderid": row[6],
                "shared": bool(row[7]),
                "sharedUserName": row[8],
                "columns": columns_json
            })

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        cursor.close()
        connection.close()

    return jsonify(result)

@app.route('/SaveTemplate', methods=['POST'])
def save_template():
    data = request.get_json()

    connection = db.get_db_connection(env)
    if not connection:
        return jsonify({'error': 'Failed to connect to database'}), 500

    cursor = connection.cursor()
    try:
        insert_sql = """
        INSERT INTO TEMPLATE_DATA (
            TEMPLATE_ID, REGION, FORMAT_TYPE, USERNAME, USEREMAIL,
            FILTERS, TEMPLATENAME, WORKORDERID, SHARED,
            SHAREDUSERNAME, COLUMNS
        ) VALUES (
            :template_id, :region, :format_type, :userName, :userEmail,
            :filters, :templatename, :workorderid, :shared,
            :sharedUserName, :columns
        )
        """

        bind_data = {
            "template_id": data.get("template_id"),
            "region": data.get("region"),
            "format_type": data.get("format_type"),
            "userName": data.get("userName"),
            "userEmail": data.get("userEmail"),
            "filters": json.dumps(data.get("filters", {})),
            "templatename": data.get("templatename"),
            "workorderid": data.get("workorderid"),
            "shared": 1 if data.get("shared") else 0,
            "sharedUserName": data.get("sharedUserName"),
            "columns": json.dumps(data.get("columns", []))
        }

        cursor.execute(insert_sql, bind_data)
        connection.commit()
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        cursor.close()
        connection.close()

    return jsonify({'message': 'Template saved successfully'})

@app.route('/EditTemplate/<template_id>', methods=['PUT'])
def edit_template(template_id):
    data = request.get_json()

    connection = db.get_db_connection(env)
    if not connection:
        return jsonify({'error': 'Failed to connect to database'}), 500

    cursor = connection.cursor()
    try:
        update_sql = """
        UPDATE TEMPLATE_DATA SET
            REGION = :region,
            FORMAT_TYPE = :format_type,
            USERNAME = :userName,
            USEREMAIL = :userEmail,
            FILTERS = :filters,
            TEMPLATENAME = :templatename,
            WORKORDERID = :workorderid,
            SHARED = :shared,
            SHAREDUSERNAME = :sharedUserName,
            COLUMNS = :columns
        WHERE TEMPLATE_ID = :template_id
        """

        bind_data = {
            "region": data.get("region"),
            "format_type": data.get("format_type"),
            "userName": data.get("userName"),
            "userEmail": data.get("userEmail"),
            "filters": json.dumps(data.get("filters", {})),
            "templatename": data.get("templatename"),
            "workorderid": data.get("workorderid"),
            "shared": 1 if data.get("shared") else 0,
            "sharedUserName": data.get("sharedUserName"),
            "columns": json.dumps(data.get("columns", [])),
            "template_id": template_id
        }

        cursor.execute(update_sql, bind_data)
        connection.commit()
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        cursor.close()
        connection.close()

    return jsonify({'message': 'Template updated successfully'})

@app.route('/DeleteTemplate/<template_id>', methods=['DELETE'])
def delete_template(template_id):
    connection = db.get_db_connection(env)
    if not connection:
        return jsonify({'error': 'Failed to connect to database'}), 500

    cursor = connection.cursor()
    try:
        delete_sql = "DELETE FROM TEMPLATE_DATA WHERE TEMPLATE_ID = :template_id"
        cursor.execute(delete_sql, {"template_id": template_id})
        connection.commit()
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        cursor.close()
        connection.close()

    return jsonify({'message': f'Template with TEMPLATE_ID {template_id} deleted successfully'})

@app.route('/combine_filters', methods=['POST'])
def combine_filters_data():
    data = request.get_json()
    filters_data = data.get('filters', {})
    format_type = data.get('format_type', 'flat')
    region = data.get('region')
    if not filters_data:
        return jsonify({
            'error_code': 400,
            'error': "need atleast one filter"
        }), 400

    try:
        input_data = {
            "format_type": format_type,
            "region": region
        }
        if filters_data.get("salesorderid"):
            input_data["sales_order_ids"] = filters_data.get("salesorderid").split(",")
        if filters_data.get("workorderid"):
            input_data["work_order_ids"] = filters_data.get("workorderid").split(",")
        if filters_data.get("fulfillmentid"):
            input_data["fulfilment_ids"] = filters_data.get("fulfillmentid").split(",")
        if filters_data.get("foId"):
            input_data["fulfilment_order_ids"] = filters_data.get("foId").split(",")
        if filters_data.get("salesOrderRef"):
            input_data["sales_order_ref_ids"] = filters_data.get("salesOrderRef").split(",")
        if filters_data.get("from"):
            input_data["from_date"] = filters_data.get("from")
        if filters_data.get("to"):
            input_data["to_date"] = filters_data.get("to")
        response_data = fetch_filter_data(input_data)
        if input_data.get("format_type") == "grid":
            desired_order = [
                'BUID', 'PP Date', 'Sales Order Id', 'Fulfillment Id', 'Region Code', 'FoId', 'System Qty',
                'Ship By Date',
                'LOB', 'Ship From Facility', 'Ship To Facility', 'Tax Regstrn Num', 'Address Line1', 'Postal Code',
                'State Code',
                'City Code', 'Customer Num', 'Customer Name Ext', 'Country', 'Create Date', 'Ship Code',
                'Must Arrive By Date',
                'Update Date', 'Merge Type', 'Manifest Date', 'Revised Delivery Date', 'Delivery City',
                'Source System Id',
                'IsDirect Ship',
                'SSC', 'Vendor Work Order Num', 'Channel Status Code', 'Ismultipack', 'Ship Mode', 'Is Otm Enabled',
                'SN Number', 'OIC Id', 'Order Date'
            ]

            rows = []
            for item in response_data:
                row = {
                    "columns": [{"value": item.get(key, "")} for key in desired_order]
                }
                rows.append(row)

            table_grid_output = tablestructural(data=rows, IsPrimary=input_data.get("region"))
            return jsonify(table_grid_output), 200
        else:
            return jsonify(response_data), 200

    except Exception as e:
        return jsonify({
            'error_code': '102',
            'error': 'Failed to execute the procedure. Error: ' + str(e)
        }), 500
 

if __name__ == '__main__':
    env = os.getenv('FLASK_ENV', 'GE4')
    debug = env 
    config = get_configdetails(env)
    app.run(threaded=True,host='0.0.0.0', port=int(5000))